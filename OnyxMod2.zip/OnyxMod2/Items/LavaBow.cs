using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class LavaBow : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Lava Bow");
            Tooltip.SetDefault("The Mini Star Melter was a placeholder...");
        }

        public override void SetDefaults()
        {
            item.width = 20;
            item.knockBack = 5f;
            item.value = 1000;
            item.damage = 17;
            item.height = 40;
            item.useTime = 27;
            item.useAnimation = 27;
            item.useStyle = 5;
            item.noMelee = true;
            item.rare = 10;
            item.UseSound = SoundID.Item5;
            item.useAmmo = AmmoID.Arrow;
            item.autoReuse = true;
            item.shoot = 1;
            item.shootSpeed = 9.1f;
            item.ranged = true;

        }
        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            float numberProjectiles = 1 + Main.rand.Next(3);
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedByRandom(MathHelper.ToRadians(12));
                Projectile.NewProjectile(position.X, position.Y, perturbedSpeed.X, perturbedSpeed.Y, type, damage, knockBack, player.whoAmI);
            }
            return false;
        }

    }

}
