﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    [AutoloadEquip(EquipType.Head)]
    public class ArmorHelmet1 : ModItem
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Oblivion Helmet");
            Tooltip.SetDefault("+10% Damage and 5% crit chance to all classes except for Summoner");
        }

        public override void SetDefaults()
        {
            item.width = 41;
            item.height = 40;
            item.value = 100000;
            item.rare = 9;
            item.defense = 25;
        }
       
        public override bool IsArmorSet(Item head, Item body, Item legs)
        {
            return body.type == mod.ItemType("ArmorBreastplate1") && legs.type == mod.ItemType("ArmorBoots1");
        }



        public override void UpdateEquip(Player player)
        {
            player.magicDamage += 0.10f;
            player.thrownDamage += 0.10f;
            player.meleeDamage += 0.10f;
            player.rangedDamage += 0.10f;
            player.magicCrit += 5;
            player.thrownCrit += 5;
            player.meleeCrit += 5;
            player.rangedCrit += 5;
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+20% Attack Damage to all classes except for Summoner" + "\nImmunity to 'Venom','OnFire','CursedInferno' and 'Lava'";
            player.magicDamage += 0.20f;
            player.thrownDamage += 0.20f;
            player.meleeDamage += 0.20f;
            player.rangedDamage += 0.20f;
            player.lavaImmune = true;
            player.buffImmune[BuffID.Venom] = true;
            player.buffImmune[BuffID.OnFire] = true;
            player.buffImmune[BuffID.CursedInferno] = true;
        }




        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(null, "OnyxBar", 20);
            recipe.AddIngredient(null, "EXCore", 10);
            recipe.AddIngredient(null, "WormEye", 1);
            recipe.AddIngredient(null, "EyeShard", 3);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }


    }
}
