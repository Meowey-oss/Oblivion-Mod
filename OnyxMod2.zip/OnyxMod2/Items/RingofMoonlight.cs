
using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;

namespace OnyxMod2.Items
{

    public class RingofMoonlight : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Ring Of Moonlight");
            Tooltip.SetDefault("You gain 2% Crit Chance" + "\nSummons lunar flares when hit."+ "\n'A ring full the power of the moon.'");
        }

        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = Item.buyPrice(0, 2, 0, 0);
            item.rare = 9;
            item.accessory = true;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            MyPlayer modPlayer = MyPlayer.Get(player);
            modPlayer.ROML = true;
            player.magicCrit += 2;
            player.meleeCrit += 2;
            player.rangedCrit += 2;
            player.thrownCrit += 2;



        }
   
      

    }
}
