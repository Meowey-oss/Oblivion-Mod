using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class Bow2 : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Legend Bow");
            Tooltip.SetDefault("Only a true Hero can craft this.");
        }

        public override void SetDefaults()
        {
            item.width = 1;
            item.knockBack = 2f;
            item.value = 2000000;
            item.damage = 280;
            item.height = 1;
            item.useTime = 19;
            item.useAnimation = 19;
            item.useStyle = 5;
            item.knockBack = 9f;
            item.noMelee = true;
            item.rare = -12;
            item.UseSound = SoundID.Item5;
            item.autoReuse = true;
            item.shoot = ModContent.ProjectileType<Projectiles.ArrowProjectile2>();
            item.shootSpeed = 34.1f;
            item.ranged = true;

        }


        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            float numberProjectiles = 3 + Main.rand.Next(2);
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedByRandom(MathHelper.ToRadians(4));
                Projectile.NewProjectile(position.X, position.Y, perturbedSpeed.X, perturbedSpeed.Y, type, damage, knockBack, player.whoAmI);
            }
            return false;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "Bow1", 1);
            recipe.AddIngredient(ItemID.LunarBar, 50);
            recipe.AddIngredient(null, "EXCore", 20);
            recipe.AddIngredient(null, "WormEye", 1);
            recipe.AddIngredient(null, "EyeShard", 15);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}