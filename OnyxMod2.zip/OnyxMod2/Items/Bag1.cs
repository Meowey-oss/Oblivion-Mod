﻿using Terraria.ModLoader;
using Terraria.ID;
using Terraria;

namespace OnyxMod2.Items
{



    public class Bag1 : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Treasure Bag");
            Tooltip.SetDefault("Right Click To Open" + "\nThe Boss Can Drop:" + "\nOne of 5 Different Items/Weapons with a 100% chance" + "\n1% Chance for a Dev Weapon (2% in Expert Mode)" + "\nRandom amount of ExCores, OnyxBars and EyeShards");
        }
        public override void SetDefaults()
        {
            item.width = 12;
            item.height = 12;
            item.useStyle = -1;

            item.consumable = true;
            item.rare = -12;
            item.maxStack = 30;
        }

        public override bool CanRightClick()
        {
            return true;
        }

        public override void RightClick(Player player)
        {
            int choice = Main.rand.Next(5);
            if (Main.expertMode)
            {
                player.QuickSpawnItem(mod.ItemType("ObliviousBelt"));
            }
                if (choice == 0)
            {
                player.QuickSpawnItem(mod.ItemType("Obviliator"));
            }

            if (choice == 1)
            {
                player.QuickSpawnItem(mod.ItemType("EyeCrusher"));
            }

            if (choice == 2)
            {
                player.QuickSpawnItem(mod.ItemType("RainGun"));
            }

            if (choice == 3)
            {
                player.QuickSpawnItem(mod.ItemType("CorruptGun"));
            }
            if (choice == 4)
            {
                player.QuickSpawnItem(mod.ItemType("OblivionStaff"));
            }
        

            player.QuickSpawnItem(mod.ItemType("EXCore"), Main.rand.Next(2, 4));
            player.QuickSpawnItem(mod.ItemType("OnyxBar"), Main.rand.Next(5, 8));
            player.QuickSpawnItem(mod.ItemType("EyeShard"), Main.rand.Next(3, 5));
        }

    }
}