﻿using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class DevSickle : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Sickle of Purgation");
        }

        public override void SetDefaults()
        {
            item.width = 116;
            item.knockBack = 2f;
            item.value = Item.buyPrice(0, 23, 0, 99);
            item.damage = 300;
            item.height = 124;
            item.useTime = 18;
            item.useAnimation = 18;
            item.useStyle = 1;
            item.noMelee = false;
            item.rare = -12;
            item.UseSound = SoundID.Item105;
            item.autoReuse = true;
            item.shoot = ModContent.ProjectileType<Projectiles.GodSickle2>();
            item.shootSpeed = 10.1f;
            item.melee = true;

        }

        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            Projectile.NewProjectile(position.X, position.Y, speedX * 1.5f, speedY * 1.5f, mod.ProjectileType("GodSickle"), damage + 300, knockBack, player.whoAmI);
            Projectile.NewProjectile(position.X, position.Y, -speedX * 2f, -speedY * 2f, mod.ProjectileType("GodSickle3"), damage + 100, knockBack, player.whoAmI);
            float numberProjectiles = 2;
            float rotation = MathHelper.ToRadians(20);
            position += Vector2.Normalize(new Vector2(speedX, speedY)) * 10f;
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedBy(MathHelper.Lerp(-rotation, rotation, i / (numberProjectiles - 1))) * .7f;
                Projectile.NewProjectile(position.X, position.Y, perturbedSpeed.X, perturbedSpeed.Y, type, damage, knockBack, player.whoAmI);
            }

            return false;
        }



    }
}