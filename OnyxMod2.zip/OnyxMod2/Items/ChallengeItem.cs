using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace OnyxMod2.Items
{

    public class ChallengeItem : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Challenge Heart");
            Tooltip.SetDefault("You only have 1HP. Be Careful..." + "\nCan be toggled On and Off.(Must stay in Your Inventory)"+ "\nSome Accessories lose their Life effect if you have Challenge Mode on." + "\nNot Consumable");
        }

        public override void SetDefaults()
        {
            item.width = 20;
            item.consumable = false;
            item.height = 20;
            item.rare = -12;
            item.useStyle = 4;
        }

        public override void UpdateInventory(Player player)
        {
            if (MyWorld.ChallengeMode == true)
            {
                player.statLifeMax2 = 1;
            }


        }

        public override bool UseItem(Player player)
        {

            
                if (MyWorld.ChallengeMode == false)
                {
                Main.NewText("Challenge Mode Activated!", (byte)190, (byte)55, (byte)70, false);
                Main.PlaySound(15 , (int)player.position.X, (int)player.position.Y, 0);
                MyWorld.ChallengeMode = true;
                }
                else
            if (MyWorld.ChallengeMode == true)
            {
                Main.NewText("Challenge Mode Deactivated!", (byte)190, (byte)55, (byte)70, false);
                Main.PlaySound(15 , (int)player.position.X, (int)player.position.Y, 0);
                MyWorld.ChallengeMode = false;
            }
            return true;
        }











        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddTile(TileID.DemonAltar);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}