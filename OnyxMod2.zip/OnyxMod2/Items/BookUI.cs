/*
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Terraria;
using Terraria.DataStructures;
using Terraria.GameContent.UI.Elements;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.UI;

namespace OnyxMod2.Items
{
    internal class BookUI : UIState
    {
        private static UIPanel basePanel;
        private static float panelTop;
        private static float panelLeft;
        private static float panelWidth;
        private static float panelHeight;
        public static bool visible;
        internal static object Instance;

        public override void OnInitialize()
        {
            UIPanel panel = new UIPanel();
            panel.Width.Set(300, 0);
            panel.Height.Set(300, 0);
            Append(panel);

            UIText text = new UIText("idk"); // 1
            panel.Append(text); // 2
        }
    }
}

*/

