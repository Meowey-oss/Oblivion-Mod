﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class SArrow : ModItem
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Ultrafire Arrow");
        }

        public override void SetDefaults()
        {
            item.damage = 1;
            item.ranged = true;
            item.width = 30;
            item.maxStack = 666;
            item.consumable = true;
            item.ammo = 40;
            item.height = 30;
            item.knockBack = 3f;
            item.value = Item.buyPrice(0, 0, 2, 0);
            item.shoot = mod.ProjectileType("SlimeArrow");
            item.shootSpeed = 14.1f;
            item.rare = 4;
            item.UseSound = SoundID.Item1;

        }

        /*
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.HallowedBar, 1);
            recipe.AddIngredient(ItemID.SoulofLight, 1);
            recipe.AddIngredient(ItemID.SoulofNight, 3);
            recipe.AddIngredient(ItemID.CursedArrow, 250);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this, 250);
            recipe.AddRecipe();
        }
        */


    }
}
