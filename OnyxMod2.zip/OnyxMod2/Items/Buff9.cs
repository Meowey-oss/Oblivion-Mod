using System;
using OnyxMod2.Items.Projectiles;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class Buff9 : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Snowflake");
            Description.SetDefault("A Snowflake will protect you.");
            Main.debuff[Type] = false;
            Main.pvpBuff[Type] = true;
            Main.buffNoSave[Type] = true;
            Main.buffNoTimeDisplay[Type] = true;
        }
        public override void Update(Player player, ref int buffIndex)
        {

            MyPlayer.nobuff = true;
            MyPlayer modPlayer = MyPlayer.Get(player);
            if (player.ownedProjectileCounts[ModContent.ProjectileType<Sphere1>()] > 0)
                modPlayer.memee = true;

            if (!modPlayer.memee)
            {
                player.DelBuff(buffIndex);
                buffIndex--;
            }
            else
                player.buffTime[buffIndex] = 18000;
        }
    }


}
