﻿using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class Buff5 : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Soultaker");
            Main.debuff[Type] = true;
            Main.pvpBuff[Type] = true;
            Main.buffNoSave[Type] = true;
        }


        public override void Update(NPC npc, ref int buffIndex)
        {
            int num1 = Dust.NewDust(npc.position, npc.width, npc.height, DustID.Electric);
            Main.dust[num1].scale = 1.4f; 
            Main.dust[num1].velocity *= 7f; 
            Main.dust[num1].noGravity = true;
            npc.lifeRegen -= 2000;
            npc.lifeRegenExpectedLossPerSecond = 500;



        }




    }
}
