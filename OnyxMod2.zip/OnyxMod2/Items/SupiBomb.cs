﻿using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class SupiBomb : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Super Bomb");
            Tooltip.SetDefault("The end is near...");
        }
        public override void SetDefaults()
        {
            item.damage = 999;
            item.width = 14;
            item.height = 18;
            item.maxStack = 1;
            item.consumable = false;
            item.autoReuse = true;
            item.useStyle = 1;
            item.rare = -12;
            item.UseSound = SoundID.Item1;
            item.useTime = 3;
            item.useAnimation = 3;
            item.value = 10000;
            item.noUseGraphic = true;
            item.noMelee = true;
            item.shoot = ModContent.ProjectileType<Projectiles.SuperBomb>();
            item.shootSpeed = 30f;
        }
        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            float numberProjectiles = 5;
            float rotation = MathHelper.ToRadians(90);
            position += Vector2.Normalize(new Vector2(speedX, speedY)) * 10f;
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedBy(MathHelper.Lerp(-rotation, rotation, i / (numberProjectiles - 1))) * .7f;
                Projectile.NewProjectile(position.X, position.Y, perturbedSpeed.X, perturbedSpeed.Y, type, damage, knockBack, player.whoAmI);
            }
            return false;
        }

    }
}