﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;

namespace OnyxMod2.Items
{
    public class Doomsday : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Doomsday");
            Tooltip.SetDefault("The Laser Applies 'Poisoned' 'OnFire' 'Toxic' and 'OnMagma' on hit" + "\nToxic deals a lot of damage to enemies and even more when they are immune to 'Poisoned'.");
        }
        public override void SetDefaults()
        {   
            item.damage = 600;  
            item.noMelee = true;  
            item.noUseGraphic = false;
            item.magic = true;
            item.mana = 30; 
            item.rare = -12;  
            item.width = 28; 
            item.height = 30;  
            item.useTime = 40;
            item.channel = true;
            item.UseSound = SoundID.Item13;  
            item.useStyle = ItemUseStyleID.HoldingOut;   
            item.shootSpeed = 4f;       
            item.useAnimation = 40;                         
            item.shoot = mod.ProjectileType("BeamP2");
            item.value = Item.sellPrice(1, 40, 0, 0);
        }
    }

}
