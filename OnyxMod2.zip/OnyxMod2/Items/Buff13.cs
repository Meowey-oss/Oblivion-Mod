using System;
using OnyxMod2.Items.Projectiles;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class Buff13 : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Crystal Heart");
            Description.SetDefault("The Crystal heart will protect you from attacks up to 3 times until it breaks.");
            Main.debuff[Type] = false;
            Main.pvpBuff[Type] = true;
            Main.buffNoSave[Type] = true;
            Main.buffNoTimeDisplay[Type] = true;
        }
        public override void Update(Player player, ref int buffIndex)
        {

            MyPlayer.nobuff = true;
            MyPlayer modPlayer = MyPlayer.Get(player);
            if (player.ownedProjectileCounts[ModContent.ProjectileType<LCP1>()] > 0)
                modPlayer.memeee = true;

            if (!modPlayer.memeee)
            {
                player.DelBuff(buffIndex);
                buffIndex--;
            }
            else
                player.buffTime[buffIndex] = 18000;
        }
    }


}
