using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class UltimateRazorbladeTyphoon : ModItem
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Ultimate Razorblade Typhoon");
            Tooltip.SetDefault("Can shoot 3 Ultimate Typhoons");
        }

        public override void SetDefaults()
        {
            item.damage = 460;
            item.magic = true;
            item.mana = 40;
            item.width = 5;
            item.height = 5;
            item.knockBack = 11f;
            item.noMelee = true;
            item.autoReuse = true;
            item.UseSound = SoundID.Item84;
            item.value = Item.buyPrice(0, 50, 0, 0);
            item.useAnimation = 28;
            item.useTime = 28;
            item.useStyle = ItemUseStyleID.HoldingOut;
            item.shoot = ModContent.ProjectileType<Projectiles.UTyphoon>();
            item.shootSpeed = 20.7f;
            item.rare = ItemRarityID.Cyan;

        }

        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            float numberProjectiles = 3;
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedByRandom(MathHelper.ToRadians(35));
                Projectile.NewProjectile(position.X, position.Y, perturbedSpeed.X, perturbedSpeed.Y, type, damage, knockBack, player.whoAmI);
            }
            return false;
        }


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "RazorbladeTyphoons", 2);
            recipe.AddIngredient(null, "EyeShard", 5);
            recipe.AddIngredient(null, "WormEye", 1);
            recipe.AddIngredient(ItemID.ManaCrystal, 15);
            recipe.AddIngredient(ItemID.FragmentNebula, 15);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
