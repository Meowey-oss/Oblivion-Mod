﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class SuperSummon : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Super Summon");
            Tooltip.SetDefault("'''''''''''''''''''''''''''''''''''''''''''''''''''''''''");
        }

        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.defense = 5;
            item.value = Item.buyPrice(0, 2, 0, 0);
            item.rare = 6;
            item.accessory = true;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.maxMinions += 500;
            player.minionDamage += 3.0f;

        }

        }
}