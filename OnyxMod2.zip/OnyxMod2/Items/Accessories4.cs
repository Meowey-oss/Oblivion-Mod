﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class Accessories4 : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Hellstone shield");
            Tooltip.SetDefault("You gain the immunity against the Effect 'OnFire'"+ "\nEnemies take damage when they hit you on contact.");
        }

        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.defense = 5;
            item.value = Item.buyPrice(0, 2, 0, 0);
            item.rare = 6;
            item.accessory = true;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {

            if (player.thorns < 1f)
            {
                player.thorns = 0.333333343f;
            }

            player.buffImmune[BuffID.OnFire] = true;
            player.lavaImmune = true;
        }

       



    }
}