﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
namespace OnyxMod2.Items
{
    public class InfinityCoin : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Infinty Coin");
            Tooltip.SetDefault("Used to craft infinite amounts of ammo.");
        }

        public override void SetDefaults()
        {
            item.rare = 7;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(ItemID.GoldCoin, 255);
            recipe.AddTile(null, "BloodAltar");
            recipe.SetResult(this, 1);
            recipe.AddRecipe();
        }



    }
}
