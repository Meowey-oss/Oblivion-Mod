﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class LegendBlade : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Legend Blade");
            Tooltip.SetDefault("Greatly heals the player on melee hit."  + "\nOnly a true Hero can craft this.");
        }
        public override void SetDefaults()
        {
            item.damage = 760;
            item.melee = true;
            item.width = 100;
            item.height = 100;
            item.useTime = 12;
            item.useAnimation = 12;
            item.useStyle = 1;
            item.knockBack = 13f;
            item.value = 1000000;
            item.shoot = ModContent.ProjectileType<Projectiles.SwordProjectile5>();
            item.shootSpeed = 19.1f;
            item.rare = -12;
            item.UseSound = SoundID.Item29;
            item.autoReuse = true;
        }

        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            float numberProjectiles = 1 + Main.rand.Next(1);
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedByRandom(MathHelper.ToRadians(6));
                Projectile.NewProjectile(position.X, position.Y, perturbedSpeed.X, perturbedSpeed.Y, type, damage, knockBack, player.whoAmI);
            }
            return false;
        }

        public override void OnHitNPC(Player player, NPC target, int damage, float knockback, bool crit)
        {
            int lifeSteal = damage / 320;
            player.statLife += lifeSteal;
            player.HealEffect(lifeSteal);
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "UltimateTerraBlade", 1);
            recipe.AddIngredient(null, "EyeCrusher", 3);
            recipe.AddIngredient(null, "OnyxBar", 30);
            recipe.AddIngredient(null, "WormEye", 1);
            recipe.AddIngredient(null, "EXCore", 10);
            recipe.AddIngredient(null, "EyeShard", 15);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();


        }

    }
}
