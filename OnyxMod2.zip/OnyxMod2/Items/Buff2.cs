﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class Buff2 : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Watcher");
            Description.SetDefault("You feel terrible...");
            Main.debuff[Type] = true;
            Main.pvpBuff[Type] = true;
            Main.buffNoSave[Type] = true;
        }

        public override void Update(Player player, ref int buffIndex)
        {
            int num1 = Dust.NewDust(player.position, player.width, player.height, DustID.Shadowflame);
            Main.dust[num1].scale = 3f;
            Main.dust[num1].velocity *= 3f;
            Main.dust[num1].noGravity = true;
            player.statDefense -= 50;
            player.aggro *= 2;
            player.lifeRegen -= 35;
            player.magicDamage /= 2f;
            player.meleeDamage /= 2f;
            player.minionDamage /= 2f;
            player.thrownDamage /= 2f;
            player.rangedDamage /= 2f;
            player.rocketDamage /= 2f;
            player.moveSpeed /= 2f;
        }
        public override void Update(NPC npc, ref int buffIndex)
        {
            int num1 = Dust.NewDust(npc.position, npc.width, npc.height, DustID.PurpleCrystalShard);
            Main.dust[num1].scale = 1.9f;
            Main.dust[num1].velocity *= 3f;
            Main.dust[num1].noGravity = true;
            npc.defense -= 5;
            npc.lifeRegen -= 200;
            npc.lifeRegenExpectedLossPerSecond = 30;


        }
    }
}
