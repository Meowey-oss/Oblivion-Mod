using System;
using OnyxMod2.Items.Projectiles;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class Buff10 : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Corrupted Orb");
            Description.SetDefault("The Corrupted Orb will Protect you.");
            Main.debuff[Type] = false;
            Main.pvpBuff[Type] = true;
            Main.buffNoSave[Type] = true;
            Main.buffNoTimeDisplay[Type] = true;
        }
        public override void Update(Player player, ref int buffIndex)
        {

            MyPlayer.nobuff = true;
            MyPlayer modPlayer = MyPlayer.Get(player);
            if (player.ownedProjectileCounts[ModContent.ProjectileType<Sphere5>()] > 0)
                modPlayer.memeee = true;

            if (!modPlayer.memeee)
            {
                player.DelBuff(buffIndex);
                buffIndex--;
            }
            else
                player.buffTime[buffIndex] = 18000;
        }
    }


}
