using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class FireBomb : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Solar Bomb");
            Tooltip.SetDefault("Explodes into a storm of Fire Dragons");
        }

        public override void SetDefaults()
        {
            item.width = 44;
            item.knockBack = 9f;
            item.value = 1000;
            item.damage = 140;
            item.height = 44;
            item.useTime = 23;
            item.maxStack = 999;
            item.useAnimation = 23;
            item.useStyle = 5;
            item.noMelee = true;
            item.consumable = true;
            item.rare = 8;
            item.noUseGraphic = true;
            item.UseSound = SoundID.Item5;
            item.autoReuse = true;
            item.shoot = ModContent.ProjectileType<Projectiles.GrenadeProj>();
            item.shootSpeed = 18.1f;
            item.thrown = true;

        }





        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.FragmentSolar, 1);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this, 25);
            recipe.AddRecipe();
        }



    }
}
