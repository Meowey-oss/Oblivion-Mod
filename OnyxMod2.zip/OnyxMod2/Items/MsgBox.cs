﻿
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class MsgBox: ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Message Box");
            Tooltip.SetDefault("I guess you got some Errors now.");
        }

        public override void SetDefaults()
        {
            item.width = 20;
            item.knockBack = 8f;
            item.value = 1000000;
            item.damage = 140;
            item.height = 40;
            item.useTime = 100;
            item.useAnimation = 100;
            item.useStyle = 5;
            item.noMelee = true;
            item.rare = 9;
            item.mana = 50;
            item.UseSound = SoundID.Item7;
            item.autoReuse = true;
            item.shootSpeed = 0f;
            item.magic = true;
            item.shoot = ModContent.ProjectileType<Projectiles.Ani1>();
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.FragmentSolar, 5);
            recipe.AddIngredient(ItemID.SoulofFright, 50);
            recipe.AddIngredient(ItemID.SoulofMight, 50);
            recipe.AddIngredient(null, "EXCore", 5);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
