using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
namespace OnyxMod2.Items
{
    public class DemonDagger : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Demon Dagger");
        }
        public override void SetDefaults()
        {
            item.damage = 34;
            item.melee = true;
            item.width = 24;
            item.height = 24;
            item.useTime = 11;
            item.useAnimation = 11;
            item.useStyle = 3;
            item.knockBack = 5f;
            item.value = 100;
            item.rare = 5;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
        }

        public override void OnHitNPC(Player player, NPC target, int damage, float knockback, bool crit)
        {
            int lifeSteal = damage / 34;
            player.statLife += lifeSteal;
            player.HealEffect(lifeSteal);
        }


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(ItemID.DemoniteBar, 7);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();

            recipe = new ModRecipe(mod);

            recipe.AddIngredient(ItemID.CrimtaneBar, 7);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }


    }
}
