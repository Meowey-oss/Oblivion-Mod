﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class Buff3 : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Golden Slime Buff");
            Description.SetDefault("Greatly increases life Regen but halfs your running speed.");
            Main.debuff[Type] = false;
            Main.pvpBuff[Type] = true;
            Main.buffNoSave[Type] = true;
        }

        public override void Update(Player player, ref int buffIndex)
        {
            int num1 = Dust.NewDust(player.position, player.width, player.height, DustID.GoldCoin);
            Main.dust[num1].scale = 1.2f;
            Main.dust[num1].velocity *= 2f;
            Main.dust[num1].noGravity = true;
            player.lifeRegen += 22;
            player.moveSpeed /= 2f;
        }

    }
}
