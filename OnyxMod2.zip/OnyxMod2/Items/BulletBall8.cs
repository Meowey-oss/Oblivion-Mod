﻿using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class BulletBall8 : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Septic Bullet Ball");
        }

        public override void SetDefaults()
        {
            item.width = 50;
            item.knockBack = 2f;
            item.value = Item.buyPrice(1, 40, 0, 0);
            item.damage = 508;
       
            item.height = 50;
            item.useTime = 98;
            item.useAnimation = 98;
            item.useStyle = 5;
            item.noMelee = true;
            item.rare = 9;
            item.noUseGraphic = true;
            item.UseSound = SoundID.Item17;
            item.autoReuse = true;
            item.shoot = mod.ProjectileType("BB8");
            item.shootSpeed = 24.3f;
            item.ranged = true;

        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(null, ("EXCore"), 5);
            recipe.AddIngredient(null, ("WormEye"), 1);
            recipe.AddIngredient(null, ("OnyxBar"), 20);
            recipe.AddIngredient(null, ("EyeShard"), 10);
            recipe.AddIngredient(null, ("BulletBall7"), 1);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}