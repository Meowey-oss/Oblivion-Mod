﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class MissDrop : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Missing.Yes");
            Tooltip.SetDefault("Doubles your HP but you lose half of your Defense and You will slowly lose Life.(Life Nebulas are Disabled)"+ "\nDoesn't work while the Challenge Mode is Active."+ "\nTo take Gods Power u must take the risk.");
        }

        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = Item.buyPrice(0, 2, 0, 0);
            item.rare = 6;
            item.accessory = true;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            if (MyWorld.ChallengeMode == false)
            {
                player.buffImmune[BuffID.NebulaUpLife1] = true;
                player.buffImmune[BuffID.NebulaUpLife2] = true;
                player.buffImmune[BuffID.NebulaUpLife3] = true;
                player.lifeRegen -= 10;
                player.statLifeMax2 *= 2;
                player.statDefense /= 2;
            }
        }

    }
}