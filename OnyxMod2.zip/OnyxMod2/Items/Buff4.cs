﻿using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class Buff4 : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Ancient Curse");
            Description.SetDefault("A heavy Curse.");
            Main.debuff[Type] = true;
            Main.pvpBuff[Type] = true;
            Main.buffNoSave[Type] = true;
        }

        public override void Update(Player player, ref int buffIndex)
        {
            int num1 = Dust.NewDust(player.position, player.width, player.height, DustID.AncientLight);
            Main.dust[num1].scale = 1.9f;
            Main.dust[num1].velocity *= 3f;
            Main.dust[num1].noGravity = true;
            player.lifeRegen -= 10;
            player.lifeRegenCount -= 5;
            player.statDefense -= 20;
        }
        public override void Update(NPC npc, ref int buffIndex)
        {
            int num1 = Dust.NewDust(npc.position, npc.width, npc.height, DustID.AncientLight);
            Main.dust[num1].scale = 1.9f; 
            Main.dust[num1].velocity *= 3f; 
            Main.dust[num1].noGravity = true;
            npc.defense -= 40;
            npc.lifeRegen -= 200;
            npc.lifeRegenExpectedLossPerSecond = 50;
 

        }




    }
}
