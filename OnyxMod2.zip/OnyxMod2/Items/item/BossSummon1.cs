﻿using Terraria.ModLoader;
using Terraria.ID;
using Terraria;

namespace OnyxMod2.Items.item
{



    public class BossSummon1 : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Bad looking Eye");
            Tooltip.SetDefault("Summons 'Obvilion'." + "\nNot Consumable");
        }
        public override void SetDefaults()
        {
            item.width = 12;
            item.height = 12;
            item.useStyle = 4;
            item.rare = 1;
            item.useAnimation = 30;
            item.useTime = 30;
            item.maxStack = 1;
            item.consumable = false;
        }

        public override bool CanUseItem(Player player)
        {
           
            return !Main.dayTime && !NPC.AnyNPCs(mod.NPCType("Class1"));


        }

        public override bool UseItem(Player player)
        {
            Main.NewText("Music: TeknoAXE - Nebula Boss Fight", (byte)30, (byte)255, (byte)10, false);
            NPC.SpawnOnPlayer(player.whoAmI, mod.NPCType("Class1"));
            Main.PlaySound(15, (int)player.position.X, (int)player.position.Y, 0);
            return true;
        }


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.MechanicalEye, 1);
            recipe.AddIngredient(ItemID.Amethyst, 10);
            recipe.AddIngredient(ItemID.LunarBar, 20);
            recipe.AddIngredient(null, "EXCore", 5);
            recipe.AddIngredient(null, "OnyxBar", 10);
            recipe.AddIngredient(null, "SuperSoul", 20);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}