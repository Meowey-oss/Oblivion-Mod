﻿using Terraria.ModLoader;
using Terraria.ID;

namespace OnyxMod2.Items.item
{



    public class EXCore : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Ex Core");
            Tooltip.SetDefault("Used to craft Post-Moonlord Weapons and Items.");
        }
        public override void SetDefaults()
        {
            item.width = 30;
            item.height = 30;
            item.useStyle = -1;
            item.value = 10000;
            item.rare = -12;
            item.maxStack = 99;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.SoulofFright, 2);
            recipe.AddIngredient(ItemID.SoulofSight, 2);
            recipe.AddIngredient(ItemID.SoulofMight, 2);
            recipe.AddIngredient(null, "SoulOfRight", 2);
            recipe.AddIngredient(ItemID.FragmentSolar, 2);
            recipe.AddIngredient(ItemID.FragmentNebula, 2);
            recipe.AddIngredient(ItemID.FragmentStardust, 2);
            recipe.AddIngredient(ItemID.FragmentVortex, 2);
            recipe.AddIngredient(ItemID.ManaCrystal, 1);
            recipe.AddIngredient(ItemID.LunarBar, 1);
            recipe.AddIngredient(null, "OnyxBar", 1);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this, 2);
            recipe.AddRecipe();
        }
    }
}