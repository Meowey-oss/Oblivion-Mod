using Terraria.ModLoader;
using Terraria.ID;

namespace OnyxMod2.Items.item
{



    public class ShadowOre : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Shadow Ore");
        }
        public override void SetDefaults()
        {
            item.width = 12;
            item.height = 12;
            item.useTime = 10;
            item.useAnimation = 10;
            item.useStyle = 1;
            item.knockBack = 15f;
            item.value = 10;
            item.rare = 2;
            item.autoReuse = true;
            item.consumable = true;
            item.createTile = mod.TileType("ShadowOreTile");
            item.maxStack = 999;
        }
    }
}