using Terraria.ModLoader;
using Terraria.ID;
using Terraria;

namespace OnyxMod2.Items.item
{



    public class BossSummon4 : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Portable Bulb");
            Tooltip.SetDefault("Summons 'Plantera'.");
        }
        public override void SetDefaults()
        {
            item.width = 12;
            item.height = 12;
            item.useStyle = 4;
            item.rare = 1;
            item.useAnimation = 30;
            item.useTime = 30;
            item.maxStack = 30;
            item.consumable = true;
        }

        public override bool CanUseItem(Player player)
        {

            return !NPC.AnyNPCs(NPCID.Plantera);


        }

        public override bool UseItem(Player player)
        {
            NPC.SpawnOnPlayer(player.whoAmI, NPCID.Plantera);
            Main.PlaySound(15, (int)player.position.X, (int)player.position.Y, 0);
            return true;
        }


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "SoulOfRight", 10);
            recipe.AddIngredient(ItemID.DirtBlock, 50);
            recipe.AddIngredient(ItemID.LifeFruit, 1);
            recipe.AddIngredient(ItemID.ChlorophyteBar, 5);
            recipe.AddTile(TileID.Hellforge);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}