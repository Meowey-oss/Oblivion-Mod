﻿using Terraria.ModLoader;
using Terraria.ID;

namespace OnyxMod2.Items.item
{



    public class ShadowBar : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Shadow Bar");
        }
        public override void SetDefaults()
        {
            item.width = 12;
            item.height = 12;
            item.useStyle = -1;
            item.value = 1000;
            item.rare = 3;
            item.maxStack = 99;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "ShadowOre", 3);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}