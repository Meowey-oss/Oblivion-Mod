using Terraria.ModLoader;
using Terraria.ID;
using Terraria;

namespace OnyxMod2.Items.item
{



    public class BossSummon6 : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Missing Item");
            Tooltip.SetDefault("Summons Missing.No"+ "\nNot Consumable");
        }
        public override void SetDefaults()
        {
            item.width = 12;
            item.height = 12;
            item.useStyle = 4;
            item.rare = 7;
            item.useAnimation = 3;
            item.useTime = 3;
            item.maxStack = 1;
            item.consumable = false;
        }
        
        public override bool CanUseItem(Player player)
        {

            return !Main.dayTime && !NPC.AnyNPCs(mod.NPCType("Missingno"));

        }


        public override bool UseItem(Player player)
        {
            int[] direction = { -1, 1 };
            int rand1 = direction[Main.rand.Next(0, 1)] * Main.rand.Next(1, 2);
            int rand2 = direction[Main.rand.Next(0, 1)] * Main.rand.Next(100, 300);
            int amrerdznga = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, mod.NPCType("Missingno"), 0, 0f, 0f, 0f, 0f, 255);
            Main.PlaySound(15, (int)player.position.X, (int)player.position.Y, 0);
            return true;
        }




        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "BossSummon4", 1);
            recipe.AddIngredient(null, "BossSummon1", 1);
            recipe.AddIngredient(null, "BossSummon2", 1);
            recipe.AddIngredient(null, "SummoningItem2", 1);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}