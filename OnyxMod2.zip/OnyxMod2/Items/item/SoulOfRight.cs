using System;

using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items.item
{



    public class SoulOfRight : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Monster Soul");
            Tooltip.SetDefault("Dropped by the Undead.");
            Main.RegisterItemAnimation(item.type, new DrawAnimationVertical(6, 2));
            ItemID.Sets.ItemIconPulse[item.type] = true;

        }
        public override void SetDefaults()
        {
            item.width = 22;
            item.height = 22;
            ItemID.Sets.ItemNoGravity[item.type] = true;
            item.value = 100;
            item.rare = 4;
            item.maxStack = 999;
        }

        public override void PostUpdate()
        {
            Lighting.AddLight(item.Center, Color.Red.ToVector3() * 0.55f * Main.essScale);
        }


    }
    
}