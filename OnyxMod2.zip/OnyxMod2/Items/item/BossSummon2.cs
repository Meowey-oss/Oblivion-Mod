using Terraria.ModLoader;
using Terraria.ID;
using Terraria;

namespace OnyxMod2.Items.item
{



    public class BossSummon2 : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Lava Slime");
            Tooltip.SetDefault("Summons 'Queen Slime'.");
        }
        public override void SetDefaults()
        {
            item.width = 12;
            item.height = 12;
            item.useStyle = 4;
            item.rare = 1;
            item.useAnimation = 30;
            item.useTime = 30;
            item.maxStack = 30;
            item.consumable = true;
        }

        public override bool CanUseItem(Player player)
        {

            return !NPC.AnyNPCs(mod.NPCType("QueenSlime"));


        }

        public override bool UseItem(Player player)
        {
            Main.NewText("Music: Myuu - Final Boss", (byte)30, (byte)255, (byte)10, false);
            int[] direction = { -1, 1 };
            int rand1 = direction[Main.rand.Next(0, 1)] * Main.rand.Next(1, 2);
            int rand2 = direction[Main.rand.Next(0, 1)] * Main.rand.Next(100, 300);
            int amrerdznga = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, mod.NPCType("QueenSlime"), 0, 0f, 0f, 0f, 0f, 255);
            Main.PlaySound(15, (int)player.position.X, (int)player.position.Y, 0);
            return true;
        }


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Gel, 50);
            recipe.AddIngredient(ItemID.HellstoneBar, 2);
            recipe.AddIngredient(ItemID.GoldCrown, 1);
            recipe.AddTile(TileID.Hellforge);
            recipe.SetResult(this);
            recipe.AddRecipe();

            recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Gel, 50);
            recipe.AddIngredient(ItemID.HellstoneBar, 2);
            recipe.AddIngredient(ItemID.PlatinumCrown, 1);
            recipe.AddTile(TileID.Hellforge);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}