using System;

using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items.item
{



    public class SuperSoul : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Super Soul");
            Tooltip.SetDefault("Every Soul combined.");
            Main.RegisterItemAnimation(item.type, new DrawAnimationVertical(6, 2));
            ItemID.Sets.ItemIconPulse[item.type] = true;

        }
        public override void SetDefaults()
        {
            item.width = 22;
            item.height = 22;
            ItemID.Sets.ItemNoGravity[item.type] = true;
            item.rare = 10;
            item.maxStack = 9999;
        }

        public override void PostUpdate()
        {
            Lighting.AddLight(item.Center, Color.Red.ToVector3() * 0.55f * Main.essScale);
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.SoulofNight, 2);
            recipe.AddIngredient(ItemID.SoulofLight, 2);
            recipe.AddIngredient(ItemID.SoulofFright, 2);
            recipe.AddIngredient(ItemID.SoulofSight, 2);
            recipe.AddIngredient(ItemID.SoulofMight, 2);
            recipe.AddIngredient(null, "SoulOfRight", 2);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this, 1);
            recipe.AddRecipe();
        }


    }
    
}