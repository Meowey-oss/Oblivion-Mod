using Terraria.ModLoader;
using Terraria.ID;
using Terraria;

namespace OnyxMod2.Items.item
{



    public class BossSummon5 : ModItem
    {
        internal int DW;
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Death Wish");
            Tooltip.SetDefault("'Can you beat this?'"+ "\nSummons Every Boss Known in the Game 'No Custom Mods' (Only Oblivion Mod Bosses Included)"+"\nRightclick to change the boss you want to summon.");
        }
        public override void SetDefaults()
        {
            item.width = 12;
            item.height = 12;
            item.useStyle = 4;
            item.rare = 4;
            item.useAnimation = 30;
            item.useTime = 30;
            item.maxStack = 1;
            item.autoReuse = false;
            item.consumable = false;
            
        }
        
        public override bool CanUseItem(Player player)
        {
            return true;

        }
        
        public override bool CanRightClick()
        {
            return true;
        }
        public override bool AltFunctionUse(Player player)
        {
            return true;
        }
        public override void RightClick(Player player)
        {

        }


        public override bool UseItem(Player player)
        {

            if (player.altFunctionUse == 2)
            {
                if (DW == 0)
                {
                    DW += 1;
                    Main.NewText("All Bosses Selected.", (byte)30, (byte)255, (byte)10, false);
                }
                else if (DW == 1)
                {
                    DW += 1;
                    Main.NewText("King Slime Selected.", (byte)30, (byte)255, (byte)10, false);
                }
                else if (DW == 2)
                {
                    DW += 1;
                    Main.NewText("Eye Of Cthulhu Selected.", (byte)30, (byte)255, (byte)10, false);
                }
                else if (DW == 3)
                {
                    DW += 1;
                    Main.NewText("Eater Of Worlds Selected.", (byte)30, (byte)255, (byte)10, false);
                }
                else if (DW == 4)
                {
                    DW += 1;
                    Main.NewText("Brain Of Cthuhlu Selected.", (byte)30, (byte)255, (byte)10, false);
                }
                else if (DW == 5)
                {
                    DW += 1;
                    Main.NewText("Queen Bee Selected.", (byte)30, (byte)255, (byte)10, false);
                }
                else if (DW == 6)
                {
                    DW += 1;
                    Main.NewText("Skeletron Selected.", (byte)30, (byte)255, (byte)10, false);
                }
                else if (DW == 7)
                {
                    DW += 1;

                    Main.NewText("Wall Of Flesh Selected.", (byte)30, (byte)255, (byte)10, false);
                }
                else if (DW == 8)
                {
                    DW += 1;
                    Main.NewText("Twins Selected.", (byte)30, (byte)255, (byte)10, false);
                }
                else if (DW == 9)
                {
                    DW += 1;
                    Main.NewText("Skeletron Prime Selected.", (byte)30, (byte)255, (byte)10, false);
                }
                else if (DW == 10)
                {
                    DW += 1;
                    Main.NewText("Destroyer Selected.", (byte)30, (byte)255, (byte)10, false);
                }
                else if (DW == 11)
                {
                    DW += 1;
                    Main.NewText("Plantera Selected.", (byte)30, (byte)255, (byte)10, false);
                }
                else if (DW == 12)
                {
                    DW += 1;
                    Main.NewText("Golem Selected.", (byte)30, (byte)255, (byte)10, false);
                }
                else if (DW == 13)
                {
                    DW += 1;
                    Main.NewText("Duke Fishron Selected.", (byte)30, (byte)255, (byte)10, false);
                }
                else if (DW == 14)
                {
                    DW += 1;
                    Main.NewText("Lunatic Cultist Selected.", (byte)30, (byte)255, (byte)10, false);
                }
                else if (DW == 15)
                {
                    DW += 1;
                    Main.NewText("Moonlord Selected.", (byte)30, (byte)255, (byte)10, false);
                }
                else if (DW == 16)
                {
                    DW += 1;
                    Main.NewText("Master Control Selected.", (byte)30, (byte)255, (byte)10, false);
                }
                else if (DW == 17)
                {
                    DW += 1;
                    Main.NewText("Queen Slime Selected.", (byte)30, (byte)255, (byte)10, false);
                }
                else if (DW == 18)
                {
                    DW += 1;
                    Main.NewText("Oblivion Selected.", (byte)30, (byte)255, (byte)10, false);
                }
                else if (DW == 19)
                {
                    DW += 1;
                    Main.NewText("The Annihilator Selected.", (byte)30, (byte)255, (byte)10, false);
                }
                else if (DW == 20)
                {
                    DW += 1;
                    Main.NewText("Toxic King Slime Selected.", (byte)30, (byte)255, (byte)10, false);
                }
                else if (DW == 21)
                {
                    Main.NewText("Nothing Selected.", (byte)30, (byte)255, (byte)10, false);
                    DW = 0;
                }

            }
            else
            {
                int[] direction = { -1, 1 };
                int rand1 = direction[Main.rand.Next(0, 1)] * Main.rand.Next(500, 500);
                int rand2 = direction[Main.rand.Next(0, 1)] * Main.rand.Next(500, 500);


                if (DW == 1)
                {




                    int uaasd = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.EaterofWorldsHead, 0, 0f, 0f, 0f, 0f, 255);


                    int iuaasd = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.BrainofCthulhu, 0, 0f, 0f, 0f, 0f, 255);


                    int amrdfznwdga = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, mod.NPCType("ToxicSlimeKing"), 0, 0f, 0f, 0f, 0f, 255);
                    int iuaadsd = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.QueenBee, 0, 0f, 0f, 0f, 0f, 255);

                    int amreedznga = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.MoonLordCore, 0, 0f, 0f, 0f, 0f, 255);
                    int a = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.EyeofCthulhu, 0, 0f, 0f, 0f, 0f, 255);
                    int aa = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.KingSlime, 0, 0f, 0f, 0f, 0f, 255);
                    int aafs = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.SkeletronHead, 0, 0f, 0f, 0f, 0f, 255);
                    int asa = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.Spazmatism, 0, 0f, 0f, 0f, 0f, 255);
                    int aaaaaa = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.Retinazer, 0, 0f, 0f, 0f, 0f, 255);
                    int aaaa = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.SkeletronPrime, 0, 0f, 0f, 0f, 0f, 255);
                    int awea = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.TheDestroyer, 0, 0f, 0f, 0f, 0f, 255);
                    int abdfg = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.DukeFishron, 0, 0f, 0f, 0f, 0f, 255);
                    int ayvgda = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.Plantera, 0, 0f, 0f, 0f, 0f, 255);
                    int adum = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.Golem, 0, 0f, 0f, 0f, 0f, 255);
                    int amrdznga = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.CultistBoss, 0, 0f, 0f, 0f, 0f, 255);
                    int amserdznga = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, mod.NPCType("Class1"), 0, 0f, 0f, 0f, 0f, 255);
                    int amrdfznga = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, mod.NPCType("WormHead1"), 0, 0f, 0f, 0f, 0f, 255);
                    int amrdfzwnga = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, mod.NPCType("MasterControl"), 0, 0f, 0f, 0f, 0f, 255);
                    int amrdfznwga = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, mod.NPCType("QueenSlime"), 0, 0f, 0f, 0f, 0f, 255);
                }
                else if (DW == 2)
                {
                    int aa = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.KingSlime, 0, 0f, 0f, 0f, 0f, 255);
                }
                else if (DW == 3)
                {
                    if (!Main.dayTime)
                    {

                    int a = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.EyeofCthulhu, 0, 0f, 0f, 0f, 0f, 255);
                    }
                    else
                    {
                        Main.NewText("Can only Spawn the Eye of Cthulhu at night.", (byte)165, (byte)42, (byte)42, false);
                    }

                }
                else if (DW == 4)
                {

                    int uaasd = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.EaterofWorldsHead, 0, 0f, 0f, 0f, 0f, 255);
                }
                else if (DW == 5)
                {
                    int iuaasd = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.BrainofCthulhu, 0, 0f, 0f, 0f, 0f, 255);
                }
                else if (DW == 6)
                {
                    int iuaadsd = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.QueenBee, 0, 0f, 0f, 0f, 0f, 255);
                }
                else if (DW == 7)
                {
                    if (!Main.dayTime)
                    {


                    int aafs = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.SkeletronHead, 0, 0f, 0f, 0f, 0f, 255);
                    }
                    else
                    {
                        Main.NewText("Can only Spawn Skeletron at night.", (byte)165, (byte)42, (byte)42, false);
                    }

                    
                }
                else if (DW == 8)
                {
                    if (Main.player[Main.myPlayer].ZoneUnderworldHeight)
                    {
                        int eaafs = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.WallofFlesh, 0, 0f, 0f, 0f, 0f, 255);
                    }
                    else
                    {
                        Main.NewText("To Spawn the Wall of Flesh you need to be in the Underworld.", (byte)165, (byte)42, (byte)42, false);
                    }
                }
                else if (DW == 9)
                {
                    if (!Main.dayTime)
                    {

                  
                    int asa = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.Spazmatism, 0, 0f, 0f, 0f, 0f, 255);
                    int aaaaaa = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.Retinazer, 0, 0f, 0f, 0f, 0f, 255);
                    }
                    else
                    {
                        Main.NewText("Can only Spawn the Twins at night.", (byte)165, (byte)42, (byte)42, false);
                    }
                }
                else if (DW == 10)
                {
                    if (!Main.dayTime)
                    {

                    int aaaa = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.SkeletronPrime, 0, 0f, 0f, 0f, 0f, 255);
                    }
                    else
                    {
                        Main.NewText("Can only Spawn Skeletron Prime at night.", (byte)165, (byte)42, (byte)42, false);
                    }

                }
                else if (DW == 11)
                {
                    if (!Main.dayTime)
                    {
                    int awea = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.TheDestroyer, 0, 0f, 0f, 0f, 0f, 255);

                    }
                    else
                    {
                        Main.NewText("Can only Spawn the Destroyer at night.", (byte)165, (byte)42, (byte)42, false);
                    }

                }
                else if (DW == 12)
                {
                    int ayvgda = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.Plantera, 0, 0f, 0f, 0f, 0f, 255);
                }
                else if (DW == 13)
                {
                    int adum = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.Golem, 0, 0f, 0f, 0f, 0f, 255);
                }
                else if (DW == 14)
                {
                    int abdfg = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.DukeFishron, 0, 0f, 0f, 0f, 0f, 255);
                }
                else if (DW == 15)
                {
                    int amrdznga = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.CultistBoss, 0, 0f, 0f, 0f, 0f, 255);
                }
                else if (DW == 16)
                {
                    int amreedznga = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, NPCID.MoonLordCore, 0, 0f, 0f, 0f, 0f, 255);
                }
                else if (DW == 17)
                {
                    int amrdfzwnga = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, mod.NPCType("MasterControl"), 0, 0f, 0f, 0f, 0f, 255);
                }
                else if (DW == 18)
                {
                    int amrdfznwga = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, mod.NPCType("QueenSlime"), 0, 0f, 0f, 0f, 0f, 255);
                }
                else if (DW == 19)
                {
                    if (!Main.dayTime)
                    {
                   int amserdznga = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, mod.NPCType("Class1"), 0, 0f, 0f, 0f, 0f, 255);

                    }
                    else
                    {
                        Main.NewText("Can only Spawn Oblivion at night.", (byte)165, (byte)42, (byte)42, false);
                    }
 
                }
                else if (DW == 20)
                {
                    int amrdfznga = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, mod.NPCType("WormHead1"), 0, 0f, 0f, 0f, 0f, 255);
                }
                else if (DW == 21)
                {
                    int amrdfznga = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, mod.NPCType("ToxicSlimeKing"), 0, 0f, 0f, 0f, 0f, 255);
                }
                Main.PlaySound(15, (int)player.position.X, (int)player.position.Y, 0);
            }

            
            return true;
        }


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.SlimeCrown, 1);
            recipe.AddIngredient(ItemID.SuspiciousLookingEye, 1);
            recipe.AddIngredient(ItemID.Abeemination, 1);
            recipe.AddIngredient(ItemID.GuideVoodooDoll, 1);
            recipe.AddIngredient(ItemID.MechanicalEye, 1);
            recipe.AddIngredient(ItemID.MechanicalSkull, 1);
            recipe.AddIngredient(ItemID.MechanicalWorm, 1);
            recipe.AddIngredient(ItemID.LihzahrdPowerCell, 1);
            recipe.AddIngredient(ItemID.CelestialSigil, 1);
            recipe.AddIngredient(null, "BossSummon4", 1);
            recipe.AddIngredient(null, "BossSummon1", 1);
            recipe.AddIngredient(null, "BossSummon2", 1);
            recipe.AddIngredient(null, "SummoningItem2", 1);
            recipe.AddIngredient(null, "Toxic_Token", 1);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}