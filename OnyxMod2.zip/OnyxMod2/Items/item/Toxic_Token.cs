using Terraria.ModLoader;
using Terraria.ID;
using Terraria;

namespace OnyxMod2.Items.item
{



    public class Toxic_Token : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Toxic Galaxy Core");
            Tooltip.SetDefault("Summons 'Toxic King Slime'." +"\nNot Consumable"+"\nBreaking it would cause it to destroy the entire Universe.");
        }
        public override void SetDefaults()
        {
            item.width = 12;
            item.height = 12;
            item.useStyle = 4;
            item.rare = -12;
            item.useAnimation = 30;
            item.useTime = 30;
            item.maxStack = 1;
            item.consumable = false;
        }

        public override bool CanUseItem(Player player)
        {

            return !NPC.AnyNPCs(mod.NPCType("ToxicSlimeKing"));


        }

        public override bool UseItem(Player player)
        {
            Main.NewText("Music: Myuu - Final Boss ", (byte)30, (byte)255, (byte)10, false);
            int[] direction = { -1, 1 };
            int rand1 = direction[Main.rand.Next(0, 1)] * Main.rand.Next(1, 2);
            int rand2 = direction[Main.rand.Next(0, 1)] * Main.rand.Next(100, 300);
            int amrerdznga = NPC.NewNPC((int)player.Center.X + rand1, (int)player.Center.Y + rand2, mod.NPCType("ToxicSlimeKing"), 0, 0f, 0f, 0f, 0f, 255);
            Main.PlaySound(15, (int)player.position.X, (int)player.position.Y, 0);
            return true;
        }


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "BossSummon2", 1);
            recipe.AddIngredient(ItemID.LunarBar, 100);
            recipe.AddIngredient(null, "EXCore", 5);
            recipe.AddIngredient(null, "SuperSoul", 2);
            recipe.AddIngredient(null, "WormEye", 1);
            recipe.AddIngredient(null, "EyeShard", 5);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}