using Terraria.ModLoader;
using Terraria.ID;

namespace OnyxMod2.Items.item
{



    public class WormEye : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Eye Of The Annihilator");
        }
        public override void SetDefaults()
        {
            item.width = 12;
            item.height = 12;
            item.useStyle = -1;
            item.value = 1000;
            item.rare = 10;
            item.maxStack = 99;
        }

    }
}