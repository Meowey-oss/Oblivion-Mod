﻿using Terraria.ModLoader;
using Terraria.ID;

namespace OnyxMod2.Items.item
{



    public class BloodOre : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Blood Ore");
        }
        public override void SetDefaults()
        {
            item.width = 12;
            item.height = 12;
            item.useStyle = -1;
            item.value = 1000;
            item.rare = 8;
            item.maxStack = 999;
        }


    }
}