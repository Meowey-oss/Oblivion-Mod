﻿using Terraria.ModLoader;
using Terraria.ID;

namespace OnyxMod2.Items.item
{



    public class BloodBar : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Blood Bar");
        }
        public override void SetDefaults()
        {
            item.width = 12;
            item.height = 12;
            item.useStyle = -1;
            item.value = 1000;
            item.rare = 8;
            item.maxStack = 999;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Hellstone, 1);
            recipe.AddIngredient(ItemID.Obsidian, 1);
            recipe.AddIngredient(null, "SoulOfRight", 2);
            recipe.AddIngredient(null, "BloodOre", 2);
            recipe.AddTile(null, "BloodAltar");
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}