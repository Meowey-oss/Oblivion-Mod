using Terraria.ModLoader;
using Terraria.ID;
using Terraria;

namespace OnyxMod2.Items.item
{



    public class ChaosMode : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Chaos Wish");
            Tooltip.SetDefault("'Can you beat this?'" +"\nOnly usable in Expert Mode."+ "\nActivates a new Mode called 'Chaos Mode'" + "\nMakes Bosses a lot Harder.(For now only the Modded Oblivion Bosses) Can be toggled on and off."+ "\nDoesn't work while a boss is Active. "+ "\nNot Consumable");
        }
        public override void SetDefaults()
        {
            item.width = 12;
            item.height = 12;
            item.useStyle = ItemUseStyleID.HoldingUp;
            item.rare = ItemRarityID.LightRed;
            item.useAnimation = 30;
            item.useTime = 30;
            item.maxStack = 1;
            item.consumable = false;
        }

        public override bool CanUseItem(Player player)
        {
            return Main.expertMode && !NPC.AnyNPCs(NPCID.KingSlime) && !NPC.AnyNPCs(NPCID.EyeofCthulhu) && !NPC.AnyNPCs(NPCID.EaterofWorldsHead) && !NPC.AnyNPCs(NPCID.BrainofCthulhu) && !NPC.AnyNPCs(NPCID.QueenBee) && !NPC.AnyNPCs(NPCID.SkeletronHead) && !NPC.AnyNPCs(NPCID.WallofFlesh) && !NPC.AnyNPCs(NPCID.Spazmatism) && !NPC.AnyNPCs(NPCID.Retinazer) && !NPC.AnyNPCs(NPCID.SkeletronPrime) && !NPC.AnyNPCs(NPCID.TheDestroyer) && !NPC.AnyNPCs(NPCID.Plantera) && !NPC.AnyNPCs(NPCID.Golem) && !NPC.AnyNPCs(NPCID.CultistBoss) && !NPC.AnyNPCs(NPCID.MoonLordCore) && !NPC.AnyNPCs(mod.NPCType("Class1")) && !NPC.AnyNPCs(mod.NPCType("QueenSlime")) && !NPC.AnyNPCs(mod.NPCType("WormHead1")) && !NPC.AnyNPCs(mod.NPCType("MasterControl")) && !NPC.AnyNPCs(mod.NPCType("ToxicSlimeKing"));
        }
        public override bool UseItem(Player player)
        {
            if (MyWorld.ChaosMode == false)
            {
                Main.NewText("Chaos Mode Activated!", (byte)170, (byte)55, (byte)70, false);
                Main.PlaySound(SoundID.Roar , (int)player.position.X, (int)player.position.Y, 0);
                MyWorld.ChaosMode = true;
            }
            else
            if (MyWorld.ChaosMode == true)
            {
                Main.NewText("Chaos Mode Deactivated!", (byte)170, (byte)55, (byte)70, false);
                Main.PlaySound(SoundID.Roar , (int)player.position.X, (int)player.position.Y, 0);
                MyWorld.ChaosMode = false;
            }
            return true;
        }
        


              


               

        


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddTile(TileID.DemonAltar);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
