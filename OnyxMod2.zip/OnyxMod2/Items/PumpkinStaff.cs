﻿
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class PumpkinStaff : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Pumpking Staff");
        }

        public override void SetDefaults()
        {
            item.width = 54;
            item.knockBack = 4f;
            item.value = 1000;
            item.damage = 100;
            item.height = 54;
            item.useTime = 14;
            item.useAnimation = 14;
            item.useStyle = 5;
            item.noMelee = true;
            item.rare = 9;
            item.mana = 13;
            item.UseSound = SoundID.Item14;
            item.autoReuse = true;
            item.shootSpeed = 15.1f;
            item.magic = true;
            item.shoot = ProjectileID.FlamingJack;
        }


    }
}