﻿using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class SuperSickle : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Sickle of Death");
            Tooltip.SetDefault("Projectiles have a high chance to heal you slightly."+ "\n'Something just doesn't feel right about this.'");
        }

        public override void SetDefaults()
        {
            item.width = 50;
            item.knockBack = 2f;
            item.value = Item.buyPrice(0, 23, 0, 99);
            item.damage = 99;
            item.height = 50;
            item.useTime = 38;
            item.useAnimation = 38;
            item.useStyle = 1;
            item.noMelee = false;
            item.rare = 8;
            item.UseSound = SoundID.Item105;
            item.autoReuse = true;
            item.shoot = ModContent.ProjectileType<Projectiles.DeathSickle>();
            item.shootSpeed = 12.1f;
            item.melee = true;

        }

     

        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            float numberProjectiles = 3;
            float rotation = MathHelper.ToRadians(25);
            position += Vector2.Normalize(new Vector2(speedX, speedY)) * 10f;
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedBy(MathHelper.Lerp(-rotation, rotation, i / (numberProjectiles - 1))) * .7f;
                Projectile.NewProjectile(position.X, position.Y, perturbedSpeed.X, perturbedSpeed.Y, type, damage, knockBack, player.whoAmI);
            }
            return false;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(ItemID.DeathSickle, 1);
            recipe.AddIngredient(ItemID.LihzahrdBrick, 100);
            recipe.AddIngredient(ItemID.SoulofNight, 30);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}