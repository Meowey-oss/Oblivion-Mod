﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class Sniper1 : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Crazy Beenator");
            Tooltip.SetDefault("Can shoot a Burst of Bees and sometimes High Velocity Bullets wich deal Extra damage.");
        }

        public override void SetDefaults()
        {
            item.width = 1;
            item.knockBack = 2f;
            item.value = 100000;
            item.damage = 200;
            item.height = 1;
            item.useAnimation = 32;
            item.useTime = 8;
            item.reuseDelay = 14;
            item.useStyle = 5;
            item.knockBack = 11f;
            item.noMelee = true;
            item.rare = 9;
            item.UseSound = SoundID.Item31;
            item.autoReuse = true;
            item.shoot = 181;
            item.shootSpeed = 16.1f;
            item.ranged = true;

        }

        public override bool ConsumeAmmo(Player player)
        {
            return !(player.itemAnimation < item.useAnimation - 3);
        }

        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            if (Main.rand.Next(2) == 0)
            {
                Projectile.NewProjectile(position.X, position.Y, speedX, speedY, ProjectileID.BulletHighVelocity, (int)(item.damage * 2.0), knockBack, player.whoAmI);
            }
            return true;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.LunarBar, 10);
            recipe.AddIngredient(ItemID.FragmentNebula, 10);
            recipe.AddIngredient(ItemID.FragmentVortex, 10);
            recipe.AddIngredient(ItemID.BeeGun, 1);
            recipe.AddIngredient(null, "EXCore", 1);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
        

    }
}
