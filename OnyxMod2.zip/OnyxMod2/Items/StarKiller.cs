﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class StarKiller : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Star Killer");
            Tooltip.SetDefault("60% chance to not consume ammo");
        }

        public override void SetDefaults()
        {
            item.width = 1;
            item.knockBack = 4f;
            item.value = 1000000;
            item.damage = 100;
            item.height = 1;
            item.useTime = 9;
            item.useAnimation = 9;
            item.useStyle = 5;
            item.noMelee = true;
            item.rare = 10;
            item.useAmmo = AmmoID.FallenStar;
            item.UseSound = SoundID.Item5;
            item.autoReuse = true;
            item.shoot = 92;
            item.shootSpeed = 20.1f;
            item.ranged = true;

        }

        public override bool ConsumeAmmo(Player player)
        {
            return Main.rand.NextFloat() >= .60f;
        }

        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            float numberProjectiles = 1 + Main.rand.Next(1);
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedByRandom(MathHelper.ToRadians(5));
                Projectile.NewProjectile(position.X, position.Y, perturbedSpeed.X, perturbedSpeed.Y, type, damage, knockBack, player.whoAmI);
            }
            return false;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.StarCannon, 1);
            recipe.AddIngredient(ItemID.FallenStar, 10);
            recipe.AddIngredient(ItemID.Meteorite, 50);
            recipe.AddIngredient(ItemID.SoulofMight, 10);
            recipe.AddTile(TileID.Furnaces);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
