﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class Buff7 : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Alpha Predator");
            Description.SetDefault("Removes Nebula Buffs and Reduces Damage");
            Main.debuff[Type] = true;
            Main.pvpBuff[Type] = true;
            Main.buffNoSave[Type] = true;
        }


        public override void Update(Player player, ref int buffIndex)
        {
            player.buffImmune[BuffID.NebulaUpDmg1] = true;
            player.buffImmune[BuffID.NebulaUpDmg2] = true;
            player.buffImmune[BuffID.NebulaUpDmg3] = true;
            player.buffImmune[BuffID.NebulaUpLife1] = true;
            player.buffImmune[BuffID.NebulaUpLife2] = true;
            player.buffImmune[BuffID.NebulaUpLife3] = true;
            player.buffImmune[BuffID.NebulaUpMana1] = true;
            player.buffImmune[BuffID.NebulaUpMana2] = true;
            player.buffImmune[BuffID.NebulaUpMana3] = true;
            player.minionDamage -= 0.20f;
            player.rangedDamage -= 0.30f;
        }

    }
}
