﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class MagicBoom : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Magic Exploder");
        
        }

        public override void SetDefaults()
        {
            item.width = 1;
            item.knockBack = 8f;
            item.value = 1000000;
            item.damage = 200;
            item.height = 1;
            item.useTime = 21;
            item.useAnimation = 21;
            item.useStyle = ItemUseStyleID.HoldingOut;
            item.noMelee = true;
            item.rare = ItemRarityID.Cyan;
            item.UseSound = SoundID.Item25;
            item.autoReuse = true;
            item.shoot = ModContent.ProjectileType<Projectiles.ExMboom>();
            item.shootSpeed = 15.1f;
            item.mana = 23;
            item.magic = true;

        }

        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            float numberProjectiles = 2;
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedByRandom(MathHelper.ToRadians(3));
                Projectile.NewProjectile(position.X, position.Y, perturbedSpeed.X, perturbedSpeed.Y, type, damage, knockBack, player.whoAmI);
            }
            return false;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.FragmentStardust, 20);
            recipe.AddIngredient(ItemID.Sapphire, 15);
            recipe.AddIngredient(ItemID.StaffofEarth, 1);
            recipe.AddIngredient(null, ("EXCore"), 1);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }



    }
}
