﻿using Terraria.ModLoader;
using Terraria.ID;
using Terraria;

namespace OnyxMod2.Items
{



    public class ShadowCrate : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Shadow Crate");
            Tooltip.SetDefault("Right Click To Open" + "\nCan drop Pre-Hardmode Stuff. (And some Hardmode aswell.)");
        }
        public override void SetDefaults()
        {
            item.width = 12;
            item.height = 12;
            item.useStyle = -1;
            item.consumable = true;
            item.rare = 6;
            item.maxStack = 200;
        }

        public override bool CanRightClick()
        {
            return true;
        }

        public override void RightClick(Player player)
        {

        
        
            if (Main.rand.Next(5) == 0)
            {
                player.QuickSpawnItem(ItemID.CopperBar, Main.rand.Next(1, 2));
            }

            if (Main.rand.Next(5) == 0)
            {
                player.QuickSpawnItem(ItemID.IronBar, Main.rand.Next(1, 2));
            }

            if (Main.rand.Next(5) == 0)
            {
                player.QuickSpawnItem(ItemID.LeadBar, Main.rand.Next(1, 2));
            }

            if (Main.rand.Next(5) == 0)
            {
                player.QuickSpawnItem(ItemID.GoldBar, Main.rand.Next(1, 2));
            }


            if (Main.rand.Next(200) == 0)
            {
                Main.NewText("You got a Rare item out of the Shadow Crate! ", 55, 153, 155);
                player.QuickSpawnItem(ItemID.DemoniteBar, Main.rand.Next(3, 5));
            }
           
           else if (Main.rand.Next(200) == 0)
           {
                Main.NewText("You got a Rare item out of the Shadow Crate! ", 55, 153, 155);
                player.QuickSpawnItem(ItemID.CrimtaneBar, Main.rand.Next(3, 5));
           }
            
            else if (Main.rand.Next(200) == 0)
            {
                Main.NewText("You got a Rare item out of the Shadow Crate! ", 55, 153, 155);
                player.QuickSpawnItem(ItemID.HellstoneBar, Main.rand.Next(3, 5));
            }

            else if (Main.rand.Next(200) == 0)
            {
                Main.NewText("You got a Rare item out of the Shadow Crate! ", 55, 153, 155);
                player.QuickSpawnItem(ItemID.SuspiciousLookingEye, Main.rand.Next(1, 2));
            }
            else if (Main.rand.Next(200) == 0)
            {
                Main.NewText("You got a Rare item out of the Shadow Crate! ", 55, 153, 155);
                player.QuickSpawnItem(ItemID.GuideVoodooDoll, Main.rand.Next(1, 2));
            }
            else if (Main.rand.Next(300) == 0)
            {
                Main.NewText("You got a Very Rare item out of the Shadow Crate! ", 55, 153, 155);
                player.QuickSpawnItem(ItemID.ClothierVoodooDoll, Main.rand.Next(1, 2));
            }
            else if (Main.rand.Next(300) == 0)
            {
                Main.NewText("You got a Very Rare item out of the Shadow Crate! GG", 35, 153, 125);
                player.QuickSpawnItem(ItemID.SuperHealingPotion, Main.rand.Next(1, 2));
            }

            else if (Main.rand.Next(300) == 0)
            {
                Main.NewText("You got a Very Rare item out of the Shadow Crate! GG", 35, 153, 125);
                player.QuickSpawnItem(mod.ItemType("ShadowCrate"), Main.rand.Next(5, 10));
            }

            else if (Main.rand.Next(600) == 0)
            {
                Main.NewText("You got a Legendary Rare item out of the Shadow Crate! GG", 65, 153, 125);
                player.QuickSpawnItem(mod.ItemType("DreamCrusher"));
            }

            else if (Main.rand.Next(600) == 0)
            {
                Main.NewText("You got a Legendary Rare item out of the Shadow Crate! GG", 65, 153, 125);
                player.QuickSpawnItem(mod.ItemType("Minigun"));
            }

            player.QuickSpawnItem(ItemID.CopperCoin, Main.rand.Next(10, 20));
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(null, "ShadowBar", 5);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this, 10);
            recipe.AddRecipe();
        }
    }
}