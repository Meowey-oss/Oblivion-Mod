﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class Thrown2 : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("P.H.W.");
            Tooltip.SetDefault("Metal Arrows can inflict Acient Curse."+ "\nP.H.W. = Precise Homing Weapon");
        }

        public override void SetDefaults()
        {
            item.width = 40;
            item.knockBack = 2f;
            item.value = 1000000;
            item.damage = 210;
            item.height = 80;
            item.useTime = 34;
            item.useAnimation = 34;
            item.useStyle = 2;
            item.knockBack = 1f;
            item.noUseGraphic = true;
            item.noMelee = true;
            item.rare = 9;
            item.consumable = false;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.shoot = ModContent.ProjectileType<Projectiles.ThrownProjectile2>();
            item.shootSpeed = 15.7f;
            item.thrown = true;
        }


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.LunarBar, 10);
            recipe.AddIngredient(ItemID.FragmentNebula, 10);
            recipe.AddIngredient(ItemID.FragmentVortex, 10);
            recipe.AddIngredient(ItemID.Shuriken, 100);
            recipe.AddIngredient(null, "EXCore", 1);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}