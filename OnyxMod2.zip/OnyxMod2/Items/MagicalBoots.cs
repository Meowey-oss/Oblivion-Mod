
using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;

namespace OnyxMod2.Items
{

    public class MagicalBoots : ModItem
    {
        internal int led;
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Magical Tracer");
            Tooltip.SetDefault("You gain 10% Movement Speed and 5% Crit Chance" + "\nSummons lunar flares when hit."+ "\n'AKA Moon Boots.'");
        }

        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = Item.buyPrice(0, 7, 0, 0);
            item.rare = 9;
            item.accessory = true;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            MyPlayer modPlayer = MyPlayer.Get(player);
            modPlayer.Lol = true;
            player.accRunSpeed = 8f;
            player.moveSpeed += 0.10f;
            player.magicCrit += 5;
            player.meleeCrit += 5;
            player.rangedCrit += 5;
            player.thrownCrit += 5;



        }
   
      
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(null, "EyeShard", 3);
            recipe.AddIngredient(null, "OnyxBar", 7);
            recipe.AddIngredient(null, "RingofMoonlight", 1);
            recipe.AddIngredient(ItemID.PixieDust, 20);
            recipe.AddIngredient(null, "WormEye", 1);
            recipe.AddIngredient(ItemID.LunarFlareBook, 1);
            recipe.AddIngredient(ItemID.FrostsparkBoots, 1);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
