using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class Minigun : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Stingy Gun");
            Tooltip.SetDefault("Shoots deadly stingers wich can linger on the enemy and dealing extra damage.");
        }

        public override void SetDefaults()
        {
            item.width = 1;
            item.knockBack = 1f;
            item.value = Item.buyPrice(1, 0, 0, 0);
            item.damage = 13;
            item.height = 1;
            item.useTime = 26;
            item.useAnimation = 26;
            item.useStyle = 5;
            item.noMelee = true;
            item.rare = 4;
            item.UseSound = SoundID.Item10;
            item.autoReuse = true;
            item.shoot = ModContent.ProjectileType<Projectiles.BBP>();
            item.shootSpeed = 7.1f;
            item.ranged = true;

        }

        public override bool ConsumeAmmo(Player player)
        {
            return Main.rand.NextFloat() >= .1f;
        }

        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            float numberProjectiles = 1;
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedByRandom(MathHelper.ToRadians(7));
                Projectile.NewProjectile(position.X, position.Y, perturbedSpeed.X, perturbedSpeed.Y, type, damage, knockBack, player.whoAmI);
            }
            return false;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.IronBar, 7);
            recipe.anyIronBar = true;
            recipe.AddIngredient(null, "BloodOre", 20);
            recipe.AddIngredient(null, "CrystalOre", 25);
            recipe.AddIngredient(null, "ShadowBar", 5);
            recipe.AddTile(null, "BloodAltar");
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
