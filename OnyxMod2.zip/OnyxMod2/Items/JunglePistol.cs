using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
namespace OnyxMod2.Items
{
    public class JunglePistol : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Jungle Pistol");
            Tooltip.SetDefault("Can shoot Spores wich explodes into Leafes" + "\nLegendary");
        }
        public override void SetDefaults()
        {
            item.damage = 190;
            item.ranged = true;
            item.width = 60;
            item.height = 68;
            item.useTime = 22;
            item.useAnimation = 22;
            item.useStyle = 5;
            item.knockBack = 4f;
            item.value = 200000;
            item.rare = -12;
            item.shootSpeed = 20f;
            item.UseSound = SoundID.Item33;
            item.shoot = ModContent.ProjectileType<Projectiles.LProj1>();
            item.autoReuse = true;
            

        }




    }
}
