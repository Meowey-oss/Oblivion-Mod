using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class InfinityStone : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Infinity Stone");
            Tooltip.SetDefault("All Stones combined. When you reach 0 Hp you get revived and start at 250Hp."+ "\nRequires cooldown." + "\nMakes you Immune to Lava, 'OnFire', 'Slow', 'BrokenArmor', 'Confused', 'Venom', 'Poisoned' and 'Darkness'.");
        }

        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.defense = 15;
            item.shoot = mod.ProjectileType("Bullet2");
            item.rare = -12;
            item.value = Item.buyPrice(0, 8, 0, 0);
            item.accessory = true;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.buffImmune[BuffID.Darkness] = true;
            player.buffImmune[BuffID.BrokenArmor] = true;
            player.buffImmune[BuffID.Poisoned] = true;
            player.buffImmune[BuffID.Venom] = true;
            player.buffImmune[BuffID.Confused] = true;
            player.buffImmune[BuffID.Slow] = true;
            player.buffImmune[BuffID.OnFire] = true;
            player.lavaImmune = true;
            player.moveSpeed += 6f;
            MyPlayer.ee = true;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(null, "FireStone", 1);
            recipe.AddIngredient(null, "JungleStone", 1);
            recipe.AddIngredient(null, "ElectricalStone", 1);
            recipe.AddIngredient(null, "DungeonStone", 1);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}