using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class BurningShield : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Burning Shield");
            Tooltip.SetDefault("You gain the immunity against Many Fire Effects, Fall Damage and Knockback" + "\nEnemies take damage half of the contact damage they did to you.");
        }

        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.defense = 8;
            item.value = Item.buyPrice(0, 7, 0, 0);
            item.rare = 7;
            item.accessory = true;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            if (player.thorns < 1f)
            {
                player.thorns = 0.5f;
            }
            player.noFallDmg = true;
            player.noKnockback = true;
            player.buffImmune[BuffID.OnFire] = true;
            player.buffImmune[BuffID.Burning] = true;
            player.buffImmune[BuffID.Weak] = true;
            player.lavaImmune = true;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(null, "Accessories4", 1);
            recipe.AddIngredient(ItemID.AnkhShield, 1);
            recipe.AddTile(TileID.TinkerersWorkbench);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}