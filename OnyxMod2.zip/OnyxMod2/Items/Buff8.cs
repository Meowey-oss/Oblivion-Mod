﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class Buff8 : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Revived");
            Description.SetDefault("Can't get revived again.");
            Main.debuff[Type] = true;
            Main.pvpBuff[Type] = true;
            Main.buffNoSave[Type] = true;
        }
        public override void Update(Player player, ref int buffIndex)
        {
            int num1 = Dust.NewDust(player.position, player.width, player.height, DustID.SomethingRed);
            Main.dust[num1].scale = 1.2f;
            Main.dust[num1].velocity *= 3f;
            Main.dust[num1].noGravity = true;
            MyPlayer.em = true;
        }
    }

    
}
