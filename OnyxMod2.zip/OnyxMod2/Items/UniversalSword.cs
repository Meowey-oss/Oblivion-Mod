﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class UniversalSword : ModItem
    {
        internal int MEM;
        internal int lel;
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Universal Sword");
            Tooltip.SetDefault("Insanely heals the player on melee Strike with cooldown."+"\nShoots one projectile splitting into more homing projectiles.");
        }
        public override void SetDefaults()
        {
            item.damage = 660;
            item.melee = true;
            item.width = 100;
            item.height = 100;
            item.useTime = 8;
            item.useAnimation = 8;
            item.useStyle = ItemUseStyleID.SwingThrow;
            item.knockBack = 7f;
            item.value = 1000000;
            item.rare = -12;
            item.shootSpeed = 11f;
            item.shoot = ModContent.ProjectileType<Projectiles.NOTHING>();
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
        }
        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            if (player.ownedProjectileCounts[ModContent.ProjectileType<Projectiles.UniversalProj>()] < 1 && player.ownedProjectileCounts[ModContent.ProjectileType<Projectiles.UniversalProj2>()] < 1)
            {

                    Projectile.NewProjectile(position.X, position.Y, speedX, speedY, mod.ProjectileType("UniversalProj"), damage + 800, knockBack, player.whoAmI);

            }
            return base.Shoot(player, ref position, ref speedX, ref speedY, ref type, ref damage, ref knockBack);
        }
        public override void OnHitNPC(Player player, NPC target, int damage, float knockback, bool crit)
        {
            if (MEM <= 1)
            {
                int lifeSteal = 30;
                player.statLife += lifeSteal;
                player.HealEffect(lifeSteal);
                MEM = 30;
            }
            if (MEM >= 0)
            {
                MEM--;
            }
        }



    }
}
