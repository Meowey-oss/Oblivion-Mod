﻿using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class BulletBall7 : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Lunatic Bullet Ball");
        }

        public override void SetDefaults()
        {
            item.width = 50;
            item.knockBack = 2f;
            item.value = Item.buyPrice(0, 80, 0, 0);
            item.damage = 160;
            item.height = 50;
            item.useTime = 98;
            item.useAnimation = 98;
            item.useStyle = 5;
            item.noMelee = true;
            item.noUseGraphic = true;
            item.rare = 7;
            item.shoot = mod.ProjectileType("BB7");
            item.UseSound = SoundID.Item17;
            item.autoReuse = true;
            item.shootSpeed = 19.1f;
            item.ranged = true;

        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(ItemID.Wood, 100);
            recipe.AddIngredient(ItemID.ShroomiteBar, 10);
            recipe.AddIngredient(ItemID.FragmentVortex, 20);
            recipe.AddIngredient(null, ("BulletBall6"), 1);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}