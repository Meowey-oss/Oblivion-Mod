using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class Bullet4 : ModItem
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Bouncy Bullet");
        }

        public override void SetDefaults()
        {
            item.damage = 10;
            item.ranged = true;
            item.width = 1;
            item.maxStack = 999;
            item.consumable = true;
            item.ammo = 97;
            item.height = 1;
            item.knockBack = 9f;
            item.value = 100;
            item.shoot = mod.ProjectileType("Bullet3");
            item.shootSpeed = 18.1f;
            item.rare = 4;
            item.UseSound = SoundID.Item1;

        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.SilverBullet, 75);
            recipe.AddIngredient(ItemID.PinkGel, 10);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this, 75);
            recipe.AddRecipe();
        }

    }
}
