﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    [AutoloadEquip(EquipType.Body)]
    public class ArmorBreastplate3 : ModItem
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Crystal Chestplate");
            Tooltip.SetDefault("+12% Thrown Damage.");
        } 

        public override void SetDefaults()
        {
            item.width = 41;
            item.height = 40;
            item.value = 100000;
            item.rare = 3;
            item.defense = 5;
        }

        public override bool IsArmorSet(Item head, Item body, Item legs)
        {
            return body.type == mod.ItemType("ArmorHead3") && legs.type == mod.ItemType("ArmorBoots3");
        }



        public override void UpdateEquip(Player player)
        {
            player.thrownDamage += 0.12f;
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "Immunity to some Ice Debuffs" + "\nSummons Icebolts when hit." + "\n+10% Thrown Damage";
            player.thrownDamage += 0.10f;
            player.buffImmune[BuffID.Frozen] = true;
            player.buffImmune[BuffID.Frostburn] = true;
            MyPlayer modPlayer = MyPlayer.Get(player);
            modPlayer.mem = true;
        }




        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "CrystalOre", 50);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
