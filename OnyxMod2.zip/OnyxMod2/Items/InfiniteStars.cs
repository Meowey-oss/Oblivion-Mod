﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class InfiniteStars : ModItem
    {
        internal int OOF;
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Endless Bag of Stars");
            Tooltip.SetDefault("The power of Infinity causes the attack damage to decrease by half and you cant crit with the ranged class anymore."+"\nCounts for all Ranged Weapons as long as you have it in your inventory.");
        }

        public override void SetDefaults()
        {
            item.damage = 1;
            item.ranged = true;
            item.width = 30;
            item.maxStack = 1;
            item.consumable = false;
            item.ammo = ItemID.FallenStar;
            item.height = 30;
            item.value = 10000;
            item.rare = ItemRarityID.Green;
            item.UseSound = SoundID.Item1;

        }
        public override void UpdateInventory(Player player)
        {
            player.rangedCrit -= 1000;
            player.rangedDamage /= 2;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(ItemID.FallenStar, 3);
            recipe.AddIngredient(ItemID.HallowedBar, 30);
            recipe.AddIngredient(ItemID.Diamond, 1);
            recipe.AddIngredient(null, "InfinityCoin", 1);
            recipe.AddTile(null, "BloodAltar");
            recipe.SetResult(this, 1);
            recipe.AddRecipe();
        }

    }
}
