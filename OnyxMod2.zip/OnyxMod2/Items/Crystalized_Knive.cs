﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
namespace OnyxMod2.Items
{
    public class Crystalized_Knive : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Crystalized Knife");
            Tooltip.SetDefault("10% chance to heal the player and applies the 'Crystalized' Effect on the player when striking an enemy.");
        }
        public override void SetDefaults()
        {
            item.damage = 16;
            item.melee = true;
            item.width = 36;
            item.height = 36;
            item.useTime = 8;
            item.useAnimation = 8;
            item.useStyle = 1;
            item.knockBack = 9f;
            item.value = Item.buyPrice(0, 12, 0, 0);
            item.rare = 6;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
        }

        public override void OnHitNPC(Player player, NPC target, int damage, float knockback, bool crit)
        {
            player.AddBuff(mod.BuffType("Buff6"), 60);
            if (Main.rand.Next(10) == 0)
          {
                player.statLife += 1;
                player.HealEffect(1);
          }

        }

        
     
        

    }
}
