using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class Heavy_Grenade : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Heavy Grenade");
            Tooltip.SetDefault("Upgraded Version");
        }

        public override void SetDefaults()
        {
            item.width = 1;
            item.knockBack = 12f;
            item.value = 2000;
            item.damage = 18;
            item.height = 1;
            item.useTime = 35;
            item.useAnimation = 35;
            item.useStyle = 2;
            item.noUseGraphic = true;
            item.noMelee = true;
            item.maxStack = 999;
            item.consumable = true;
            item.rare = 5;
            item.UseSound = SoundID.Item7;
            item.autoReuse = true;
            item.shoot = ModContent.ProjectileType<Projectiles.GProj2>();
            item.shootSpeed = 12.1f;
            item.thrown = true;

        }


  

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Grenade, 10);
            recipe.AddIngredient(ItemID.Dynamite, 1);
            recipe.AddIngredient(null, "BloodOre", 2);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}