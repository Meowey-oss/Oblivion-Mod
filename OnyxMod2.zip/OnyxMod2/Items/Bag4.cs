using Terraria.ModLoader;
using Terraria.ID;
using Terraria;

namespace OnyxMod2.Items
{



    public class Bag4 : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Treasure Bag");
            Tooltip.SetDefault("Right Click To Open"+ "\nThe Boss Can Drop:" + "\nOne of 4 Different Items/Weapons with an 100% chance" + "\nRandom amount of Gel");
        }
        public override void SetDefaults()
        {
            item.width = 12;
            item.height = 12;
            item.useStyle = -1;
            
            item.consumable = true;
            item.rare = -12;
            item.maxStack = 30;
        }

        public override bool CanRightClick()
        {
            return true;
        }

        public override void RightClick(Player player)
        {
            int choice = Main.rand.Next(4);

            if (choice == 0)
            {
                player.QuickSpawnItem(mod.ItemType("DevSickle"));
            }

            if (choice == 1)
            {
                player.QuickSpawnItem(mod.ItemType("Doomsday"));
            }

            if (choice == 2)
            {
                player.QuickSpawnItem(mod.ItemType("Supernova"));
            }

            if (choice == 3)
            {
                player.QuickSpawnItem(mod.ItemType("UniversalSword"));
            }
            player.QuickSpawnItem(ItemID.Gel, Main.rand.Next(50, 80));
            player.QuickSpawnItem(ItemID.GoldCoin, Main.rand.Next(30, 45));
        }

    }
}