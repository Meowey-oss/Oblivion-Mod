﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class CWormscarf : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Corrupted Worm Scarf");
            Tooltip.SetDefault("You gain 19% damage reduction but you lose 10% attack damage.");
        }

        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = Item.buyPrice(0, 2, 0, 0);
            item.rare = -12;
            item.expertOnly = true;
            item.expert = true;
            item.accessory = true;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.magicDamage -= 0.10f;
            player.meleeDamage -= 0.10f;
            player.minionDamage -= 0.10f;
            player.rangedDamage -= 0.10f;
            player.thrownDamage -= 0.10f;
            player.endurance += 0.19f;
        }

       



    }
}