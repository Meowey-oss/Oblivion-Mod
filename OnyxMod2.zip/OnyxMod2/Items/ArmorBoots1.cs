﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    [AutoloadEquip(EquipType.Legs)]
    public class ArmorBoots1 : ModItem
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Oblivion Boots");
            Tooltip.SetDefault("+10% Damage and 7% crit chance to all classes except for Summoner" + "\nAlso gives you +40% Movement Speed");
        }

        public override void SetDefaults()
        {
            item.width = 41;
            item.height = 40;
            item.value = 100000;
            item.rare = 9;
            item.defense = 20;
        }

        public override bool IsArmorSet(Item head, Item body, Item legs)
        {
            return head.type == mod.ItemType("ArmorHelmet1") && body.type == mod.ItemType("ArmorBreastplate1");
        }



        public override void UpdateEquip(Player player)
        {
            player.magicDamage += 0.10f;
            player.thrownDamage += 0.10f;
            player.meleeDamage += 0.10f;
            player.rangedDamage += 0.10f;
            player.moveSpeed += 0.40f;
            player.magicCrit += 7;
            player.thrownCrit += 7;
            player.meleeCrit += 7;
            player.rangedCrit += 7;
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+20% Attack Damage to all classes except for Summoner" + "\nImmunity to 'Venom','OnFire','CursedInferno' and 'Lava'";
            player.magicDamage += 0.20f;
            player.thrownDamage += 0.20f;
            player.meleeDamage += 0.20f;
            player.rangedDamage += 0.20f;
            player.lavaImmune = true;
            player.buffImmune[BuffID.Venom] = true;
            player.buffImmune[BuffID.OnFire] = true;
            player.buffImmune[BuffID.CursedInferno] = true;
        }




        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(null, "OnyxBar", 15);
            recipe.AddIngredient(null, "EXCore", 5);
            recipe.AddIngredient(null, "WormEye", 1);
            recipe.AddIngredient(null, "EyeShard", 2);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }


    }
}
