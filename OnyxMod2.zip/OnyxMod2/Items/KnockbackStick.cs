﻿using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class KnockbackStick : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Knockback Stick");
            Tooltip.SetDefault("Let enemies fly...");
        }
        public override void SetDefaults()
        {
            item.damage = 2;
            item.melee = true;
            item.width = 30;
            item.height = 30;
            item.useTime = 6;
            item.useAnimation = 6;
            item.useStyle = 1;
            item.knockBack = 95f;
            item.value = 34880;
            item.rare = 11;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(ItemID.Wood, 10);
            recipe.AddIngredient(ItemID.TitanGlove, 1);
            recipe.AddIngredient(ItemID.SlapHand, 1);
            recipe.AddIngredient(null, "BloodBar", 3);
            recipe.AddTile(null, "BloodAltar");
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
