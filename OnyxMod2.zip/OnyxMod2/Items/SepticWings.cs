using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace OnyxMod2.Items
{
    [AutoloadEquip(EquipType.Wings)]
    public class SepticWings : ModItem
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Septic Wings");
            Tooltip.SetDefault("'I believe i can fly!'" + "\nMax Flight Time: 300" + "\nAcceleration Multiplier: 1" + "\nHorizontal Speed: 9");
        }

        public override void SetDefaults()
        {
            item.width = 22;
            item.height = 20;
            item.value = 10;
            item.rare = 9;
            item.accessory = true;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.wingTimeMax = 300; 
        }

        public override void VerticalWingSpeeds(Player player, ref float ascentWhenFalling, ref float ascentWhenRising,
            ref float maxCanAscendMultiplier, ref float maxAscentMultiplier, ref float constantAscend)
        {
            ascentWhenFalling = 2f;
            ascentWhenRising = 2f;
            maxCanAscendMultiplier = 1f;
            maxAscentMultiplier = 3f;
            constantAscend = 0.235f;
        }

        public override void HorizontalWingSpeeds(Player player, ref float speed, ref float acceleration)
        {
            speed = 9f;
            acceleration *= 1f;
        }

        public override void AddRecipes()  //How to craft this item
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "OnyxBar", 15);
            recipe.AddIngredient(null, "EXCore", 3);
            recipe.AddIngredient(null, "EyeShard", 7);
            recipe.AddIngredient(null, "WormEye", 1);
            recipe.AddIngredient(ItemID.SoulofFlight, 30);
            recipe.AddTile(TileID.LunarCraftingStation);   //at work bench
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}