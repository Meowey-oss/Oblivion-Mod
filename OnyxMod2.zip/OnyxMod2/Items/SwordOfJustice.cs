using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
namespace OnyxMod2.Items
{
    public class SwordOfJustice : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Sword Of Justice");
            Tooltip.SetDefault("Can inflict Ancient Curse on Melee hit."+ "\nLegendary");
        }
        public override void SetDefaults()
        {
            item.damage = 42;
            item.melee = true;
            item.width = 52;
            item.height = 52;
            item.useTime = 11;
            item.useAnimation = 11;
            item.useStyle = 1;
            item.knockBack = 7f;
            item.value = 1000;
            item.rare = -12;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;



        }


        public override void OnHitPvp(Player player, Player target, int damage, bool crit)
        {
            player.AddBuff(mod.BuffType("Buff4"), 900);
        }


        public override void OnHitNPC(Player player, NPC target, int damage, float knockback, bool crit)
        {
            target.AddBuff(mod.BuffType("Buff4"), 900);
        }
    }
}





