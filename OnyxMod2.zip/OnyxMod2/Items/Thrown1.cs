﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class Thrown1 : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Mysterious Bone");
            Tooltip.SetDefault("'Do you just like the feeling of your sins crawling on your back?'");
        }

        public override void SetDefaults()
        {
            item.width = 30;
            item.knockBack = 2f;
            item.value = 1000000;
            item.damage = 315;
            item.height = 30;
            item.useTime = 14;
            item.useAnimation = 14;
            item.useStyle = 2;
            item.knockBack = 1f;
            item.noUseGraphic = true;
            item.noMelee = true;
            item.rare = 9;
            item.consumable = false;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.shoot = ModContent.ProjectileType<Projectiles.ThrownProjectile1>();
            item.shootSpeed = 26.7f;
            item.thrown = true;
            
        }


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.LunarBar, 10);
            recipe.AddIngredient(ItemID.FragmentNebula, 10);
            recipe.AddIngredient(ItemID.FragmentSolar, 10);
            recipe.AddIngredient(ItemID.Bone, 100);
            recipe.AddIngredient(null, "EXCore", 1);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}