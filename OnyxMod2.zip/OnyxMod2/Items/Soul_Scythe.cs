﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
namespace OnyxMod2.Items
{
    public class Soul_Scythe : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Soul Scythe");
            Tooltip.SetDefault("Releases a powerful effect on melee hit wich drains your life."+ "\nLegendary");
        }
        public override void SetDefaults()
        {
            item.damage = 53;
            item.melee = true;
            item.width = 92;
            item.height = 78;
            item.useTime = 30;
            item.useAnimation = 30;
            item.useStyle = 1;
            item.knockBack = 1f;
            item.value = 200000;
            item.rare = -12;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
        }


        public override void OnHitNPC(Player player, NPC target, int damage, float knockback, bool crit)
        {
            int lifeSteal = -5;
            player.statLife += lifeSteal;
            player.HealEffect(lifeSteal);
            target.AddBuff(mod.BuffType("Buff5"), 250);
        }

    }
}
