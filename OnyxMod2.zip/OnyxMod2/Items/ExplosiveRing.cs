
using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;

namespace OnyxMod2.Items
{

    public class ExplosiveRing : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Explosive Ring");
            Tooltip.SetDefault("\nSummons Explosions when hurt."+ "\n'Oof'" + "\nLegendary");
        }

        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = Item.buyPrice(0, 6, 6, 6);
            item.rare = -12;
            item.accessory = true;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            MyPlayer modPlayer = MyPlayer.Get(player);
            modPlayer.no = true;



        }
   
      

    }
}
