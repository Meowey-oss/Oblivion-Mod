﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class Holy : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Holy Blaster");
            
        }

        public override void SetDefaults()
        {
            item.width = 60;
            item.knockBack = 2f;
            item.value = Item.buyPrice(1, 0, 0, 0);
            item.damage = 600;
            item.height = 30;
            item.useTime = 28;
            item.useAnimation = 28;
            item.useAmmo = ItemID.FallenStar;
            item.useStyle = ItemUseStyleID.HoldingOut;
            item.noMelee = true;
            item.rare = ItemRarityID.Cyan;
            item.UseSound = SoundID.Item12;
            item.autoReuse = true;
            item.shoot = ModContent.ProjectileType<Projectiles.HolyP1>();
            item.shootSpeed = 20.1f;
            item.ranged = true;
            

        }


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "StarMelter", 1);
            recipe.AddIngredient(ItemID.LunarBar, 20);
            recipe.AddIngredient(ItemID.GoldCoin, 5);
            recipe.AddIngredient(null, "WormEye", 1);
            recipe.AddIngredient(null, "EXCore", 3);
            recipe.AddIngredient(null, "EyeShard", 15);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
