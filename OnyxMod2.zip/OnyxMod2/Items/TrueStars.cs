﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class TrueStars : ModItem
    {
        internal int OOF;
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("True Endless Bag of Stars");
            Tooltip.SetDefault("The True Endless Bag of Stars will provide you with an endless amount of stars.");
        }

        public override void SetDefaults()
        {
            item.damage = 1;
            item.ranged = true;
            item.width = 30;
            item.maxStack = 1;
            item.consumable = false;
            item.ammo = ItemID.FallenStar;
            item.height = 30;
            item.value = 100000;
            item.rare = ItemRarityID.Cyan;
            item.UseSound = SoundID.Item1;

        }
        public override void UpdateInventory(Player player)
        {
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(ItemID.FallenStar, 50);
            recipe.AddIngredient(mod.ItemType("InfiniteStars"), 1);
            recipe.AddIngredient(ItemID.LunarBar, 20);
            recipe.AddIngredient(null, "InfinityCoin", 1);
            recipe.AddTile(null, "BloodAltar");
            recipe.SetResult(this, 1);
            recipe.AddRecipe();
        }

    }
}
