﻿using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class UltimateTerraBlade : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Ultimate Terra Blade");
            Tooltip.SetDefault("Projectiles can inflict Frostbite.");
        }
        public override void SetDefaults()
        {
            item.damage = 260;
            item.melee = true;
            item.width = 100;
            item.height = 100;
            item.useTime = 16;
            item.useAnimation = 16;
            item.useStyle = 1;
            item.knockBack = 13f;
            item.value = 10000;
            item.shoot = ModContent.ProjectileType<Projectiles.SwordProjectile2>();
            item.shootSpeed = 17.1f;
            item.rare = -12;
            item.UseSound = SoundID.Item25;
            item.autoReuse = true;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.TerraBlade, 1);
            recipe.AddIngredient(ItemID.BreakerBlade, 1);
            recipe.AddIngredient(ItemID.ChristmasTreeSword, 1);
            recipe.AddIngredient(ItemID.Frostbrand, 1);
            recipe.AddIngredient(ItemID.InfluxWaver, 1);
            recipe.AddIngredient(ItemID.Keybrand, 1);
            recipe.AddIngredient(ItemID.Seedler, 1);
            recipe.AddIngredient(ItemID.TheHorsemansBlade, 1);
            recipe.AddIngredient(ItemID.CrystalStorm, 1);
            recipe.AddIngredient(ItemID.FragmentStardust, 20);
            recipe.AddIngredient(ItemID.BrokenHeroSword, 3);
            recipe.AddTile(TileID.AdamantiteForge);
            recipe.SetResult(this);
            recipe.AddRecipe();
        

        }

    }
}
