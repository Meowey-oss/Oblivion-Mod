﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class Bullet3 : ModItem
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Hell Bullet");
            Tooltip.SetDefault("If it hits a Block, it will release an Inferno.");
        }

        public override void SetDefaults()
        {
            item.damage = 9;
            item.ranged = true;
            item.width = 1;
            item.maxStack = 999;
            item.consumable = true;
            item.ammo = 97;
            item.height = 1;
            item.knockBack = 3f;
            item.value = 100;
            item.shoot = mod.ProjectileType("Bullet2");
            item.shootSpeed = 20.1f;
            item.rare = 2;
            item.UseSound = SoundID.Item1;

        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(null, "BloodBar", 1);
            recipe.AddIngredient(null, "BloodOre", 2);
            recipe.AddIngredient(ItemID.SoulofNight, 1);
            recipe.AddTile(null, "BloodAltar");
            recipe.SetResult(this, 50);
            recipe.AddRecipe();
        }

    }
}
