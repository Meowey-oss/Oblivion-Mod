using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace OnyxMod2.Items
{

    public class MagicalHeart : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Magical Heart");
            Tooltip.SetDefault("You can feel the power of the Magic Heart." +"\nIf your life is over 50% your total damage is reduced by 15% and your defense is reduced by 50."+ "\nIf your life is under 50% your life regen is slightly increased." + "\nIf your life is under 33% you gain 20 defense." + "\nIf your life is under 25% you gain +15% Damage for all Classes."+ "\nIf your life is under 20% you gain 25% crit chance" + "\nIf your life is under 10% you take -5% Damage." + "\nIf your life is under 5% your life regen and mana regen is highly increased.");
        }

        public override void SetDefaults()
        {
            item.value = Item.buyPrice(0, 30, 0, 0);
            item.width = 20;
            item.height = 20;
            item.rare = 10;
            item.accessory = true;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            if (MyWorld.ChallengeMode == false)
            {
                if (player.statLife > player.statLifeMax2 / 2)
                {
                    player.statDefense -= 50;
                    player.magicDamage -= 0.15f;
                    player.minionDamage -= 0.15f;
                    player.thrownDamage -= 0.15f;
                    player.rangedDamage -= 0.15f;
                    player.meleeDamage -= 0.15f;
                }
                if (player.statLife < player.statLifeMax2 / 2)
                {
                    player.lifeRegen += 5; 
                }

                if (player.statLife < player.statLifeMax2 / 3)
                {
                    player.statDefense += 20;
                }

                if (player.statLife < player.statLifeMax2 / 4)
                {
                    player.magicDamage += 0.15f;
                    player.minionDamage += 0.15f;
                    player.thrownDamage += 0.15f;
                    player.rangedDamage += 0.15f;
                    player.meleeDamage += 0.15f;
                }

                if (player.statLife < player.statLifeMax2 / 5)
                {
                    player.meleeCrit += 25;
                    player.rangedCrit += 25;
                    player.magicCrit += 25;
                    player.thrownCrit += 25;
                }

                if (player.statLife < player.statLifeMax2 / 10)
                {
                    player.endurance += 0.05f;
                }

                if (player.statLife < player.statLifeMax2 / 20)
                {
                    player.lifeRegen += 20;
                    player.manaRegen += 20;
                }

            }
        }


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.LifeCrystal, 5);
            recipe.AddIngredient(ItemID.LifeFruit, 3);
            recipe.AddIngredient(ItemID.PanicNecklace, 1);
            recipe.AddIngredient(ItemID.SharkToothNecklace, 1);
            recipe.AddIngredient(ItemID.CrossNecklace, 1);
            recipe.AddIngredient(null, "Accessories4", 1);
            recipe.AddIngredient(null, "Toxic_Token", 1);
            recipe.AddIngredient(null, "OnyxBar", 10);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}