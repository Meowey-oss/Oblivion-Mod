using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class Terminator : ModItem
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Termination");
            Tooltip.SetDefault("Destroy the whole world!"+"\nSpecial");
        }

        public override void SetDefaults()
        {
            item.damage = 1;
            item.ranged = true;
            item.width = 5;
            item.height = 5;
            item.knockBack = 15f;
            item.noMelee = true;
            item.autoReuse = true;
            item.UseSound = SoundID.Item11;
            item.value = Item.buyPrice(0, 40, 0, 0);
            item.useAnimation = 3;
            item.useTime = 3;
            item.useStyle = 5;
            item.shoot = ModContent.ProjectileType<Projectiles.Bullet4>();
            item.shootSpeed = 23.7f;
            item.rare = -12;

        }

        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            float numberProjectiles = 1 + Main.rand.Next(7);
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedByRandom(MathHelper.ToRadians(5));
                Projectile.NewProjectile(position.X, position.Y, perturbedSpeed.X, perturbedSpeed.Y, type, damage, knockBack, player.whoAmI);
            }
            return false;
        }


       
        
    }
}
