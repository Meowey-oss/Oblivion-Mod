using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class DungeonStone : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Dungeon Stone");
            Tooltip.SetDefault("A Stone with great power inside of it." + "\nMakes you Immune to 'Confused' and 'Slow'."+ "\nSlightly Increased Liferegen and Manaregen and if you are under 50% life the effects are doubled."+ "\nIf you are under 10% health the effects are 5x stronger.");
        }

        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.defense = 10;
            item.value = Item.buyPrice(0, 4, 0, 0);
            item.rare = -12;
            item.accessory = true;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.buffImmune[BuffID.Confused] = true;
            player.buffImmune[BuffID.Slow] = true; 
            if (player.statLife < player.statLifeMax2 / 10)
            {
                player.manaRegen += 15;
                player.lifeRegen += 15;
            }
            else if (player.statLife < player.statLifeMax2 / 2)
            {
                player.manaRegen += 6;
                player.lifeRegen += 6;
            }
            else
            {
                player.manaRegen += 3;
                player.lifeRegen += 3;
            }
        }

    }
}