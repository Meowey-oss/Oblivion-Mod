using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class JungleStone : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Jungle Stone");
            Tooltip.SetDefault("A Stone with great power inside of it." + "\n+40 Mana"+ "\nMakes you Immune to 'Posioned' and 'Venom'."+"\nWhen your mana is under 150 your life regen and your Magic damage is increased.");
        }

        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = Item.buyPrice(0, 4, 0, 0);
            item.rare = -12;
            item.accessory = true;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.buffImmune[BuffID.Poisoned] = true;
            player.buffImmune[BuffID.Venom] = true;
            if (player.statMana <= 150)
            {
                player.magicDamage += 0.10f;
                player.lifeRegen += 5;
            }
            player.statManaMax2 += 40;
        }

    }
}