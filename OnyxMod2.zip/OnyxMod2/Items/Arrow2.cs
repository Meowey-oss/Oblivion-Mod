using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class Arrow2 : ModItem
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Demonfire Arrow");
        }

        public override void SetDefaults()
        {
            item.damage = 34;
            item.ranged = true;
            item.width = 30;
            item.maxStack = 9999;
            item.consumable = true;
            item.ammo = 40;
            item.height = 30;
            item.knockBack = 3f;
            item.value = Item.buyPrice(0, 1, 0, 0);
            item.shoot = mod.ProjectileType("ArrowProjectile2");
            item.shootSpeed = 22.1f;
            item.rare = -12;
            item.UseSound = SoundID.Item1;

        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "EyeShard", 4);
            recipe.AddIngredient(null, "EXCore", 5);
            recipe.AddIngredient(ItemID.CursedArrow, 500);
            recipe.AddIngredient(null, "Arrow1", 500);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this, 500);
            recipe.AddRecipe();
        }


    }
}
