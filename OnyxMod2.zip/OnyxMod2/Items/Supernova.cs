using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class Supernova : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Supernova");
            Tooltip.SetDefault("Shoots one heavy Supernova" + "\nSecondary Attack: Shoots 3 weaker Supernovas.");

        }

        public override void SetDefaults()
        {
            item.width = 20;
            item.knockBack = 16f;
            item.value = 2000;
            item.damage = 4000;
            item.height = 20;
            item.useTime = 55;
            item.useAnimation = 55;
            item.useStyle = 2;
            item.noUseGraphic = true;
            item.noMelee = true;
            item.maxStack = 1;
            item.consumable = false;
            item.rare = -12;
            item.UseSound = SoundID.Item7;
            item.autoReuse = true;
            item.shoot = ModContent.ProjectileType<Projectiles.GProj4>();
            item.shootSpeed = 16.1f;
            item.thrown = true;

        }

        public override bool AltFunctionUse(Player player)
        {
            return true;
        }
        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            if (player.altFunctionUse == 2)
            {
                Projectile.NewProjectile(position.X, position.Y, speedX * 1f, speedY * 1f, mod.ProjectileType("GProj5"), damage / 4, knockBack, player.whoAmI); ;
                Projectile.NewProjectile(position.X, position.Y, speedX * 1.5f, speedY * 1.5f, mod.ProjectileType("GProj5"), damage / 4, knockBack, player.whoAmI);
                Projectile.NewProjectile(position.X, position.Y, speedX * 2f, speedY * 2f, mod.ProjectileType("GProj5"), damage / 2, knockBack, player.whoAmI);
            }
            else
                return base.Shoot(player, ref position, ref speedX, ref speedY, ref type, ref damage, ref knockBack);
            return false;

        }
        public override void RightClick(Player player)
        {

        }


    }
}