using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
	public class SwordOfTheEyes : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Cheaters Sword");
			Tooltip.SetDefault("Cheater!!!!");
		}
		public override void SetDefaults()
		{
			item.damage = 400000;
			item.melee = true;
			item.width = 80;
			item.height = 80;
			item.useTime = 7;
			item.useAnimation = 7;
			item.useStyle = 1;
			item.knockBack = 15f;
			item.value = 100000;
			item.rare = 10;
			item.UseSound = SoundID.Item1;
			item.autoReuse = true;
		}

        public override void OnHitNPC(Player player, NPC target, int damage, float knockback, bool crit)
        {
            int lifeSteal = damage / 2;
            player.statLife += lifeSteal;
            player.HealEffect(lifeSteal);
        }

        /*
        public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.StoneBlock, 100);
			recipe.AddTile(TileID.WorkBenches);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
        */
	}
}
