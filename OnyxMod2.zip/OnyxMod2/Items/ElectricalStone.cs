using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using System;

namespace OnyxMod2.Items
{

    public class ElectricalStone : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Electrical Stone");
            Tooltip.SetDefault("A Stone with great power inside of it." + "\n+4% Movementspeed" + "\nMakes you Immune to 'Darkness' and 'BrokenArmor'."+ "\nWhen your life is under 50% you get +50% increased Movementspeed.");
        }

        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = Item.buyPrice(0, 4, 0, 0);
            item.rare = -12;
            item.accessory = true;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.buffImmune[BuffID.Darkness] = true;
            player.buffImmune[BuffID.BrokenArmor] = true;
            if (player.statLife < player.statLifeMax2 / 2)
            {
                player.moveSpeed += 0.50f;
            }
            player.moveSpeed += 0.04f;
        }


    }
}