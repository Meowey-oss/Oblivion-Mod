using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class CrystalSprayer : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Crystal Sprayer");
            Tooltip.SetDefault("Shoots Crystal Bullets wich can slpit into more Crystal Bullets.");
        }

        public override void SetDefaults()
        {
            item.width = 1;
            item.knockBack = 6f;
            item.value = 1000;
            item.damage = 20;
            item.height = 1;
            item.useTime = 11;
            item.useAnimation = 11;
            item.useStyle = 5;
            item.knockBack = 6f;
            item.noMelee = true;
            item.rare = 6;
            item.UseSound = SoundID.Item36;
            item.autoReuse = true;
            item.shoot = ModContent.ProjectileType<Projectiles.CrystalProj3>();
            item.shootSpeed = 15.1f;
            item.magic = true;
            item.mana = 7;

        }



        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            float numberProjectiles = 1;
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedByRandom(MathHelper.ToRadians(9));
                float scale = 1f - (Main.rand.NextFloat() * .5f);
                perturbedSpeed = perturbedSpeed * scale;
                Projectile.NewProjectile(position.X, position.Y, perturbedSpeed.X, perturbedSpeed.Y, type, damage, knockBack, player.whoAmI);
            }
            return false;
        }


    }
}
