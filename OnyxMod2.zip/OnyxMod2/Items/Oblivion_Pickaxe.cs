﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
namespace OnyxMod2.Items
{
    public class Oblivion_Pickaxe : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Oblivion Pickaxe");
        }
        public override void SetDefaults()
        {
            item.damage = 100;
            item.melee = true;
            item.width = 36;
            item.height = 36;
            item.useTime = 0;
            item.pick = 260;
            item.tileBoost += 10;
            item.useAnimation = 8;
            item.useStyle = ItemUseStyleID.SwingThrow;
            item.knockBack = 5.5f;
            item.value = Item.buyPrice(0, 20, 0, 0);
            item.rare = ItemRarityID.Lime;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            
        }


        
        public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
 
            recipe.AddIngredient(ItemID.StardustPickaxe, 1);
            recipe.AddIngredient(null, "EyeShard", 5);
            recipe.AddTile(null, "BloodAltar");
			recipe.SetResult(this);
			recipe.AddRecipe();

            recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.NebulaPickaxe, 1);
            recipe.AddIngredient(null, "EyeShard", 5);
            recipe.AddTile(null, "BloodAltar");
            recipe.SetResult(this);
            recipe.AddRecipe();
            recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.VortexPickaxe, 1);
            recipe.AddIngredient(null, "EyeShard", 5);
            recipe.AddTile(null, "BloodAltar");
            recipe.SetResult(this);
            recipe.AddRecipe();
            recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.SolarFlarePickaxe, 1);
            recipe.AddIngredient(null, "EyeShard", 5);
            recipe.AddTile(null, "BloodAltar");
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
        

    }
}
