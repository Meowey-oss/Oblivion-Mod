﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    [AutoloadEquip(EquipType.Body)]
    public class ArmorBreastplate1 : ModItem
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Oblivion Chestplate");
            Tooltip.SetDefault("+10% Damage and 10% crit chance to all classes except for Summoner" + "\nAlso gives you +120 Max Mana");
        }

        public override void SetDefaults()
        {
            item.width = 41;
            item.height = 40;
            item.value = 100000;
            item.rare = 9;
            item.defense = 35;
        }
        
        public override bool IsArmorSet(Item head, Item body, Item legs)
        {
            return head.type == mod.ItemType("ArmorHelmet1") && legs.type == mod.ItemType("ArmorBoots1");
        }
        


        public override void UpdateEquip(Player player)
        {
            player.magicDamage += 0.10f;
            player.thrownDamage += 0.10f;
            player.meleeDamage += 0.10f;
            player.rangedDamage += 0.10f;
            player.statManaMax2 += 120;
            player.magicCrit += 10;
            player.thrownCrit += 10;
            player.meleeCrit += 10;
            player.rangedCrit += 10;
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+20% Attack Damage to all classes except for Summoner" + "\nImmunity to 'Venom','OnFire','CursedInferno' and 'Lava'";
            player.magicDamage += 0.20f;
            player.thrownDamage += 0.20f;
            player.meleeDamage += 0.20f;
            player.rangedDamage += 0.20f;
            player.lavaImmune = true;
            player.buffImmune[BuffID.Venom] = true;
            player.buffImmune[BuffID.OnFire] = true;
            player.buffImmune[BuffID.CursedInferno] = true;
        }




        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(null, "OnyxBar", 25);
            recipe.AddIngredient(null, "EXCore", 15);
            recipe.AddIngredient(null, "WormEye", 1);
            recipe.AddIngredient(null, "EyeShard", 4);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }


    }
}
