using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class FireStone : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Fire Stone");
            Tooltip.SetDefault("A Stone with great power inside of it." + "\n+2% Damage" + "\nMakes you Immune to Lava and 'OnFire'."+"\nIf you are under 50% life your defense is increased by 10 and your melee damage is increased by 20%.");
        }

        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.rare = -12;
            item.value = Item.buyPrice(0, 4, 0, 0);
            item.accessory = true;
        }

        
        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            if (player.statLife < player.statLifeMax2 / 2)
            {
                player.statDefense += 10;
                player.meleeDamage += 0.20f;
            }
            player.buffImmune[BuffID.OnFire] = true;
            player.lavaImmune = true;
            player.thrownDamage += 0.02f;
            player.rangedDamage += 0.02f;
            player.meleeDamage += 0.02f;
            player.minionDamage += 0.02f;
            player.magicDamage += 0.02f;
        }


    }
}