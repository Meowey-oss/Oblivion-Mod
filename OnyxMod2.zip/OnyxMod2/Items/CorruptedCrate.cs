﻿using Terraria.ModLoader;
using Terraria.ID;
using Terraria;

namespace OnyxMod2.Items
{



    public class CorruptedCrate : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Corrupted Crate");
            Tooltip.SetDefault("Right Click To Open" + "\nCan drop Hardmode Stuff from both Corruptions and the Hallow.");
        }
        public override void SetDefaults()
        {
            item.width = 12;
            item.height = 12;
            item.useStyle = -1;
            item.consumable = true;
            item.rare = 7;
            item.maxStack = 200;
        }

        public override bool CanRightClick()
        {
            return true;
        }

        public override void RightClick(Player player)
        {

        
        
            if (Main.rand.Next(5) == 0)
            {
                player.QuickSpawnItem(ItemID.Ichor, Main.rand.Next(1, 2));
            }

            if (Main.rand.Next(5) == 0)
            {
                player.QuickSpawnItem(ItemID.CursedFlame, Main.rand.Next(1, 2));
            }

            if (Main.rand.Next(5) == 0)
            {
                player.QuickSpawnItem(ItemID.CrystalShard, Main.rand.Next(1, 2));
            }

            if (Main.rand.Next(5) == 0)
            {
                player.QuickSpawnItem(ItemID.SoulofNight, Main.rand.Next(1, 2));
            }

            if (Main.rand.Next(5) == 0)
            {
                player.QuickSpawnItem(ItemID.SoulofLight, Main.rand.Next(1, 2));
            }

           
           if (Main.rand.Next(300) == 0)
           {
                Main.NewText("You got a Rare item out of the Corrupted Crate! ", 55, 153, 155);
                player.QuickSpawnItem(ItemID.LifeFruit, Main.rand.Next(1, 2));
           }
            
            else if (Main.rand.Next(300) == 0)
            {
                Main.NewText("You got a Rare item out of the Corrupted Crate! ", 55, 153, 155);
                player.QuickSpawnItem(ItemID.MechanicalEye, Main.rand.Next(1, 2));
            }

            else if (Main.rand.Next(300) == 0)
            {
                Main.NewText("You got a Rare item out of the Corrupted Crate! ", 55, 153, 155);
                player.QuickSpawnItem(ItemID.MechanicalSkull, Main.rand.Next(1, 2));
            }
            else if (Main.rand.Next(300) == 0)
            {
                Main.NewText("You got a Rare item out of the Corrupted Crate! ", 55, 153, 155);
                player.QuickSpawnItem(ItemID.MechanicalWorm, Main.rand.Next(1, 2));
            }
            else if (Main.rand.Next(400) == 0)
            {
                Main.NewText("You got a Very Rare item out of the Corrupted Crate! ", 55, 153, 155);
                player.QuickSpawnItem(ItemID.NightKey, Main.rand.Next(1, 2));
            }
            else if (Main.rand.Next(400) == 0)
            {
                Main.NewText("You got a Very Rare item out of the Corrupted Crate! ", 55, 153, 155);
                player.QuickSpawnItem(ItemID.LightKey, Main.rand.Next(1, 2));
            }
            else if (Main.rand.Next(400) == 0)
            {
                Main.NewText("You got a Very Rare item out of the Corrupted Crate! GG", 35, 153, 125);
                player.QuickSpawnItem(ItemID.AdamantiteForge, Main.rand.Next(1, 2));
            }

            else if (Main.rand.Next(600) == 0)
            {
                Main.NewText("You got a Legendary Rare item out of the Corrupted Crate! GG", 35, 153, 125);
                player.QuickSpawnItem(mod.ItemType("BookOfBlood"), Main.rand.Next(1, 2));
            }

            else if (Main.rand.Next(800) == 0)
            {
                Main.NewText("You got a Legendary Rare item out of the Corrupted Crate! GG", 65, 153, 125);
                player.QuickSpawnItem(ItemID.CrystalStorm, Main.rand.Next(1, 2));
            }

            else if (Main.rand.Next(800) == 0)
            {
                Main.NewText("You got a Legendary Rare item out of the Corrupted Crate! GG", 65, 153, 125);
                player.QuickSpawnItem(ItemID.GoldenShower, Main.rand.Next(1, 2));
            }

            player.QuickSpawnItem(ItemID.CopperCoin, Main.rand.Next(50, 80));
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(null, "BloodBar", 1);
            recipe.AddTile(null, "BloodAltar");
            recipe.SetResult(this, 4);
            recipe.AddRecipe();
        }
    }
}