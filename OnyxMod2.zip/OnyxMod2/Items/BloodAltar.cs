using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class BloodAltar : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Blood Altar");
            Tooltip.SetDefault("Bloody version of the Demon Altar." + "\nCan be used as a Demon Altar.");
        }
        public override void SetDefaults()
        {
            item.width = 48;
            item.height = 34;
            item.maxStack = 99;
            item.useTurn = false;
            item.autoReuse = true;
            item.useAnimation = 15;
            item.rare = ItemRarityID.LightRed;
            item.useTime = 10;
            item.useStyle = 1;
            item.consumable = true;
            item.value = 450;
            item.createTile = mod.TileType("BloodAltar");
        }


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(ItemID.DemoniteOre, 50);
            recipe.AddIngredient(null, "BloodOre", 50);
            recipe.AddTile(TileID.DemonAltar);
            recipe.SetResult(this);
            recipe.AddRecipe();
            recipe = new ModRecipe(mod);

            recipe.AddIngredient(ItemID.CrimtaneOre, 50);
            recipe.AddIngredient(null, "BloodOre", 50);
            recipe.AddTile(TileID.DemonAltar);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}