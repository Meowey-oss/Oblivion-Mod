﻿using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class BulletBall1 : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Wooden Bullet Ball");
            Tooltip.SetDefault("Shoots out a ball wich explodes into projectiles.");
        }

        public override void SetDefaults()
        {
            item.width = 50;
            item.knockBack = 2f;
            item.value = Item.buyPrice(0, 0, 0, 99);
            item.damage = 5;
            item.height = 50;
            item.noUseGraphic = true;
            item.useTime = 98;
            item.useAnimation = 98;
            item.useStyle = ItemUseStyleID.HoldingOut;
            item.noMelee = true;
            item.rare = ItemRarityID.Green;
            item.UseSound = SoundID.Item17;
            item.autoReuse = true;
            item.shoot = mod.ProjectileType("BB1");
            item.shootSpeed = 10.1f;
            item.ranged = true;

        }



        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(ItemID.Wood, 150);
            recipe.AddIngredient(ItemID.IronBar, 15);
            recipe.anyIronBar = true;
            recipe.AddIngredient(ItemID.WoodenBow, 1);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}