﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class Buff6 : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Crystalized");
            Description.SetDefault("15% damage reduction.");
            Main.debuff[Type] = false;
            Main.pvpBuff[Type] = true;
            Main.buffNoSave[Type] = true;
        }


        public override void Update(Player player, ref int buffIndex)
        {
            int num1 = Dust.NewDust(player.position, player.width, player.height, DustID.BlueCrystalShard);
            Main.dust[num1].scale = 1.3f;
            Main.dust[num1].velocity *= 2f;
            Main.dust[num1].noGravity = true;
            player.endurance += 0.15f;
        }

    }
}
