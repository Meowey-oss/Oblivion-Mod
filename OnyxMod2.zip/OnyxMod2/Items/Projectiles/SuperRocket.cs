﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace OnyxMod2.Items.Projectiles
{
    public class SuperRocket : ModProjectile
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Super Rocket");
        }

        public override void SetDefaults()
        {
            projectile.width = 14;
            projectile.height = 20;
            projectile.hostile = false;
            projectile.friendly = true;
            projectile.penetrate = 1;
            projectile.magic = true;
            projectile.tileCollide = true;
            projectile.ignoreWater = true;
            projectile.timeLeft = 200;
            aiType = 1;
            projectile.aiStyle = 2;
        }

        public override void AI()
        {
            Dust.NewDust(projectile.position + projectile.velocity, projectile.width, projectile.height, DustID.Fire, projectile.velocity.X * 0.1f, projectile.velocity.Y * 0.1f);
            projectile.rotation = (float)Math.Atan2((double)projectile.velocity.Y, (double)projectile.velocity.X) + 1.57f;


        }

        public override void Kill(int timeLeft)
        {

            Main.PlaySound(SoundID.Item14, projectile.position);

            if (projectile.owner == Main.myPlayer)
            {

                float speedX = projectile.velocity.X / 4;
                float speedY = projectile.velocity.Y / 4;
                float numberProjectiles = 40;
                float rotation = MathHelper.ToRadians(360);
                projectile.position += Vector2.Normalize(new Vector2(speedX, speedY)) * 10f;
                for (int i = 0; i < numberProjectiles; i++)
                {
                    Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedBy(MathHelper.Lerp(-rotation, rotation, i / (numberProjectiles - 1))) * .7f;
                    Projectile.NewProjectile(projectile.position.X, projectile.position.Y, perturbedSpeed.X, perturbedSpeed.Y, mod.ProjectileType("RocketProj1"), (int)(projectile.damage * 0.6), 0f, projectile.owner, 0f, 0f);
                }


            }
            if (projectile.owner == Main.myPlayer)
            {

                float speedX = projectile.velocity.X / 6;
                float speedY = projectile.velocity.Y / 6;
                float numberProjectiles = 20;
                float rotation = MathHelper.ToRadians(360);
                projectile.position += Vector2.Normalize(new Vector2(speedX, speedY)) * 10f;
                for (int i = 0; i < numberProjectiles; i++)
                {
                    Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedBy(MathHelper.Lerp(-rotation, rotation, i / (numberProjectiles - 1))) * .7f;
                    Projectile.NewProjectile(projectile.position.X, projectile.position.Y, perturbedSpeed.X, perturbedSpeed.Y, mod.ProjectileType("RocketProj2"), (int)(projectile.damage * 0.7), 0f, projectile.owner, 0f, 0f);
                }


            }
            if (projectile.owner == Main.myPlayer)
            {

                float speedX = projectile.velocity.X / 8;
                float speedY = projectile.velocity.Y / 8;
                float numberProjectiles = 8;
                float rotation = MathHelper.ToRadians(360);
                projectile.position += Vector2.Normalize(new Vector2(speedX, speedY)) * 10f;
                for (int i = 0; i < numberProjectiles; i++)
                {
                    Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedBy(MathHelper.Lerp(-rotation, rotation, i / (numberProjectiles - 1))) * .7f;
                    Projectile.NewProjectile(projectile.position.X, projectile.position.Y, perturbedSpeed.X, perturbedSpeed.Y, mod.ProjectileType("RocketProj3"), (int)(projectile.damage * 0.8), 0f, projectile.owner, 0f, 0f);
                }


            }



        }







    }
}