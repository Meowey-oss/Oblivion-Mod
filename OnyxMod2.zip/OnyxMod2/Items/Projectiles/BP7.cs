﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Terraria.DataStructures;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items.Projectiles
{
    // to investigate: Projectile.Damage, (8843)
    class BP7 : ModProjectile
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Corrupted Bomb");
        }

        public override void SetDefaults()
        {
            // while the sprite is actually bigger than 15x15, we use 15x15 since it lets the projectile clip into tiles as it bounces. It looks better.
            projectile.width = 52;
            projectile.height = 52;
            projectile.aiStyle = 0;
            projectile.friendly = false;
            projectile.hostile = true;
            projectile.penetrate = 1;
            // 8 second fuse.
            projectile.timeLeft = 80;

            // These 2 help the projectile hitbox be centered on the projectile sprite.
            drawOffsetX = 0;
            drawOriginOffsetY = 0;
        }


        public override void AI()
        {
            projectile.rotation += 0.3f;
            if (projectile.owner == Main.myPlayer && projectile.timeLeft <= 3)
            {
                projectile.tileCollide = false;
                // Set to transparant. This projectile technically lives as  transparant for about 3 frames
                projectile.alpha = 255;
                // change the hitbox size, centered about the original projectile center. This makes the projectile damage enemies during the explosion.
                projectile.position.X = projectile.position.X + (float)(projectile.width / 2);
                projectile.position.Y = projectile.position.Y + (float)(projectile.height / 2);
                projectile.width = 250;
                projectile.height = 250;
                projectile.position.X = projectile.position.X - (float)(projectile.width / 2);
                projectile.position.Y = projectile.position.Y - (float)(projectile.height / 2);
                projectile.damage = 40;
                projectile.knockBack = 40f;
            }
            else
            {
                // Smoke and fuse dust spawn.
                if (Main.rand.Next(2) == 0)
                {
                    int dustIndex = Dust.NewDust(new Vector2(projectile.position.X, projectile.position.Y), projectile.width, projectile.height, ProjectileID.ShadowFlame, 0f, 0f, 100, default(Color), 1f);
                    Main.dust[dustIndex].scale = 0.1f + (float)Main.rand.Next(1) * 0.1f;
                    Main.dust[dustIndex].fadeIn = 1.5f + (float)Main.rand.Next(1) * 0.1f;
                    Main.dust[dustIndex].noGravity = true;
                    Main.dust[dustIndex].position = projectile.Center + new Vector2(0f, (float)(-(float)projectile.height / 2)).RotatedBy((double)projectile.rotation, default(Vector2)) * 1.1f;
                    dustIndex = Dust.NewDust(new Vector2(projectile.position.X, projectile.position.Y), projectile.width, projectile.height, ProjectileID.ShadowFlame, 0f, 0f, 100, default(Color), 1f);
                    Main.dust[dustIndex].scale = 1f + (float)Main.rand.Next(1) * 0.1f;
                    Main.dust[dustIndex].noGravity = true;
                    Main.dust[dustIndex].position = projectile.Center + new Vector2(0f, (float)(-(float)projectile.height / 2 - 6)).RotatedBy((double)projectile.rotation, default(Vector2)) * 1.1f;
                }
            }
        }

        public override void OnHitPlayer(Player target, int damage, bool crit)
        {
            projectile.timeLeft = 0;
        }

        public override void Kill(int timeLeft)
        {

            float speedX = projectile.velocity.X * 2;
            float speedY = projectile.velocity.Y * 2;
            float numberProjectiles = 12;
            float rotation = MathHelper.ToRadians(360);
            projectile.position += Vector2.Normalize(new Vector2(speedX, speedY)) * 10f;
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedBy(MathHelper.Lerp(-rotation, rotation, i / (numberProjectiles - 1))) * .7f;
                Projectile.NewProjectile(projectile.position.X, projectile.position.Y, perturbedSpeed.X, perturbedSpeed.Y, mod.ProjectileType("BossProjectile2"), (int)(projectile.damage * 1), 0f, projectile.owner, 0f, 0f);
            }
            // If we are the original projectile, spawn the 5 child projectiles

            if (projectile.ai[1] == 0)
            {


                // Play explosion sound
                Main.PlaySound(SoundID.Item14, projectile.position);
                // Smoke Dust spawn
                for (int i = 0; i < 50; i++)
                {
                    int dustIndex = Dust.NewDust(new Vector2(projectile.position.X, projectile.position.Y), projectile.width, projectile.height, DustID.Shadowflame, 0f, 0f, 180, default(Color), 2f);
                    Main.dust[dustIndex].velocity *= 1.4f;
                }
                // Fire Dust spawn
                for (int i = 0; i < 80; i++)
                {
                    int dustIndex = Dust.NewDust(new Vector2(projectile.position.X, projectile.position.Y), projectile.width, projectile.height, DustID.Shadowflame, 0f, 0f, 180, default(Color), 3f);
                    Main.dust[dustIndex].noGravity = true;
                    Main.dust[dustIndex].velocity *= 5f;
                    dustIndex = Dust.NewDust(new Vector2(projectile.position.X, projectile.position.Y), projectile.width, projectile.height, DustID.Shadowflame, 0f, 0f, 180, default(Color), 2f);
                    Main.dust[dustIndex].velocity *= 3f;
                }

                // reset size to normal width and height.
                projectile.position.X = projectile.position.X + (float)(projectile.width / 2);
                projectile.position.Y = projectile.position.Y + (float)(projectile.height / 2);
                projectile.width = 10;
                projectile.height = 10;
                projectile.position.X = projectile.position.X - (float)(projectile.width / 2);
                projectile.position.Y = projectile.position.Y - (float)(projectile.height / 2);

                // TODO, tmodloader helper method
                {
                    int explosionRadius = 29;
                    //if (projectile.type == 29 || projectile.type == 470 || projectile.type == 637)
                    //{
                    //  explosionRadius = 15;
                    //}
                    int minTileX = (int)(projectile.position.X / 16f - (float)explosionRadius);
                    int maxTileX = (int)(projectile.position.X / 16f + (float)explosionRadius);
                    int minTileY = (int)(projectile.position.Y / 16f - (float)explosionRadius);
                    int maxTileY = (int)(projectile.position.Y / 16f + (float)explosionRadius);
                    if (minTileX < 0)
                    {
                        minTileX = 0;
                    }
                    if (maxTileX > Main.maxTilesX)
                    {
                        maxTileX = Main.maxTilesX;
                    }
                    if (minTileY < 0)
                    {
                        minTileY = 0;
                    }
                    if (maxTileY > Main.maxTilesY)
                    {
                        maxTileY = Main.maxTilesY;
                    }
                    bool canKillWalls = false;
                    for (int x = minTileX; x <= maxTileX; x++)
                    {
                        for (int y = minTileY; y <= maxTileY; y++)
                        {
                            float diffX = Math.Abs((float)x - projectile.position.X / 16f);
                            float diffY = Math.Abs((float)y - projectile.position.Y / 16f);
                            double distance = Math.Sqrt((double)(diffX * diffX + diffY * diffY));
                            if (distance < (double)explosionRadius && Main.tile[x, y] != null && Main.tile[x, y].wall == 0)
                            {
                                canKillWalls = true;
                                break;
                            }
                        }
                    }
                    for (int i = minTileX; i <= maxTileX; i++)
                    {
                        for (int j = minTileY; j <= maxTileY; j++)
                        {
                            float diffX = Math.Abs((float)i - projectile.position.X / 16f);
                            float diffY = Math.Abs((float)j - projectile.position.Y / 16f);
                            double distanceToTile = Math.Sqrt((double)(diffX * diffX + diffY * diffY));
                            if (distanceToTile < (double)explosionRadius)
                            {
                                bool canKillTile = false;
                                if (Main.tile[i, j] != null && Main.tile[i, j].active())
                                {
                                    canKillTile = false;
                                    if (Main.tileDungeon[(int)Main.tile[i, j].type] || Main.tile[i, j].type == 88 || Main.tile[i, j].type == 21 || Main.tile[i, j].type == 26 || Main.tile[i, j].type == 107 || Main.tile[i, j].type == 108 || Main.tile[i, j].type == 111 || Main.tile[i, j].type == 226 || Main.tile[i, j].type == 237 || Main.tile[i, j].type == 221 || Main.tile[i, j].type == 222 || Main.tile[i, j].type == 223 || Main.tile[i, j].type == 211 || Main.tile[i, j].type == 404)
                                    {
                                        canKillTile = false;
                                    }
                                    if (!Main.hardMode && Main.tile[i, j].type == 58)
                                    {
                                        canKillTile = false;
                                    }
                                    if (!TileLoader.CanExplode(i, j))
                                    {
                                        canKillTile = false;
                                    }
                                    if (canKillTile)
                                    {
                                        WorldGen.KillTile(i, j, false, false, false);
                                        if (!Main.tile[i, j].active() && Main.netMode != NetmodeID.SinglePlayer)
                                        {
                                            NetMessage.SendData(MessageID.TileChange, -1, -1, null, 0, (float)i, (float)j, 0f, 0, 0, 0);
                                        }
                                    }
                                }
                                if (canKillTile)
                                {
                                    for (int x = i - 1; x <= i + 1; x++)
                                    {
                                        for (int y = j - 1; y <= j + 1; y++)
                                        {
                                            if (Main.tile[x, y] != null && Main.tile[x, y].wall > 0 && canKillWalls && WallLoader.CanExplode(x, y, Main.tile[x, y].wall))
                                            {
                                                WorldGen.KillWall(x, y, false);
                                                if (Main.tile[x, y].wall == 0 && Main.netMode != NetmodeID.SinglePlayer)
                                                {
                                                    NetMessage.SendData(MessageID.TileChange, -1, -1, null, 2, (float)x, (float)y, 0f, 0, 0, 0);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}