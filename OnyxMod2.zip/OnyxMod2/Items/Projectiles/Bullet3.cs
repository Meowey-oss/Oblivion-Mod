using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using System;

namespace OnyxMod2.Items.Projectiles //We need this to basically indicate the folder where it is to be read from, so you the texture will load correctly
{
    public class Bullet3 : ModProjectile
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Bouncy Bullet");
        }


        public override void SetDefaults()
        {
            projectile.width = 2; //Set the hitbox width
            projectile.height = 38; //Set the hitbox height
            projectile.timeLeft = 190; //The amount of time the projectile is alive for
            projectile.penetrate = 4; //Tells the game how many enemies it can hit before being destroyed
            projectile.friendly = true; //Tells the game whether it is friendly to players/friendly npcs or not
            projectile.hostile = false; //Tells the game whether it is hostile to players or not
            projectile.tileCollide = true; //Tells the game whether or not it can collide with a tile
            projectile.ignoreWater = true; //Tells the game whether or not projectile will be affected by water
            projectile.ranged = true; //Tells the game whether it is a ranged projectile or not
            projectile.aiStyle = 0; //How the projectile works, 0 makes the projectile just go straight towards your cursor
        }

        public override void OnHitNPC(NPC target, int damage, float knockback, bool crit)
        {
            projectile.timeLeft += 80;

            if (projectile.velocity.X != -projectile.velocity.X)
            {
                projectile.velocity.X = -projectile.velocity.X + 1; //Goes in the opposite direction with half of its x velocity
            }
            if (projectile.velocity.Y != -projectile.velocity.Y)
            {
                projectile.velocity.Y = -projectile.velocity.Y + 1; //Goes in the opposite direction with half of its y velocity
            }
            base.OnHitNPC(target, damage, knockback, crit);
        }
        //When the projectile hits a tile
        public override bool OnTileCollide(Vector2 velocityChange)
        {
            projectile.timeLeft -= 40;

            if (projectile.velocity.X != velocityChange.X)
            {
                projectile.velocity.X = -velocityChange.X + 1; //Goes in the opposite direction with half of its x velocity
            }
            if (projectile.velocity.Y != velocityChange.Y)
            {
                projectile.velocity.Y = -velocityChange.Y + 1; //Goes in the opposite direction with half of its y velocity
            }
            return false;
        }

        public override void AI()
        {
          
            projectile.rotation = (float)Math.Atan2((double)projectile.velocity.Y, (double)projectile.velocity.X) + 1.57f;
        }

    }
}