
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace OnyxMod2.Items
{
    public abstract class MinionAI1 : ModProjectile
    {
        public override void AI()
        {
            CheckActive();
            Behaviour();

        }

        public abstract void CheckActive();

        public abstract void Behaviour();
    }
}