﻿
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items.Projectiles
{
    public class ThrownProjectile1 : ModProjectile
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("EX Bone");
        }

        public override void SetDefaults()
        {
            projectile.width = 10;
            projectile.height = 100;
            projectile.hostile = false;
            projectile.friendly = true;
            projectile.penetrate = 1;
            projectile.thrown = true;
            projectile.tileCollide = false;
            projectile.ignoreWater = false;
            projectile.timeLeft = 200;
            aiType = 1;
            projectile.aiStyle = 2;


        }

        public override void ModifyHitNPC(NPC target, ref int damage, ref float knockback, ref bool crit, ref int hitDirection)
        {
            target.AddBuff(BuffID.Venom, 10 * 300);
        }
    }

}