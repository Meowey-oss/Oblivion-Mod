﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace OnyxMod2.Items.Projectiles
{
    public class CrystalProj3 : ModProjectile
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Crystal");
        }

        public override void SetDefaults()
        {
            projectile.width = 20;
            projectile.height = 20;
            projectile.hostile = false;
            projectile.friendly = true;
            projectile.penetrate = 2;
            projectile.magic = true;
            projectile.tileCollide = true;
            projectile.ignoreWater = true;
            projectile.timeLeft = 200;
            projectile.aiStyle = 0;
        }

        public override void AI()
        {
            Dust.NewDust(projectile.position + projectile.velocity, projectile.width, projectile.height, DustID.Ice, projectile.velocity.X * 0.5f, projectile.velocity.Y * 0.5f);
            projectile.rotation = (float)Math.Atan2((double)projectile.velocity.Y, (double)projectile.velocity.X) + 1.57f;


        }

        public override void Kill(int timeLeft)
        {



            if (projectile.owner == Main.myPlayer)
            {

                float speedX = projectile.velocity.X / 2;
                float speedY = projectile.velocity.Y / 2;
                float numberProjectiles = 4;
                float rotation = MathHelper.ToRadians(360);
                projectile.position += Vector2.Normalize(new Vector2(speedX, speedY)) * 10f;
                for (int i = 0; i < numberProjectiles; i++)
                {
                    Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedBy(MathHelper.Lerp(-rotation, rotation, i / (numberProjectiles - 1))) * .7f;
                    Projectile.NewProjectile(projectile.position.X, projectile.position.Y, perturbedSpeed.X, perturbedSpeed.Y, mod.ProjectileType("CrystalProj2"), (int)(projectile.damage * 0.5), 0f, projectile.owner, 0f, 0f);
                }


            }



        }







    }
}