using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using System;

namespace OnyxMod2.Items.Projectiles //We need this to basically indicate the folder where it is to be read from, so you the texture will load correctly
{
    public class LASER1 : ModProjectile
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("C-Laser");
        }


        public override void SetDefaults()
        {
            projectile.alpha = 100;
            projectile.width = 2; //Set the hitbox width
            projectile.height = 38; //Set the hitbox height
            projectile.timeLeft = 30; //The amount of time the projectile is alive for
            projectile.penetrate = 1; //Tells the game how many enemies it can hit before being destroyed
            projectile.friendly = true; //Tells the game whether it is friendly to players/friendly npcs or not
            projectile.hostile = false; //Tells the game whether it is hostile to players or not
            projectile.tileCollide = true; //Tells the game whether or not it can collide with a tile
            projectile.ignoreWater = true; //Tells the game whether or not projectile will be affected by water
            projectile.ranged = true; //Tells the game whether it is a ranged projectile or not
            projectile.aiStyle = 0; //How the projectile works, 0 makes the projectile just go straight towards your cursor
        }




        public override void AI()
        {
            Dust.NewDust(new Vector2(projectile.position.X, projectile.position.Y), projectile.width, projectile.height, DustID.PinkFlame, projectile.velocity.X * 1.2f, projectile.velocity.Y * 1.2f, 130, default(Color), 1.75f);
            projectile.rotation = (float)Math.Atan2((double)projectile.velocity.Y, (double)projectile.velocity.X) + 1.57f;
        }
        public override void Kill(int timeLeft)
        {

            float speedX = projectile.velocity.X * 1;
            float speedY = projectile.velocity.Y * 1;
            float numberProjectiles = 3;
            float rotation = MathHelper.ToRadians(25);
            projectile.position += Vector2.Normalize(new Vector2(speedX, speedY)) * 10f;
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedBy(MathHelper.Lerp(-rotation, rotation, i / (numberProjectiles - 1))) * .7f;
                Projectile.NewProjectile(projectile.position.X, projectile.position.Y, perturbedSpeed.X, perturbedSpeed.Y, mod.ProjectileType("LASER2"), (int)(projectile.damage * 0.3), 0f, projectile.owner, 0f, 0f);
            }
        }
    }
}