
using System;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items.Projectiles
{


public class Sphere1 : Hovershooter
{
        private float rot;
        private Vector2 rotVec = new Vector2(0.0f, 90.0f);
        public override void SetStaticDefaults()
    {
        DisplayName.SetDefault("Snowflake");
    }
        public override bool PreDraw(SpriteBatch spriteBatch, Color lightColor)
        {
            //Redraw the projectile with the color not influenced by light
            Vector2 drawOrigin = new Vector2(Main.projectileTexture[projectile.type].Width * 0.5f, projectile.height * 0.5f);
            for (int k = 0; k < projectile.oldPos.Length; k++)
            {
                Vector2 drawPos = projectile.oldPos[k] - Main.screenPosition + drawOrigin + new Vector2(0f, projectile.gfxOffY);
                Color color = projectile.GetAlpha(lightColor) * ((float)(projectile.oldPos.Length - k) / (float)projectile.oldPos.Length);
                spriteBatch.Draw(Main.projectileTexture[projectile.type], drawPos, null, color, projectile.rotation, drawOrigin, projectile.scale, SpriteEffects.None, 0f);
            }
            return true;
        }

        public sealed override void SetDefaults()
        {
            projectile.netImportant = true;
            projectile.width = 30;
        projectile.height = 30;
        projectile.tileCollide = false;
        projectile.aiStyle = 0;
            projectile.timeLeft = 18000;
        projectile.friendly = true;
        projectile.minion = true;
        projectile.minionSlots = 1f;
        projectile.penetrate = -1;
            inertia = 20f;
            shoot = ModContent.ProjectileType<ThrownProjectile2>();
            shootCool = 25f;
            shootSpeed = 45f;
            
        }


        public override void CheckActive()
        {
            Player player = Main.player[projectile.owner];
            MyPlayer modPlayer = MyPlayer.Get(player);
            if (player.dead)
            {
                modPlayer.memee = false;
            }
            if (modPlayer.memee)
            {
                projectile.timeLeft = 2;
            }
        }

        public override bool MinionContactDamage()
    {
        return true;
    }
        public override void ModifyHitNPC(NPC target, ref int damage, ref float knockback, ref bool crit, ref int hitDirection)
        {
            target.AddBuff(BuffID.Frostburn, 10 * 300);
        }



        /*
        public override void AI()
    {


            this.rot += 0.06f;

            projectile.Center = Main.player[projectile.owner].Center + OnyxUti.RotateVector(new Vector2(), this.rotVec, this.rot + projectile.ai[0] * 20.14f);
            if (Main.rand.NextBool(1, 5))
            {
                float x = projectile.velocity.X / 3f;
                float y = projectile.velocity.Y / 3f;
                int dust = Dust.NewDust(projectile.position, projectile.width, projectile.height, 172, 0.0f, 0.0f, 0, new Color(), 1.0f);
                Main.dust[dust].position.X = projectile.Center.X - x;
                Main.dust[dust].position.Y = projectile.Center.Y - y;
                Main.dust[dust].noGravity = true;
                Main.dust[dust].scale += Main.rand.NextFloat() * 1f;

            }
            Player player = Main.player[projectile.owner];

        #region Active check
        // This is the "active check", makes sure the minion is alive while the player is alive, and despawns if not
        #endregion

        #region General behavior
        Vector2 idlePosition = player.Center;
        idlePosition.Y -= 48f; // Go up 48 coordinates (three tiles from the center of the player)

        // If your minion doesn't aimlessly move around when it's idle, you need to "put" it into the line of other summoned minions
        // The index is projectile.minionPos
        float minionPositionOffsetX = (10 + projectile.minionPos * 40) * -player.direction;
        idlePosition.X += minionPositionOffsetX; // Go behind the player

        // All of this code below this line is adapted from Spazmamini code (ID 388, aiStyle 66)

        // Teleport to player if distance is too big
        Vector2 vectorToIdlePosition = idlePosition - projectile.Center;
        float distanceToIdlePosition = vectorToIdlePosition.Length();
        if (Main.myPlayer == player.whoAmI && distanceToIdlePosition > 2000f)
        {
            // Whenever you deal with non-regular events that change the behavior or position drastically, make sure to only run the code on the owner of the projectile,
            // and then set netUpdate to true
            projectile.position = idlePosition;
            projectile.velocity *= 0.1f;
            projectile.netUpdate = true;
        }

        // If your minion is flying, you want to do this independently of any conditions
        float overlapVelocity = 0.04f;
        for (int i = 0; i < Main.maxProjectiles; i++)
        {
            // Fix overlap with other minions
            Projectile other = Main.projectile[i];
            if (i != projectile.whoAmI && other.active && other.owner == projectile.owner && Math.Abs(projectile.position.X - other.position.X) + Math.Abs(projectile.position.Y - other.position.Y) < projectile.width)
            {
                if (projectile.position.X < other.position.X) projectile.velocity.X -= overlapVelocity;
                else projectile.velocity.X += overlapVelocity;

                if (projectile.position.Y < other.position.Y) projectile.velocity.Y -= overlapVelocity;
                else projectile.velocity.Y += overlapVelocity;
         
                }
        } */


        Vector2 flyTo;
        int identity = 0;
        int sniperCount = 0;

        NPC target;
        int timer;
        public override void AI()
        {
            projectile.rotation += 0.2f;
            this.rot += 0.06f;

            projectile.Center = Main.player[projectile.owner].Center + OnyxUti.RotateVector(new Vector2(), this.rotVec, this.rot + projectile.ai[0] * 20.14f);
            if (Main.rand.NextBool(1, 5))
            {
                float x = projectile.velocity.X / 3f;
                float y = projectile.velocity.Y / 3f;
                int dust = Dust.NewDust(projectile.position, projectile.width, projectile.height, 172, 0.0f, 0.0f, 0, new Color(), 1.0f);
                Main.dust[dust].position.X = projectile.Center.X - x;
                Main.dust[dust].position.Y = projectile.Center.Y - y;
                Main.dust[dust].noGravity = true;
                Main.dust[dust].scale += Main.rand.NextFloat() * 1f;

            }
            Player player = Main.player[projectile.owner];


            MyPlayer modPlayer = player.GetModPlayer<MyPlayer>();
            sniperCount = player.ownedProjectileCounts[mod.ProjectileType("Sphere1")];
            if (modPlayer.memee)
            {
                projectile.timeLeft = 2;
            }
            for (int p = 0; p < 1000; p++)
            {
                if (Main.projectile[p].type == mod.ProjectileType("Sphere1"))
                {
                    if (p == projectile.whoAmI)
                    {
                        break;
                    }
                    else
                    {
                        identity++;
                    }
                }
            }







            timer++;
            if (sniperCount != 0)
            {
                projectile.ai[0] = 40f;

                flyTo = player.Center;

                projectile.velocity = (flyTo - projectile.Center) * .0f;
                if (QwertyMethods.ClosestNPC(ref target, 100000, projectile.Center, false, player.MinionAttackTargetNPC) && timer > 70)
                {
                    Main.PlaySound(SoundID.Pixie, (int)player.position.X, (int)player.position.Y, 6);
                    Projectile.NewProjectile(projectile.Center, QwertyMethods.PolarVector(30, (target.Center - projectile.Center).ToRotation()),ProjectileID.IceBolt, projectile.damage, projectile.knockBack, player.whoAmI);
                    timer = 0;
                }

            }







            identity = 0;

        }




    


}
}