using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using System;

namespace OnyxMod2.Items.Projectiles //We need this to basically indicate the folder where it is to be read from, so you the texture will load correctly
{
    public class LASER2 : ModProjectile
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("C-Laser");
        }


        public override void SetDefaults()
        {
            projectile.alpha = 100;
            projectile.width = 2; //Set the hitbox width
            projectile.height = 38; //Set the hitbox height
            projectile.timeLeft = 190; //The amount of time the projectile is alive for
            projectile.penetrate = 1; //Tells the game how many enemies it can hit before being destroyed
            projectile.friendly = true; //Tells the game whether it is friendly to players/friendly npcs or not
            projectile.hostile = false; //Tells the game whether it is hostile to players or not
            projectile.tileCollide = true; //Tells the game whether or not it can collide with a tile
            projectile.ignoreWater = true; //Tells the game whether or not projectile will be affected by water
            projectile.ranged = true; //Tells the game whether it is a ranged projectile or not
            projectile.aiStyle = 0; //How the projectile works, 0 makes the projectile just go straight towards your cursor
        }




        public override void AI()
        {
            Dust.NewDust(new Vector2(projectile.position.X, projectile.position.Y), projectile.width, projectile.height, DustID.PinkFlame, projectile.velocity.X * 1.2f, projectile.velocity.Y * 1.2f, 130, default(Color), 1.75f);
            projectile.rotation = (float)Math.Atan2((double)projectile.velocity.Y, (double)projectile.velocity.X) + 1.57f;
        }

    }
}