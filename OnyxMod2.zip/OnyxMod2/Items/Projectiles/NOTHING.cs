using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;


namespace OnyxMod2.Items.Projectiles
{
    public class NOTHING : ModProjectile
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Universal Laser");
        }

        public override void SetDefaults()
        {
            Main.projFrames[projectile.type] = 4;

            projectile.alpha = 255;
            projectile.width = 14;
            projectile.height = 40;
            projectile.timeLeft = 1;
            projectile.penetrate = 1;
            projectile.friendly = true;
            projectile.hostile = false;
            projectile.tileCollide = true;
            projectile.ignoreWater = true;
            projectile.melee = true;
            projectile.aiStyle = 0;
        }




    }
}