
using System;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items.Projectiles
{


public class LCP1 : Hovershooter
{
        private float rot;
        private Vector2 rotVec = new Vector2(0.0f, 90.0f);
        public override void SetStaticDefaults()
    {
        DisplayName.SetDefault("Heart Crystal");
    }
        public override bool PreDraw(SpriteBatch spriteBatch, Color lightColor)
        {
            //Redraw the projectile with the color not influenced by light
            Vector2 drawOrigin = new Vector2(Main.projectileTexture[projectile.type].Width * 0.5f, projectile.height * 0.5f);
            for (int k = 0; k < projectile.oldPos.Length; k++)
            {
                Vector2 drawPos = projectile.oldPos[k] - Main.screenPosition + drawOrigin + new Vector2(0f, projectile.gfxOffY);
                Color color = projectile.GetAlpha(lightColor) * ((float)(projectile.oldPos.Length - k) / (float)projectile.oldPos.Length);
                spriteBatch.Draw(Main.projectileTexture[projectile.type], drawPos, null, color, projectile.rotation, drawOrigin, projectile.scale, SpriteEffects.None, 0f);
            }
            return true;
        }

        public sealed override void SetDefaults()
        {
            projectile.netImportant = true;
            projectile.width = 30;
        projectile.height = 30;
        projectile.tileCollide = false;
        projectile.aiStyle = 0;
            projectile.timeLeft = 3600;
        projectile.friendly = true;
        projectile.minion = true;
        projectile.penetrate = 3;
            inertia = 20f;
            shootCool = 25f;
            shootSpeed = 45f;
            
        }


        public override void CheckActive()
        {
            Player player = Main.player[projectile.owner];
            MyPlayer modPlayer = MyPlayer.Get(player);
            if (player.dead)
            {
                modPlayer.memee = false;
            }
            if (modPlayer.memee)
            {
                projectile.timeLeft = 2;
            }
        }

        public override bool MinionContactDamage()
    {
        return true;
    }



        /*
        public override void AI()
    {


            this.rot += 0.06f;

            projectile.Center = Main.player[projectile.owner].Center + OnyxUti.RotateVector(new Vector2(), this.rotVec, this.rot + projectile.ai[0] * 20.14f);
            if (Main.rand.NextBool(1, 5))
            {
                float x = projectile.velocity.X / 3f;
                float y = projectile.velocity.Y / 3f;
                int dust = Dust.NewDust(projectile.position, projectile.width, projectile.height, 172, 0.0f, 0.0f, 0, new Color(), 1.0f);
                Main.dust[dust].position.X = projectile.Center.X - x;
                Main.dust[dust].position.Y = projectile.Center.Y - y;
                Main.dust[dust].noGravity = true;
                Main.dust[dust].scale += Main.rand.NextFloat() * 1f;

            }
            Player player = Main.player[projectile.owner];

        #region Active check
        // This is the "active check", makes sure the minion is alive while the player is alive, and despawns if not
        #endregion

        #region General behavior
        Vector2 idlePosition = player.Center;
        idlePosition.Y -= 48f; // Go up 48 coordinates (three tiles from the center of the player)

        // If your minion doesn't aimlessly move around when it's idle, you need to "put" it into the line of other summoned minions
        // The index is projectile.minionPos
        float minionPositionOffsetX = (10 + projectile.minionPos * 40) * -player.direction;
        idlePosition.X += minionPositionOffsetX; // Go behind the player

        // All of this code below this line is adapted from Spazmamini code (ID 388, aiStyle 66)

        // Teleport to player if distance is too big
        Vector2 vectorToIdlePosition = idlePosition - projectile.Center;
        float distanceToIdlePosition = vectorToIdlePosition.Length();
        if (Main.myPlayer == player.whoAmI && distanceToIdlePosition > 2000f)
        {
            // Whenever you deal with non-regular events that change the behavior or position drastically, make sure to only run the code on the owner of the projectile,
            // and then set netUpdate to true
            projectile.position = idlePosition;
            projectile.velocity *= 0.1f;
            projectile.netUpdate = true;
        }

        // If your minion is flying, you want to do this independently of any conditions
        float overlapVelocity = 0.04f;
        for (int i = 0; i < Main.maxProjectiles; i++)
        {
            // Fix overlap with other minions
            Projectile other = Main.projectile[i];
            if (i != projectile.whoAmI && other.active && other.owner == projectile.owner && Math.Abs(projectile.position.X - other.position.X) + Math.Abs(projectile.position.Y - other.position.Y) < projectile.width)
            {
                if (projectile.position.X < other.position.X) projectile.velocity.X -= overlapVelocity;
                else projectile.velocity.X += overlapVelocity;

                if (projectile.position.Y < other.position.Y) projectile.velocity.Y -= overlapVelocity;
                else projectile.velocity.Y += overlapVelocity;
         
                }
        } */


        Vector2 flyTo;
        int identity = 0;
        int sniperCount = 0;

        NPC target;
        int timer;
        public override void Kill(int timeLeft)
        {



                // Play explosion sound
                Main.PlaySound(SoundID.Item27, projectile.position);
                // Smoke Dust spawn
                for (int i = 0; i < 50; i++)
                {
                    int dustIndex = Dust.NewDust(new Vector2(projectile.position.X, projectile.position.Y), projectile.width, projectile.height, DustID.CrystalPulse, 0f, 0f, 180, default(Color), 1f);
                    Main.dust[dustIndex].velocity *= 1.4f;
                }
                // Fire Dust spawn
                for (int i = 0; i < 80; i++)
                {
                    int dustIndex = Dust.NewDust(new Vector2(projectile.position.X, projectile.position.Y), projectile.width, projectile.height, DustID.CrystalPulse, 0f, 0f, 180, default(Color), 1.5f);
                    Main.dust[dustIndex].noGravity = true;
                    Main.dust[dustIndex].velocity *= 5f;
                    dustIndex = Dust.NewDust(new Vector2(projectile.position.X, projectile.position.Y), projectile.width, projectile.height, DustID.CrystalPulse, 0f, 0f, 180, default(Color), 1.5f);
                    Main.dust[dustIndex].velocity *= 3f;
                }
            
        }
        public override void AI()
        {


            projectile.rotation += 0.2f;
            this.rot += 0.04f;

            projectile.Center = Main.player[projectile.owner].Center + OnyxUti.RotateVector(new Vector2(), this.rotVec, this.rot + projectile.ai[0] * 20.14f);
            if (Main.rand.NextBool(1, 5))
            {
                float x = projectile.velocity.X / 3f;
                float y = projectile.velocity.Y / 3f;
                int dust = Dust.NewDust(projectile.position, projectile.width, projectile.height, DustID.CrystalPulse, 0.0f, 0.0f, 0, new Color(), 1.0f);
                Main.dust[dust].position.X = projectile.Center.X - x;
                Main.dust[dust].position.Y = projectile.Center.Y - y;
                Main.dust[dust].noGravity = true;
                Main.dust[dust].scale += Main.rand.NextFloat() * 1f;

            }
            Player player = Main.player[projectile.owner];


            MyPlayer modPlayer = player.GetModPlayer<MyPlayer>();
            sniperCount = player.ownedProjectileCounts[mod.ProjectileType("LCP1")];
            if (modPlayer.memee)
            {
                projectile.timeLeft = 2;
            }
            for (int p = 0; p < 1000; p++)
            {
                if (Main.projectile[p].type == mod.ProjectileType("LCP1"))
                {
                    if (p == projectile.whoAmI)
                    {
                        break;
                    }
                    else
                    {
                        identity++;
                    }
                }
            }














            identity = 0;

        }




    


}
}