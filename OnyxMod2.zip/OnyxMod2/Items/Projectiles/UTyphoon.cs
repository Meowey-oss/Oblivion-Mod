using System;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items.Projectiles
{
    public class UTyphoon : ModProjectile
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Ultimate Typhoon");
            ProjectileID.Sets.TrailCacheLength[projectile.type] = 5;
            ProjectileID.Sets.TrailingMode[projectile.type] = 0;
        }

        public override bool PreDraw(SpriteBatch spriteBatch, Color lightColor)
        {
            //Redraw the projectile with the color not influenced by light
            Vector2 drawOrigin = new Vector2(Main.projectileTexture[projectile.type].Width * 0.5f, projectile.height * 0.5f);
            for (int k = 0; k < projectile.oldPos.Length; k++)
            {
                Vector2 drawPos = projectile.oldPos[k] - Main.screenPosition + drawOrigin + new Vector2(0f, projectile.gfxOffY);
                Color color = projectile.GetAlpha(lightColor) * ((float)(projectile.oldPos.Length - k) / (float)projectile.oldPos.Length);
                spriteBatch.Draw(Main.projectileTexture[projectile.type], drawPos, null, color, projectile.rotation, drawOrigin, projectile.scale, SpriteEffects.None, 0f);
            }
            return true;
        }
        public override void SetDefaults()
        {

            projectile.width = 62;
            projectile.height = 62;
            projectile.hostile = false;
            projectile.light = 1.5f;
            projectile.friendly = true;
            projectile.penetrate = 10;
            projectile.magic = true;
            projectile.tileCollide = true;
            projectile.ignoreWater = true;
            projectile.timeLeft = 200;
            aiType = 14;


        }
        public override void OnHitNPC(NPC n, int damage, float knockback, bool crit)
        {
            projectile.timeLeft += 10;
            projectile.alpha = 100;

        }

        public override bool OnTileCollide(Vector2 velocityChange)
        {
            projectile.timeLeft -= 50;

            if (projectile.velocity.X != velocityChange.X)
            {
                projectile.velocity.X = -velocityChange.X + 0; //Goes in the opposite direction with half of its x velocity
            }
            if (projectile.velocity.Y != velocityChange.Y)
            {
                projectile.velocity.Y = -velocityChange.Y + 0; //Goes in the opposite direction with half of its y velocity
            }
            return false;
        }

        public override void AI()
        {


            for (int i = 0; i < 200; i++)
            {
                NPC target = Main.npc[i];
                //If the npc is hostile
                if (!target.friendly && target.active && !target.dontTakeDamage)
                {
                    //Get the shoot trajectory from the projectile and target
                    float shootToX = target.position.X + (float)target.width * 0.5f - projectile.Center.X;
                    float shootToY = target.position.Y - projectile.Center.Y;
                    float distance = (float)System.Math.Sqrt((double)(shootToX * shootToX + shootToY * shootToY));
                    if (projectile.timeLeft < 100)
                    {
                        projectile.alpha = 200;
                        //If the distance between the live targeted npc and the projectile is less than 480 pixels
                        if (distance < 280f && !target.friendly && target.active)
                        {
                            //Divide the factor, 3f, which is the desired velocity
                            distance = 4f / distance;

                            //Multiply the distance by a multiplier if you wish the projectile to have go faster
                            shootToX *= distance * 6;
                            shootToY *= distance * 6;

                            //Set the velocities to the shoot values
                            projectile.velocity.X = shootToX;
                            projectile.velocity.Y = shootToY;
                        }
                    }

                        if (projectile.timeLeft > 100)
                        {
                            //If the distance between the live targeted npc and the projectile is less than 480 pixels
                            if (distance < 280f && distance > 90f && !target.friendly && target.active)
                            {
                                //Divide the factor, 3f, which is the desired velocity
                                distance = 4f / distance;

                                //Multiply the distance by a multiplier if you wish the projectile to have go faster
                                shootToX *= distance * 6;
                                shootToY *= distance * 6;

                                //Set the velocities to the shoot values
                                projectile.velocity.X = shootToX;
                                projectile.velocity.Y = shootToY;
                            }
                        }
                    
                }
            }

            projectile.rotation += 0.2f;
            Dust.NewDust(projectile.position + projectile.velocity, projectile.width, projectile.height, DustID.LavaMoss, projectile.velocity.X * 0.5f, projectile.velocity.Y * 0.5f);
        }

    }

}