﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace OnyxMod2.Items.Projectiles
{
    public class ThrownProjectile2 : ModProjectile
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Metal Arrow");
            ProjectileID.Sets.TrailCacheLength[projectile.type] = 10;
            ProjectileID.Sets.TrailingMode[projectile.type] = 0;
        }

        public override void SetDefaults()
        {
            
            projectile.width = 30;
            projectile.height = 40;
            projectile.hostile = false;
            projectile.friendly = true;
            projectile.penetrate = 4;
            projectile.thrown = true;
            projectile.tileCollide = true;
            projectile.ignoreWater = false;
            projectile.aiStyle = ProjectileID.ChlorophyteBullet;
            projectile.timeLeft = 18000;

        }

        public override bool PreDraw(SpriteBatch spriteBatch, Color lightColor)
        {
            //Redraw the projectile with the color not influenced by light
            Vector2 drawOrigin = new Vector2(Main.projectileTexture[projectile.type].Width * 0.5f, projectile.height * 0.5f);
            for (int k = 0; k < projectile.oldPos.Length; k++)
            {
                Vector2 drawPos = projectile.oldPos[k] - Main.screenPosition + drawOrigin + new Vector2(0f, projectile.gfxOffY);
                Color color = projectile.GetAlpha(lightColor) * ((float)(projectile.oldPos.Length - k) / (float)projectile.oldPos.Length);
                spriteBatch.Draw(Main.projectileTexture[projectile.type], drawPos, null, color, projectile.rotation, drawOrigin, projectile.scale, SpriteEffects.None, 0f);
            }
            return true;
        }
        public override void AI()
        {
            for (int i = 0; i < 200; i++)
            {

                    NPC target = Main.npc[i];
                //If the npc is hostile
                if (!target.friendly && target.active && !target.dontTakeDamage)
                {
                    //Get the shoot trajectory from the projectile and target
                    float shootToX = target.position.X + (float)target.width * 0.5f - projectile.Center.X;
                    float shootToY = target.position.Y - projectile.Center.Y;
                    float distance = (float)System.Math.Sqrt((double)(shootToX * shootToX + shootToY * shootToY));

                    if (distance < 30f && !target.friendly && target.active)
                    {
                      
                        projectile.alpha = 254;
                    }

                    //If the distance between the live targeted npc and the projectile is less than 480 pixels
                    if (distance < 120f && !target.friendly && target.active)
                    {
                        //Divide the factor, 3f, which is the desired velocity
                        distance = 3f / distance;

                        //Multiply the distance by a multiplier if you wish the projectile to have go faster
                        shootToX *= distance * 6;
                        shootToY *= distance * 6;

                        //Set the velocities to the shoot values
                        projectile.velocity.X = shootToX;
                        projectile.velocity.Y = shootToY;
                    }
                }
            }
            Dust.NewDust(projectile.position + projectile.velocity, projectile.width, projectile.height, DustID.PlatinumCoin, projectile.velocity.X * 0.5f, projectile.velocity.Y * 0.5f);
            projectile.rotation = (float)Math.Atan2((double)projectile.velocity.Y, (double)projectile.velocity.X) + 1.57f;
        }

        public override void Kill(int timeLeft)
        {

            // If we are the original projectile, spawn the 5 child projectiles

            if (projectile.ai[1] == 0)
            {


                // Play explosion sound
                Main.PlaySound(SoundID.Item14, projectile.position);
                // Smoke Dust spawn
                for (int i = 0; i < 50; i++)
                {
                    int dustIndex = Dust.NewDust(new Vector2(projectile.position.X, projectile.position.Y), projectile.width, projectile.height, DustID.AncientLight, 0f, 0f, 480, default(Color), 2f);
                    Main.dust[dustIndex].velocity *= 1.4f;
                }
                // Fire Dust spawn
                for (int i = 0; i < 80; i++)
                {
                    int dustIndex = Dust.NewDust(new Vector2(projectile.position.X, projectile.position.Y), projectile.width, projectile.height, DustID.AncientLight, 0f, 0f, 480, default(Color), 3f);
                    Main.dust[dustIndex].noGravity = true;
                    Main.dust[dustIndex].velocity *= 5f;
                    dustIndex = Dust.NewDust(new Vector2(projectile.position.X, projectile.position.Y), projectile.width, projectile.height, DustID.AncientLight, 0f, 0f, 480, default(Color), 2f);
                    Main.dust[dustIndex].velocity *= 3f;
                }

                // reset size to normal width and height.
                projectile.position.X = projectile.position.X + (float)(projectile.width / 2);
                projectile.position.Y = projectile.position.Y + (float)(projectile.height / 2);
                projectile.width = 10;
                projectile.height = 10;
                projectile.damage = 300;
                projectile.position.X = projectile.position.X - (float)(projectile.width / 2);
                projectile.position.Y = projectile.position.Y - (float)(projectile.height / 2);

                // TODO, tmodloader helper method
                {
                    int explosionRadius = 49;
                    //if (projectile.type == 29 || projectile.type == 470 || projectile.type == 637)
                    //{
                    //  explosionRadius = 15;
                    //}
                    int minTileX = (int)(projectile.position.X / 16f - (float)explosionRadius);
                    int maxTileX = (int)(projectile.position.X / 16f + (float)explosionRadius);
                    int minTileY = (int)(projectile.position.Y / 16f - (float)explosionRadius);
                    int maxTileY = (int)(projectile.position.Y / 16f + (float)explosionRadius);
                    if (minTileX < 0)
                    {
                        minTileX = 0;
                    }
                    if (maxTileX > Main.maxTilesX)
                    {
                        maxTileX = Main.maxTilesX;
                    }
                    if (minTileY < 0)
                    {
                        minTileY = 0;
                    }
                    if (maxTileY > Main.maxTilesY)
                    {
                        maxTileY = Main.maxTilesY;
                    }
                    bool canKillWalls = false;
                    for (int x = minTileX; x <= maxTileX; x++)
                    {
                        for (int y = minTileY; y <= maxTileY; y++)
                        {
                            float diffX = Math.Abs((float)x - projectile.position.X / 16f);
                            float diffY = Math.Abs((float)y - projectile.position.Y / 16f);
                            double distance = Math.Sqrt((double)(diffX * diffX + diffY * diffY));
                            if (distance < (double)explosionRadius && Main.tile[x, y] != null && Main.tile[x, y].wall == 0)
                            {
                                canKillWalls = true;
                                break;
                            }
                        }
                    }
                    for (int i = minTileX; i <= maxTileX; i++)
                    {
                        for (int j = minTileY; j <= maxTileY; j++)
                        {
                            float diffX = Math.Abs((float)i - projectile.position.X / 16f);
                            float diffY = Math.Abs((float)j - projectile.position.Y / 16f);
                            double distanceToTile = Math.Sqrt((double)(diffX * diffX + diffY * diffY));
                            if (distanceToTile < (double)explosionRadius)
                            {
                                bool canKillTile = false;
                                if (Main.tile[i, j] != null && Main.tile[i, j].active())
                                {
                                    canKillTile = false;
                                    if (Main.tileDungeon[(int)Main.tile[i, j].type] || Main.tile[i, j].type == 88 || Main.tile[i, j].type == 21 || Main.tile[i, j].type == 26 || Main.tile[i, j].type == 107 || Main.tile[i, j].type == 108 || Main.tile[i, j].type == 111 || Main.tile[i, j].type == 226 || Main.tile[i, j].type == 237 || Main.tile[i, j].type == 221 || Main.tile[i, j].type == 222 || Main.tile[i, j].type == 223 || Main.tile[i, j].type == 211 || Main.tile[i, j].type == 404)
                                    {
                                        canKillTile = false;
                                    }
                                    if (!Main.hardMode && Main.tile[i, j].type == 58)
                                    {
                                        canKillTile = false;
                                    }
                                    if (!TileLoader.CanExplode(i, j))
                                    {
                                        canKillTile = false;
                                    }
                                    if (canKillTile)
                                    {
                                        WorldGen.KillTile(i, j, false, false, false);
                                        if (!Main.tile[i, j].active() && Main.netMode != 0)
                                        {
                                            NetMessage.SendData(17, -1, -1, null, 0, (float)i, (float)j, 0f, 0, 0, 0);
                                        }
                                    }
                                }
                                if (canKillTile)
                                {
                                    for (int x = i - 1; x <= i + 1; x++)
                                    {
                                        for (int y = j - 1; y <= j + 1; y++)
                                        {
                                            if (Main.tile[x, y] != null && Main.tile[x, y].wall > 0 && canKillWalls && WallLoader.CanExplode(x, y, Main.tile[x, y].wall))
                                            {
                                                WorldGen.KillWall(x, y, false);
                                                if (Main.tile[x, y].wall == 0 && Main.netMode != 0)
                                                {
                                                    NetMessage.SendData(17, -1, -1, null, 2, (float)x, (float)y, 0f, 0, 0, 0);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        public override void ModifyHitNPC(NPC target, ref int damage, ref float knockback, ref bool crit, ref int hitDirection)
        {
            target.AddBuff(mod.BuffType("Buff4"), 100);
        }
    }

}