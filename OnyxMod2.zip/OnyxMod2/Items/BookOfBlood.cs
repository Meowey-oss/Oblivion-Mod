﻿
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class BookOfBlood : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Bloody Tome");
        }

        public override void SetDefaults()
        {
            item.width = 20;
            item.knockBack = 8f;
            item.value = Item.buyPrice(0, 30, 0, 0);
            item.damage = 90;
            item.height = 40;
            item.useTime = 22;
            item.useAnimation = 22;
            item.useStyle = 5;
            item.noMelee = true;
            item.rare = 10;
            item.mana = 16;
            
            item.UseSound = SoundID.Item7;
            item.autoReuse = true;
            item.shootSpeed = 14.1f;
            item.magic = true;
            item.shoot = ModContent.ProjectileType<Projectiles.MagicProjectile1>();
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.SpellTome, 1);
            recipe.AddIngredient(null, "SoulOfRight", 10);
            recipe.AddIngredient(ItemID.SoulofSight, 10);
            recipe.AddIngredient(null, "BloodBar", 5);
            recipe.AddTile(null, "BloodAltar");
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}