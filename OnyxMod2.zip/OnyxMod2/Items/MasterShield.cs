using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class MasterShield : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Master Shield");
            Tooltip.SetDefault("You gain the immunity against Many Effects, Fall Damage and Knockback"+ "\nGrants the Ability to dash" + "\nEnemies take full contact damage they did to you.");
        }

        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.defense = 20;
            item.value = Item.buyPrice(0, 7, 0, 0);
            item.rare = 9;
            item.accessory = true;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {

            if (player.thorns < 1f)
            {
                player.thorns = 1.0f;
            }

            player.dash = 1;
            player.noFallDmg = true;
            player.noKnockback = true;
            player.buffImmune[BuffID.OnFire] = true;
            player.buffImmune[BuffID.Burning] = true;
            player.buffImmune[BuffID.Weak] = true;
            player.buffImmune[BuffID.Darkness] = true;
            player.buffImmune[BuffID.BrokenArmor] = true;
            player.buffImmune[BuffID.Poisoned] = true;
            player.buffImmune[BuffID.Venom] = true;
            player.buffImmune[BuffID.Confused] = true;
            player.buffImmune[BuffID.Slow] = true;
            player.lavaImmune = true;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(null, "BurningShield", 1);
            recipe.AddIngredient(null, "EXCore", 3);
            recipe.AddIngredient(null, "OnyxBar", 5);
            recipe.AddIngredient(null, "WormEye", 1);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}