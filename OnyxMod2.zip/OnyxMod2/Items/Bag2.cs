using Terraria.ModLoader;
using Terraria.ID;
using Terraria;

namespace OnyxMod2.Items
{



    public class Bag2 : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Treasure Bag");
            Tooltip.SetDefault("Right Click To Open"+ "\nThe Boss Can Drop:" + "\nOne of 4 Different Items/Weapons with a 100% chance"+ "\n1% Chance for a Dev Weapon (2% in Expert Mode)" + "\nRandom amount of Gel and Living Fire Block"+ "\nIf you kill the Boss while hes Enraged you have a 100% chance to get a Fire Stone");
        }
        public override void SetDefaults()
        {
            item.width = 12;
            item.height = 12;
            item.useStyle = -1;
            
            item.consumable = true;
            item.rare = -12;
            item.maxStack = 30;
        }

        public override bool CanRightClick()
        {
            return true;
        }

        public override void RightClick(Player player)
        {
            int choice = Main.rand.Next(4);

            if (choice == 0)
            {
                player.QuickSpawnItem(mod.ItemType("FireSpellBook"));
            }

            if (choice == 1)
            {
                player.QuickSpawnItem(mod.ItemType("Accessories4"));
            }

            if (choice == 2)
            {
                player.QuickSpawnItem(mod.ItemType("LavaBow"));
            }

            if (choice == 3)
            {
                player.QuickSpawnItem(mod.ItemType("SwordOfFire"));
            }
            player.QuickSpawnItem(ItemID.Gel, Main.rand.Next(20, 30));
            player.QuickSpawnItem(ItemID.LivingFireBlock, Main.rand.Next(20, 60));
            player.QuickSpawnItem(ItemID.GoldCoin, Main.rand.Next(1, 15));
        }

    }
}