using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class SuperSword : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("True Blades");
            Tooltip.SetDefault("Enemies take 50x the contact damage they did to you."+"\nIncreases Melee Speed by 100% but decreases Melee damage by 30%.");
        }

        public override void SetDefaults()
        {
            item.width = 80;
            item.height = 58;
            item.defense = 1;
            item.expert = true;
            item.expertOnly = true;
            item.value = Item.buyPrice(1, 0, 0, 0);
            item.rare = -12;
            item.accessory = true;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.meleeDamage -= 0.30f;
            player.meleeSpeed += 1f;

            if (player.thorns < 1f)
            {
                player.thorns = 50.0f;
            }
        }


    }
}