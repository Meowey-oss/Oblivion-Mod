﻿using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;

namespace OnyxMod2.Items
{
    [AutoloadEquip(EquipType.Legs)]
    public class ArmorBoots2 : ModItem
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Oblivion Boots(S)");
            Tooltip.SetDefault("+ 40% Movement Speed");
        }

        public override void SetDefaults()
        {
            item.width = 41;
            item.height = 40;
            item.value = 100000;
            item.rare = 9;
            item.defense = 10;
        }

        public override bool IsArmorSet(Item head, Item body, Item legs)
        {
            return head.type == mod.ItemType("ArmorHelmet2") && body.type == mod.ItemType("ArmorBreastplate2");
        }



        public override void UpdateEquip(Player player)
        {
            player.moveSpeed += 0.40f;
        }
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+20% Attack Damage for Summoner and decreases all other damage by -10%." + "\nImmunity to 'Venom','OnFire','CursedInferno' and 'Lava'" + " + 2 Max Minion";
            MyPlayer.minikn = true;
            player.magicDamage -= 0.10f;
            player.thrownDamage -= 0.10f;
            player.meleeDamage -= 0.10f;
            player.rangedDamage -= 0.10f;
            player.minionDamage += 0.20f;
            player.lavaImmune = true;
            player.maxMinions++;
            player.maxMinions++;
            player.buffImmune[BuffID.Venom] = true;
            player.buffImmune[BuffID.OnFire] = true;
            player.buffImmune[BuffID.CursedInferno] = true;
        }




        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(null, "OnyxBar", 15);
            recipe.AddIngredient(null, "EXCore", 5);
            recipe.AddIngredient(null, "WormEye", 1);
            recipe.AddIngredient(null, "EyeShard", 2);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }


    }
}
