using Terraria.ModLoader;
using Terraria.ID;
using Terraria;

namespace OnyxMod2.Items
{



    public class Bag3 : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Treasure Bag");
            Tooltip.SetDefault("Right Click To Open"+ "\nThe Boss Can Drop:" + "\nOne of 3 Different Items/Weapons with a 100% chance"+ "\nNo Legendary Weapons available for now");
        }
        public override void SetDefaults()
        {
            item.width = 12;
            item.height = 12;
            item.useStyle = -1;
            
            item.consumable = true;
            item.rare = -12;
            item.maxStack = 30;
        }

        public override bool CanRightClick()
        {
            return true;
        }

        public override void RightClick(Player player)
        {
            int choice = Main.rand.Next(3);

            if (choice == 0)
            {
                player.QuickSpawnItem(mod.ItemType("Crystalized_Knive"));
            }

            if (choice == 1)
            {
                player.QuickSpawnItem(mod.ItemType("Crystalknives"));
            }

            if (choice == 2)
            {
                player.QuickSpawnItem(mod.ItemType("CrystalSprayer"));
            }
            player.QuickSpawnItem(ItemID.SilverCoin, Main.rand.Next(1, 15));
        }

    }
}