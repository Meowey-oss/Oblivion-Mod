﻿
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class Emblem3 : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Strength Emblem");
            Tooltip.SetDefault("Increases General damage by 8%");
        }

        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.rare = -12;
            item.accessory = true;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.meleeDamage += 0.08f;
            player.magicDamage += 0.08f;
            player.minionDamage += 0.08f;
            player.thrownDamage += 0.08f;
            player.rangedDamage += 0.08f;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(ItemID.HallowedBar, 7);
            recipe.AddIngredient(ItemID.SoulofMight, 20);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }


    }
}