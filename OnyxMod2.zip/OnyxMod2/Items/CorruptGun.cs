﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class CorruptGun : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Corrupted Blaster");
            
        }

        public override void SetDefaults()
        {
            item.width = 60;
            item.knockBack = 2f;
            item.value = Item.buyPrice(1, 0, 0, 0);
            item.damage = 300;
            item.height = 40;
            item.useTime = 18;
            item.useAnimation = 18;
            item.useStyle = 5;
            item.noMelee = true;
            item.mana = 9;
            item.rare = 9;
            item.UseSound = SoundID.Item12;
            item.autoReuse = true;
            item.shoot = ModContent.ProjectileType<Projectiles.LASER1>();
            item.shootSpeed = 25.1f;
            item.magic = true;
            

        }




    }
}
