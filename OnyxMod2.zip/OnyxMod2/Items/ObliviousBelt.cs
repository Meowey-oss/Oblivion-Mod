﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class ObliviousBelt : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Oblivious Belt");
            Tooltip.SetDefault("You don't regen Health naturally but you also don't get the damaging effect from most of the Debuffs." + "\nYou also gain Night Vision." + "\n'Even an Eye has balance.'");
        }

        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.expert = true;
            item.expertOnly = true;
            item.value = Item.buyPrice(0, 2, 0, 0);
            item.rare = -12;
            item.accessory = true;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {


            player.lifeRegen = 0;
            player.lifeRegenCount = 0;
            player.nightVision = true;

        }

       



    }
}