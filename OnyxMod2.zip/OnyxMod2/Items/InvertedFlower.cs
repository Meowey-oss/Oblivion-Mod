using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class InvertedFlower : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Synus' Inverted Flower");
            Tooltip.SetDefault("!sunyS ,em as'tI" + "\nLegendary");
        }

        public override void SetDefaults()
        {
            item.width = 1;
            item.knockBack = 2f;
            item.value = 10000;
            item.damage = 42;
            item.height = 1;
            item.useTime = 11;
            item.useAnimation = 11;
            item.useStyle = 1;
            item.noMelee = true;
            item.rare = -12;
            item.autoReuse = true;
            item.shoot = ModContent.ProjectileType<Projectiles.Proj2>();
            item.shootSpeed = 32.1f;
            item.magic = true;
            item.mana = 7;

        }


        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            float numberProjectiles = 2;
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedByRandom(MathHelper.ToRadians(22));
                float scale = 1f - (Main.rand.NextFloat() * .3f);
                perturbedSpeed = perturbedSpeed * scale;
                Projectile.NewProjectile(position.X, position.Y, perturbedSpeed.X, perturbedSpeed.Y, type, damage, knockBack, player.whoAmI);
            }
            return false;
        }


    }
}