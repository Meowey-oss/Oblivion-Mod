﻿using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class BulletBall4 : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Hellstone Bullet Ball");
        }

        public override void SetDefaults()
        {
            item.width = 50;
            item.knockBack = 2f;
            item.value = Item.buyPrice(0, 10, 0, 0);
            item.damage = 35;
            item.height = 50;
            item.noUseGraphic = true;
            item.useTime = 98;
            item.useAnimation = 98;
            item.useStyle = 5;
            item.noMelee = true;
            item.rare = 4;
            item.UseSound = SoundID.Item17;
            item.autoReuse = true;
            item.shoot = mod.ProjectileType("BB4");
            item.shootSpeed = 15.1f;
            item.ranged = true;

        }


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(ItemID.Obsidian, 50);
            recipe.AddIngredient(ItemID.Bone, 10);
            recipe.AddIngredient(ItemID.AshBlock, 100);
            recipe.AddIngredient(ItemID.HellstoneBar, 15);
            recipe.AddRecipeGroup("BulletBalls", 1);
            recipe.AddTile(TileID.Hellforge);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}