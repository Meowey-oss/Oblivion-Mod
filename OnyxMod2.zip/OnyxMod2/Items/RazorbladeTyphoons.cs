using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class RazorbladeTyphoons : ModItem
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Baby Typhoons");
            Tooltip.SetDefault("Can shoot 3 small Typhoons");
        }

        public override void SetDefaults()
        {
            item.damage = 70;
            item.magic = true;
            item.mana = 20;
            item.width = 5;
            item.height = 5;
            item.knockBack = 11f;
            item.noMelee = true;
            item.autoReuse = true;
            item.UseSound = SoundID.Item84;
            item.value = Item.buyPrice(0, 20, 0, 0);
            item.useAnimation = 18;
            item.useTime = 18;
            item.useStyle = 5;
            item.shoot = mod.ProjectileType("BTyphoon");
            item.shootSpeed = 12.7f;
            item.rare = 8;

        }

        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            float numberProjectiles = 3;
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedByRandom(MathHelper.ToRadians(30));
                Projectile.NewProjectile(position.X, position.Y, perturbedSpeed.X, perturbedSpeed.Y, type, damage, knockBack, player.whoAmI);
            }
            return false;
        }


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.RazorbladeTyphoon, 3);
            recipe.AddIngredient(ItemID.ManaCrystal, 15);
            recipe.AddIngredient(ItemID.FragmentNebula, 5);
            recipe.AddIngredient(ItemID.SoulofFright, 50);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}
