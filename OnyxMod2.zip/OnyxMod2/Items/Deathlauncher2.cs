﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class Deathlauncher2 : ModItem
    {
        public override void SetStaticDefaults()
        { 
            DisplayName.SetDefault("Death Launcher");
            Tooltip.SetDefault("Can shoot a powerful Rocket wich explodes into many little projectiles wich deal 80% the damage."+ "\nThe Projectiles Apply the 'OnMagma' Debuff wich is stronger than the OnFire Debuff."+"\nLittle Projectiles have a chance to heal the Player by 1/2/3 Hitpoints." + "\nEnemies with the OnFire immunty will take Extra damage unless they are immune to this Debuff too."+ "\nPunish them for their Resistance of Fire.");
        }

        public override void SetDefaults()
        {
            item.width = 1;
            item.knockBack = 20f;
            item.value = 100000;
            item.damage = 520;
            item.height = 1;
            item.useTime = 70;
            item.useAnimation = 70;
            item.useStyle = 5;
            item.noMelee = true;
            item.rare = 10;
            item.UseSound = SoundID.Item18;
            item.autoReuse = true;
            item.shoot = ModContent.ProjectileType<Projectiles.SuperRocket>();
            item.shootSpeed = 16.1f;
            item.ranged = true;

        }


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.FragmentVortex, 15);
            recipe.AddIngredient(ItemID.HallowedBar, 100);
            recipe.AddIngredient(ItemID.HallowedRepeater, 1);
            recipe.AddIngredient(null, ("EXCore"), 1);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}

