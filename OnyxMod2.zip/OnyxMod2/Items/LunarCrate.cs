using Terraria.ModLoader;
using Terraria.ID;
using Terraria;

namespace OnyxMod2.Items
{



    public class LunarCrate : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Lunar Crate");
            Tooltip.SetDefault("Right Click To Open" + "\nCan drop Fragments and other Moonlord stuff.");
        }
        public override void SetDefaults()
        {
            item.width = 12;
            item.height = 12;
            item.useStyle = -1;
            item.consumable = true;
            item.rare = 8;
            item.maxStack = 200;
        }

        public override bool CanRightClick()
        {
            return true;
        }

        public override void RightClick(Player player)
        {



            if (Main.rand.Next(3) == 0)
            {
                player.QuickSpawnItem(ItemID.FragmentNebula, Main.rand.Next(1, 5));
            }

            if (Main.rand.Next(3) == 0)
            {
                player.QuickSpawnItem(ItemID.FragmentSolar, Main.rand.Next(1, 5));
            }

            if (Main.rand.Next(3) == 0)
            {
                player.QuickSpawnItem(ItemID.FragmentStardust, Main.rand.Next(1, 5));
            }

            if (Main.rand.Next(3) == 0)
            {
                player.QuickSpawnItem(ItemID.FragmentVortex, Main.rand.Next(1, 5));
            }


            if (Main.rand.Next(50) == 0)
            {
                Main.NewText("You got a Rare item out of the Lunar Crate! ", 55, 153, 155);
                player.QuickSpawnItem(ItemID.SuperHealingPotion, Main.rand.Next(3, 5));
            }

            else if (Main.rand.Next(300) == 0)
            {
                Main.NewText("You got a Very Rare item out of the Lunar Crate! ", 55, 153, 155);
                player.QuickSpawnItem(ItemID.LunarOre, Main.rand.Next(20, 30));
            }

            else if (Main.rand.Next(500) == 0)
            {
                Main.NewText("You got a Very Rare item out of the Lunar Crate! ", 55, 153, 155);
                player.QuickSpawnItem(ItemID.LunarBar, Main.rand.Next(5, 20));
            }






            else if (Main.rand.Next(500) == 0)
            {
                Main.NewText("You got a Legendary Rare item out of the Lunar Crate! GG", 65, 153, 125);
                player.QuickSpawnItem(ItemID.LastPrism, Main.rand.Next(1, 2));
            }

            else if (Main.rand.Next(500) == 0)
            {
                Main.NewText("You got a Legendary Rare item out of the Lunar Crate! GG", 65, 153, 125);
                player.QuickSpawnItem(ItemID.MoonlordTurretStaff, Main.rand.Next(1, 2));
            }

            else if (Main.rand.Next(500) == 0)
            {
                Main.NewText("You got a Legendary Rare item out of the Lunar Crate! GG", 65, 153, 125);
                player.QuickSpawnItem(ItemID.SDMG, Main.rand.Next(1, 2));
            }

            else if (Main.rand.Next(500) == 0)
            {
                Main.NewText("You got a Legendary Rare item out of the Lunar Crate! GG", 65, 153, 125);
                player.QuickSpawnItem(ItemID.StarWrath, Main.rand.Next(1, 2));
            }

            else if (Main.rand.Next(500) == 0)
            {
                Main.NewText("You got a Legendary Rare item out of the Lunar Crate! GG", 65, 153, 125);
                player.QuickSpawnItem(ItemID.Meowmere, Main.rand.Next(1, 2));
            }
            else if (Main.rand.Next(500) == 0)
            { 
                Main.NewText("You got a Legendary Rare item out of the Lunar Crate! GG", 65, 153, 125);
                player.QuickSpawnItem(ItemID.LunarFlareBook, Main.rand.Next(1, 2));
            }
            else if (Main.rand.Next(500) == 0)
            {
                Main.NewText("You got a Legendary Rare item out of the Lunar Crate! GG", 65, 153, 125);
                player.QuickSpawnItem(ItemID.RainbowCrystalStaff, Main.rand.Next(1, 2));
            }
            player.QuickSpawnItem(ItemID.SilverCoin, Main.rand.Next(50, 80));
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(ItemID.LunarOre, 1);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this, 3);
            recipe.AddRecipe();
        }
    }
}