﻿
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class RetinazerRifle : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Retinazer Rifle");
        }

        public override void SetDefaults()
        {
            item.width = 30;
            item.knockBack = 8f;
            item.value = 1000000;
            item.damage = 70;
            item.height = 30;
            item.useTime = 12;
            item.useAnimation = 12;
            item.useStyle = 5;
            item.noMelee = true;
            item.rare = 9;
            item.mana = 3;
            item.UseSound = SoundID.Item33;
            item.autoReuse = true;
            item.shootSpeed = 35.1f;
            item.magic = true;
            item.shoot = ModContent.ProjectileType<Projectiles.RangedProjectile1>();
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.LaserRifle, 1);
            recipe.AddIngredient(ItemID.HallowedBar, 15);
            recipe.AddIngredient(ItemID.SoulofLight, 10);
            recipe.AddIngredient(ItemID.SoulofSight, 10);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}