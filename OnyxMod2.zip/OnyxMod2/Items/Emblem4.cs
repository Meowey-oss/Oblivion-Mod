
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class Emblem4 : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Dragon's Emblem");
            Tooltip.SetDefault("Increases your Movement Speed by +10%, Hit Points by +50, Crit Chance by +5%, Melee Speed by +15%," + "\nMana by +20, Thrown Speed by +20%, Minion Slots by +2, and Damage. by +5%");
        }

        public override void SetDefaults()
        {
            item.width = 52;
            item.height = 40;
            item.rare = 10;
            item.accessory = true;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.maxMinions++;
            player.maxMinions++;
            player.moveSpeed += 1f;
            if (MyWorld.ChallengeMode == false)
            {
                player.statLifeMax2 += 50;
            }
            player.magicCrit += 5;
            player.meleeCrit += 5;
            player.rangedCrit += 5;
            player.thrownCrit += 5;
            player.magicDamage += 0.05f;
            player.meleeDamage += 0.05f;
            player.minionDamage += 0.05f;
            player.rangedDamage += 0.05f;
            player.thrownDamage += 0.05f;
            player.meleeSpeed += 0.15f;
            player.thrownVelocity += 0.20f;
            player.statManaMax2 += 20;

        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(ItemID.HallowedBar, 20);
            recipe.AddIngredient(null, "EyeShard", 10);
            recipe.AddIngredient(null, "OnyxBar", 30);
            recipe.AddIngredient(null, "Emblem1", 1);
            recipe.AddIngredient(null, "Emblem2", 1);
            recipe.AddIngredient(null, "Emblem3", 1);
            recipe.AddIngredient(ItemID.AvengerEmblem, 1);
            recipe.AddIngredient(ItemID.WarriorEmblem, 1);
            recipe.AddIngredient(ItemID.SummonerEmblem, 1);
            recipe.AddIngredient(ItemID.SorcererEmblem, 1);
            recipe.AddIngredient(ItemID.RangerEmblem, 1);
            recipe.AddIngredient(ItemID.DestroyerEmblem, 1);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }




    }
}