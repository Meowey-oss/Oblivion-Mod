﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
namespace OnyxMod2.Items
{
    public class DreamCrusher : ModItem
    {
        internal int lel;
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Dream Crusher");
            Tooltip.SetDefault("Heals the player on melee hit."+ "\nCan spawn Heart Crystals wich protect you."+"\nThere can only be 3 Crystal Hearts.");
        }
        public override void SetDefaults()
        {
            item.damage = 29;
            item.melee = true;
            item.width = 36;
            item.height = 36;
            item.useTime = 18;
            item.useAnimation = 18;
            item.useStyle = ItemUseStyleID.SwingThrow;
            item.shoot = ModContent.ProjectileType<Projectiles.NOTHING>();
            item.knockBack = 9f;
            item.value = Item.buyPrice(0, 12, 0, 0);
            item.rare = -12;
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
        }

        public override void OnHitNPC(Player player, NPC target, int damage, float knockback, bool crit)
        {
            int lifeSteal = damage / 20;
            player.statLife += lifeSteal;
            player.HealEffect(lifeSteal);
        }
        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            if (player.ownedProjectileCounts[ModContent.ProjectileType<Projectiles.LCP1>()] < 3)
            {


                if (lel <= 1)
                {
                    Projectile.NewProjectile(position.X, position.Y, speedX, speedY, mod.ProjectileType("LCP1"), damage + 5, knockBack, player.whoAmI);
                    lel = 15;
                }
                if (lel >= 0)
                {
                    lel--;
                }
            }
            return base.Shoot(player, ref position, ref speedX, ref speedY, ref type, ref damage, ref knockBack);
        }

        public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
 
            recipe.AddIngredient(ItemID.GoldOre, 10);
            recipe.AddIngredient(ItemID.Diamond, 1);
            recipe.AddIngredient(null, "BloodOre", 30);
            recipe.AddIngredient(ItemID.GoldShortsword, 1);
            recipe.AddTile(null, "BloodAltar");
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
        

    }
}
