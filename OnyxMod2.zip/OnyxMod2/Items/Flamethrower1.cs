using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items        //We need this to basically indicate the folder where it is to be read from, so you the texture will load correctly
{
    public class Flamethrower1 : ModItem
    {

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Meowey's Flamethrower");
            Tooltip.SetDefault("\n70% chance to not consume gel" + "\nLegendary");
        }


        public override void SetDefaults()
        {
            item.damage = 430;  //The damage stat for the Weapon.
            item.ranged = true;    //This defines if it does Ranged damage and if its effected by Ranged increasing Armor/Accessories.
            item.width = 42;  //The size of the width of the hitbox in pixels.
            item.height = 16;    //The size of the height of the hitbox in pixels.
            item.useTime = 4;   //How fast the Weapon is used.
            item.useAnimation = 10;     //How long the Weapon is used for.
            item.useStyle = 5;   //The way your Weapon will be used, 1 is the regular sword swing for example
            item.noMelee = true; //so the item's animation doesn't do damage
            item.knockBack = 5.25f;  //The knockback stat of your Weapon.
            item.UseSound = SoundID.Item34; //The sound played when using your Weapon
            item.value = Item.buyPrice(20, 0, 0, 0); //	How much the item is worth, in copper coins, when you sell it to a merchant. It costs 1/5th of this to buy it back from them. An easy way to remember the value is platinum, gold, silver, copper or PPGGSSCC (so this item price is 10gold)
            item.rare = -12;   //The color the title of your Weapon when hovering over it ingame   
            item.autoReuse = true;   //Weather your Weapon will be used again after use while holding down, if false you will need to click again after use to use it again.
            item.shoot = ModContent.ProjectileType<Projectiles.FlamethrowerP1>();
            item.shootSpeed = 4.5f; //This defines the projectile speed when shoot , for flamethrower this make how far the flames can go
            item.useAmmo = AmmoID.Gel; //This defines what ammo this weapon should use.
        }

        public override bool ConsumeAmmo(Player player) //this is where you can modify the ammo consuming
        {
            return Main.rand.NextFloat() > .70f;//this make so the weapon has 70% chance to not consume ammo, in this case gel
        }
    }
}