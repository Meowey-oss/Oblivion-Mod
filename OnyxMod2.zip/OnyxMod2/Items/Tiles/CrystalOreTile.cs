﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace OnyxMod2.Items.Tiles
{

    public class CrystalOreTile : ModTile
    {
        public override void SetDefaults()
        {
            TileID.Sets.Ore[Type] = true;
            Main.tileSpelunker[Type] = true;
            Main.tileValue[Type] = 110;
            Main.tileShine2[Type] = true;
            Main.tileShine[Type] = 775;
            Main.tileSolid[Type] = true;
            Main.tileMergeDirt[Type] = true;
          
            Main.tileLighted[Type] = true;
            Main.tileBlockLight[Type] = true;
            drop = mod.ItemType("CrystalOre");
            ModTranslation name = CreateMapEntryName();
            name.SetDefault("CrystalOre");
            AddMapEntry(new Color(0, 60, 100), name);
            dustType = DustID.BlueCrystalShard;
            soundType = 21;
            soundStyle = 1;
            mineResist = 2f;
            minPick = 60;
        }

        public override void ModifyLight(int i, int j, ref float r, ref float g, ref float b)
        {
            r = 0.2f;
            g = 0.2f;
            b = 0.9f;
        }

        public override bool CanExplode(int i, int j)
        {
            if (Main.tile[i, j].type == mod.TileType("CrystalOreTile"))
            {
                return false;
            }
            return false;
        }
    }
}