using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace OnyxMod2.Items.Tiles
{

    public class ShadowOreTile : ModTile
    {
        public override void SetDefaults()
        {
            TileID.Sets.Ore[Type] = true;
            Main.tileSpelunker[Type] = true;
            Main.tileValue[Type] = 70;
            Main.tileShine2[Type] = true;
            Main.tileShine[Type] = 575;
            Main.tileSolid[Type] = true;
            Main.tileMergeDirt[Type] = true;
            Main.tileLighted[Type] = true;
            Main.tileBlockLight[Type] = true;
            drop = mod.ItemType("ShadowOre");
            ModTranslation name = CreateMapEntryName();
            name.SetDefault("Shadow Ore");
            AddMapEntry(new Color(60, 60, 60), name);
            dustType = DustID.SilverCoin;
            soundType = 21;
            soundStyle = 1;
            mineResist = 1f;
            minPick = 25;
        }

    }
}