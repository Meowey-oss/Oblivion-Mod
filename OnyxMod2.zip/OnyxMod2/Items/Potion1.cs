﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
namespace OnyxMod2.Items
{



    public class Potion1 : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Golden Potion");
            Tooltip.SetDefault("A Potion with Great power inside of it." + "\nSlime Version");
        }
        public override void SetDefaults()
        {
            item.width = 12;
            item.height = 12;
            item.useStyle = 2;
            item.useTime = 30;
            item.useAnimation = 30;
            item.rare = -12;
            item.consumable = true;
            item.buffType = mod.BuffType("Buff3");
            item.buffTime = 4800;
            item.UseSound = SoundID.Item3;
            item.autoReuse = true;
            item.maxStack = 100;
        }

        /*
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.LesserHealingPotion, 10);
            recipe.AddIngredient(ItemID.Amethyst, 5);
            recipe.AddTile(TileID.AlchemyTable);
            recipe.SetResult(this, 3);
            recipe.AddRecipe();
        }
        */
    }
}