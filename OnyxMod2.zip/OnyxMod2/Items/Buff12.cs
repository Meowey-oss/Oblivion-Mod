﻿using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{
    public class Buff12 : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Toxic");
            Description.SetDefault("You lose life fast and even faster if you have 'Poisoned' Immunity.");
            Main.debuff[Type] = true;
            Main.pvpBuff[Type] = true;
            Main.buffNoSave[Type] = true;
        }

        public override void Update(Player player, ref int buffIndex)
        {
            int num1 = Dust.NewDust(player.position, player.width, player.height, DustID.ToxicBubble);
            Main.dust[num1].scale = 1.9f;
            Main.dust[num1].velocity *= 3f;
            Main.dust[num1].noGravity = true;
            if (player.buffImmune[BuffID.Poisoned] == false)
            {
                player.lifeRegen -= 50;
            }
            else if (player.buffImmune[BuffID.Poisoned] == true)
            {
                player.lifeRegen -= 300;
            }
        }
        public override void Update(NPC npc, ref int buffIndex)
        {
            int num1 = Dust.NewDust(npc.position, npc.width, npc.height, DustID.ToxicBubble);
            Main.dust[num1].scale = 1.9f; 
            Main.dust[num1].velocity *= 3f; 
            Main.dust[num1].noGravity = true;
            if (npc.buffImmune[BuffID.Poisoned] == false)
            {
                npc.lifeRegen -= 160;

                npc.lifeRegenExpectedLossPerSecond = 40;
            }
            else if (npc.buffImmune[BuffID.Poisoned] == true)
            {
                npc.lifeRegen -= 2000;

                npc.lifeRegenExpectedLossPerSecond = 500;
            }



        }




    }
}
