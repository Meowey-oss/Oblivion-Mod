using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class EXBookOfDeath : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Book Of Death");
            Tooltip.SetDefault("'This book is very hot.'");
        }

        public override void SetDefaults()
        {
            item.width = 60;
            item.knockBack = 7f;
            item.value = 1000000;
            item.damage = 350;
            item.height = 30;
            item.useTime = 12;
            item.useAnimation = 12;
            item.useStyle = 5;
            item.noMelee = true;
            item.rare = 9;
            item.mana = 15;
            item.UseSound = SoundID.Item20;
            item.autoReuse = true;
            item.shootSpeed = 12.1f;
            item.magic = true;
            item.shoot = ModContent.ProjectileType<Projectiles.FlamethrowerP4>();
        }

        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            float numberProjectiles = 3 + Main.rand.Next(1);
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedByRandom(MathHelper.ToRadians(14));
                float scale = 1f - (Main.rand.NextFloat() * .9f);
                perturbedSpeed = perturbedSpeed * scale;
                Projectile.NewProjectile(position.X, position.Y, perturbedSpeed.X, perturbedSpeed.Y, type, damage, knockBack, player.whoAmI);
            }
            return false;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(ItemID.LavaBucket, 5);
            recipe.AddIngredient(ItemID.FragmentSolar, 40);
            recipe.AddIngredient(ItemID.SpellTome, 1);
            recipe.AddIngredient(null, ("EXCore"), 1);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}