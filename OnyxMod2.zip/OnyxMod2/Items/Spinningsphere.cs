using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class Spinningsphere : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Spinning Book");
            Tooltip.SetDefault("Snowflakes will spin around you and protect you." + "\nLegendary");
        }

        public override void SetDefaults()
        {
            item.width = 1;
            item.knockBack = 2f;
            item.value = 10000;
            item.damage = 170;
            item.height = 1;
            item.useTime = 29;
            item.useAnimation = 29;
            item.useStyle = 5;
            item.knockBack = 5f;
            item.noMelee = true;
            item.rare = -12;
            item.buffType = ModContent.BuffType<Buff9>();
            item.buffTime = 3600;
            
            item.UseSound = SoundID.Item84;
            item.autoReuse = true;
            item.shoot = ModContent.ProjectileType<Projectiles.Sphere1>();
            item.shootSpeed = 4.1f;
            item.summon = true;
            item.mana = 22;

        }
        public override bool AltFunctionUse(Player player)
        {
            return true;
        }

        public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
        {
            return player.altFunctionUse != 2;
        }

        public override bool UseItem(Player player)
        {
            if (player.altFunctionUse == 2)
            {
                player.MinionNPCTargetAim();
            }
            return base.UseItem(player);
        }

    }
}