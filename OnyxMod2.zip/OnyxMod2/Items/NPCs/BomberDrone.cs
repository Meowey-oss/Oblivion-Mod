﻿
using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;

namespace OnyxMod2.Items.NPCs
{
    public class BomberDrone : ModNPC
    {
        private Player player;
        private float speed;
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("BomberDrone");
        }
        public override void SetDefaults()
        {
            npc.width = 32;
            npc.height = 32;
            npc.damage = 5;
            npc.defense = 0;
            npc.buffImmune[BuffID.Ichor] = true;
            npc.buffImmune[BuffID.OnFire] = true;
            npc.buffImmune[BuffID.CursedInferno] = true;
            npc.lifeMax = 70;
            npc.HitSound = SoundID.NPCHit4;
            npc.DeathSound = SoundID.NPCDeath6;
            npc.knockBackResist = 0.05f;
            npc.value = 100f;
            npc.aiStyle = 2;
            npc.noGravity = true;
            npc.noTileCollide = true;
            npc.lavaImmune = true;


        }

        private void Move(Vector2 offset)
        {
            speed = 15f; // Sets the max speed of the npc.
            Vector2 moveTo = player.Center + offset; // Gets the point that the npc will be moving to.
            Vector2 move = moveTo - npc.Center;
            float magnitude = Magnitude(move);
            if (magnitude > speed)
            {
                move *= speed / magnitude;
            }
            float turnResistance = 60f; // The larget the number the slower the npc will turn.
            move = (npc.velocity * turnResistance + move) / (turnResistance + 1f);
            magnitude = Magnitude(move);
            if (magnitude > speed)
            {
                move *= speed / magnitude;
            }
            npc.velocity = move;
        }

        private float Magnitude(Vector2 mag)
        {
            return (float)Math.Sqrt(mag.X * mag.X + mag.Y * mag.Y);
        }

        public override void ScaleExpertStats(int numPlayers, float bossLifeScale)
        {
            if (MyWorld.ChaosMode == true)
            {
                npc.lifeMax = (int)(npc.lifeMax * 0.50f * bossLifeScale);
                npc.damage = (int)(npc.damage * 0.4f);
            }
            if (MyWorld.ChaosMode == false)
            {
                npc.lifeMax = (int)(npc.lifeMax * 0.25f * bossLifeScale);
                npc.damage = (int)(npc.damage * 0.3f);
            }

        }



        public override void AI()
        {


            Target();

            DespawnHandler();
            Move(new Vector2(-150, -150f));
            npc.ai[0]++;
            Player P = Main.player[npc.target];

            npc.ai[1]++;
            if (npc.ai[1] >= 160)
            {
                float Speed = 1f;
                Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                int damage = 10;
                int type = mod.ProjectileType("BossProjectile6");
                float rotation = (float)Math.Atan2(vector8.Y - (P.position.Y + (P.height * 0.5f)), vector8.X - (P.position.X + (P.width * 0.5f)));
                int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                npc.ai[1] = 0;
            }



        }


        private void Target()
        {
            player = Main.player[npc.target];
        }

        private void DespawnHandler()
        {
            if (!player.active || player.dead)
            {
                npc.TargetClosest(true);
                player = Main.player[npc.target];
                if (!player.active || player.dead)
                {
                    npc.velocity = new Vector2(10f, -10f);
                    if (npc.timeLeft > 10)
                    {

                    }
                    return;


                }



            }



        }
        public override void FindFrame(int frameHeight)
        {
            npc.frameCounter += 1;
            npc.frameCounter %= 60;
            int frame = (int)(npc.frameCounter / 20.0);
            if (frame >= Main.npcFrameCount[npc.type]) frame = 0;
            npc.frame.Y = frame * frameHeight;

            RotateNPCToTarget();
        }

        private void RotateNPCToTarget()
        {
            if (player == null) return;
            Vector2 direction = npc.Center - player.Center;
            float rotation = (float)Math.Atan2(direction.Y, direction.X);
            npc.rotation = rotation + ((float)Math.PI * 0.5f);
        }
    
    

        public override void OnHitPlayer(Player player, int damage, bool crit)
        {
            player.AddBuff(BuffID.OnFire, 100, true);
        }
    }
}







