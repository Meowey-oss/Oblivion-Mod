﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using System;

namespace OnyxMod2.Items.NPCs
{
    public class FireFairy : ModNPC
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Fire Fary");
        }
        public override void SetDefaults()
        {
            npc.width = 20;
            npc.height = 20;
            npc.damage = 30;
            npc.defense = 3;
            npc.buffImmune[BuffID.Ichor] = true;
            npc.buffImmune[BuffID.OnFire] = true;
            npc.buffImmune[BuffID.CursedInferno] = true;
            npc.lifeMax = 50;
            npc.HitSound = SoundID.NPCHit3;
            npc.DeathSound = SoundID.NPCDeath3;
            npc.knockBackResist = 0.50f;
            npc.value = 300f;
            npc.aiStyle = 14;
            npc.lavaImmune = true;


        }

        public override float SpawnChance(NPCSpawnInfo spawnInfo)
        {
            return SpawnCondition.Underworld.Chance * 0.10f;
        }

        public override void AI()
        {
            Dust.NewDust(npc.position + npc.velocity, npc.width, npc.height, DustID.Fire, npc.velocity.X * 0.5f, npc.velocity.Y * 0.5f);
            npc.rotation = (float)Math.Atan2((double)npc.velocity.Y, (double)npc.velocity.X) + 1.57f;
        }
        public override void OnHitPlayer(Player player, int damage, bool crit)
        {
            player.AddBuff(BuffID.OnFire, 100, true);
        }
    }








}
