﻿using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;

namespace OnyxMod2.Items.NPCs
{
    public class CorruptMimic3 : ModNPC
    {
        private Player player;

        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Copper Treasure Chest");
        }
        public override void SetDefaults()
        {
            npc.width = 42;
            npc.height = 48;
            npc.damage = 0;
            npc.defense = 29;
            npc.lifeMax = 50;
            npc.HitSound = SoundID.NPCHit4;
            npc.DeathSound = SoundID.NPCDeath7;
            npc.knockBackResist = 0.0f;
            npc.value = 150f;
            npc.aiStyle = 0;


        }

        public override float SpawnChance(NPCSpawnInfo spawnInfo)
        {
            if (Main.hardMode)
            {
                return SpawnCondition.OverworldDay.Chance * 0.00f;
            }
            return SpawnCondition.OverworldDay.Chance * 0.025f;
        }
      
        public override void AI()
        {
            int dustIndex = Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, DustID.CopperCoin, 0f, 0f, 1, default(Color), 0.2f);
            Main.dust[dustIndex].velocity *= 0.1f;
            Main.dust[dustIndex].scale *= .25f;
        }
        public override void NPCLoot()
        {
            if (Main.rand.Next(2) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.CopperBar, Main.rand.Next(3, 20));
            }

            if (Main.rand.Next(4) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.LeadBar, Main.rand.Next(3, 20));
            }

            if (Main.rand.Next(10) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.GoldBar, Main.rand.Next(3, 20));
            }

            if (Main.rand.Next(2) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.Wood, Main.rand.Next(5, 50));
            }
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.CopperCoin, Main.rand.Next(1, 99));

            int choice = Main.rand.Next(7);
            if (choice == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.SilverAxe, Main.rand.Next(1, 2));
            }

            if (choice == 1)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.SilverPickaxe, Main.rand.Next(1, 2));
            }

            if (choice == 2)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.SilverBow, Main.rand.Next(1, 2));
            }

            if (choice == 3)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.SilverBroadsword, Main.rand.Next(1, 2));
            }
        }
    }
}