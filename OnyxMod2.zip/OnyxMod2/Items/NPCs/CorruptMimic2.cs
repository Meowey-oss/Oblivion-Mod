﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using System;

namespace OnyxMod2.Items.NPCs
{
    public class CorruptMimic2 : ModNPC
    {
        private Player player;
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Silver Treasure Chest");
        }
        public override void SetDefaults()
        {
            npc.width = 42;
            npc.height = 48;
            npc.damage = 0;
            npc.defense = 49;
            npc.lifeMax = 100;
            npc.HitSound = SoundID.NPCHit4;
            npc.DeathSound = SoundID.NPCDeath7;
            npc.knockBackResist = 0.0f;
            npc.value = 150f;
            npc.aiStyle = 0;


        }

        public override float SpawnChance(NPCSpawnInfo spawnInfo)
        {

            if (Main.hardMode)
            {
                return SpawnCondition.OverworldDay.Chance * 0.00f;
            }
            return SpawnCondition.OverworldDay.Chance * 0.01f;
        }

        public override void AI()
        {
            Target();
            Player P = Main.player[npc.target];
            int dustIndex = Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, DustID.SilverCoin, 0f, 0f, 1, default(Color), 0.2f);
            Main.dust[dustIndex].velocity *= 0.1f;
            Main.dust[dustIndex].scale *= .25f;
        }
        private void Target()
        {
            player = Main.player[npc.target];
        }
        public override void NPCLoot()
        {
            if (Main.rand.Next(4) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.SilverBar, Main.rand.Next(6, 30));
            }

            if (Main.rand.Next(2) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.LeadBar, Main.rand.Next(6, 30));
            }

            if (Main.rand.Next(6) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.GoldBar, Main.rand.Next(6, 30));
            }

            if (Main.rand.Next(5) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.Sapphire, Main.rand.Next(1, 5));
            }
            Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.SilverCoin, Main.rand.Next(2, 59));

            int choice = Main.rand.Next(8);
            if (choice == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.GoldAxe, Main.rand.Next(1, 2));
            }

            if (choice == 1)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.GoldPickaxe, Main.rand.Next(1, 2));
            }

            if (choice == 2)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.GoldBow, Main.rand.Next(1, 2));
            }

            if (choice == 3)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.GoldBroadsword, Main.rand.Next(1, 2));
            }

        }
    }
}