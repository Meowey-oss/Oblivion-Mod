﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using System;

namespace OnyxMod2.Items.NPCs
{
    public class BabySpazmatism : ModNPC
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("S-420 Prototype");
        }
        public override void SetDefaults()
        {
            npc.width = 30;
            npc.height = 20;
            npc.damage = 20;
            npc.noGravity = true;
            npc.noTileCollide = true;
            npc.defense = 10;
            npc.lifeMax = 250;
            npc.HitSound = SoundID.NPCHit4;
            npc.DeathSound = SoundID.NPCDeath6;
            npc.knockBackResist = 0.10f;
            npc.value = 150f;
            npc.aiStyle = 31;


        }





    }
}
