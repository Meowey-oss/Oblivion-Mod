﻿using Microsoft.Xna.Framework;
using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;


namespace OnyxMod2.Items.NPCs
{

    public class LSlime : ModNPC
    {
        private Player player;
        private float speed;
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Golden Slime");
            Main.npcFrameCount[npc.type] = 2;
        }
        public override void SetDefaults()
        {
            npc.width = 32;
            npc.height = 26;
            npc.damage = 8;
            npc.defense = 10;
            npc.lifeMax = 100;
            npc.knockBackResist = 0.70f;
            npc.value = 150;
            npc.HitSound = SoundID.NPCHit1;
            npc.DeathSound = SoundID.NPCDeath1;
            aiType = NPCID.BlueSlime;
            npc.noTileCollide = false;
            npc.noGravity = false;
            npc.aiStyle = NPCID.BlueSlime; 
            Main.npcFrameCount[npc.type] = Main.npcFrameCount[NPCID.BlueSlime];
            animationType = NPCID.BlueSlime;


        }

        public override float SpawnChance(NPCSpawnInfo spawnInfo)
        {
            return SpawnCondition.OverworldDay.Chance * 0.01f;
        }



        public override void AI()
        {
            npc.ai[0]++;
            Player P = Main.player[npc.target];
            Target();
            int dustIndex = Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, DustID.GoldCoin, 0f, 0f, 100, default(Color), 0.2f);
            Main.dust[dustIndex].velocity *= 0f;
        }

        private void Target()
        {
            player = Main.player[npc.target];
        }

        public override void NPCLoot()
        {
            if (Main.rand.Next(3) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("Potion1"), Main.rand.Next(1, 2));
            }
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.Gel, Main.rand.Next(3, 10));

            if (Main.rand.Next(100) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.SlimeStaff, Main.rand.Next(1, 2));
            }

        }
        







    }
}
