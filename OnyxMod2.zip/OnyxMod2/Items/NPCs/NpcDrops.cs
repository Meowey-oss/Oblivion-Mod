using System.IO;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.World.Generation;
using Microsoft.Xna.Framework;
using Terraria.GameContent.Generation;

namespace OnyxMod2.Items.NPCs
{
    public class NpcDrops : GlobalNPC
    {
        public override void NPCLoot(NPC npc)
        {
            if (!Main.player[Main.myPlayer].ZoneJungle && npc.type == NPCID.Plantera || !Main.player[Main.myPlayer].ZoneRockLayerHeight && npc.type == NPCID.Plantera)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("JungleStone"));
            }
                if (Main.dayTime && npc.type == NPCID.SkeletronPrime)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("ElectricalStone"));
            }
            if (Main.rand.Next(3) == 0)
            {
                if (npc.type == NPCID.SkeletronHead)
                {
                    Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("DungeonBomb"), Main.rand.Next(1, 2));
                }
            }
            if (Main.rand.Next(20) == 0)
            {
                if (npc.type == NPCID.Pumpking)
                {
                    Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("PumpkinStaff"), Main.rand.Next(1, 2));
                }
            }
            if (!Main.expertMode)
            {
                if (Main.rand.Next(200) == 0)
                {
                    if (npc.type == NPCID.Spazmatism)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("SwordOfJustice"), Main.rand.Next(1, 2));
                        Main.NewText("You found a Legendary Item!", 155, 53, 155);
                    }
                }
            }
            if (Main.expertMode)
            {
                if (Main.rand.Next(100) == 0)
                {
                    if (npc.type == NPCID.Spazmatism)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("SwordOfJustice"), Main.rand.Next(1, 2));
                        Main.NewText("You found a Legendary Item!", 155, 53, 155);
                    }
                }
            }
            if (!NPC.AnyNPCs(mod.NPCType("WormHead3")))
            {
                if (Main.rand.Next(10) == 0)
                {
                    if (npc.type == NPCID.Worm)
                    {
                        NPC.NewNPC((int)npc.position.X, (int)npc.position.Y, mod.NPCType("WormHead3"));
                        Main.NewText("The Worm God has awoken!", 115, 53, 155);
                    }
                }
            }
            if (!Main.expertMode)
            {
                if (Main.rand.Next(200) == 0)
                {
                    if (npc.type == NPCID.EyeofCthulhu)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("ExplosiveRing"), Main.rand.Next(1, 2));
                        Main.NewText("You found a Legendary Item!", 155, 53, 155);
                    }
                }
            }
            if (Main.expertMode)
            {
                if (Main.rand.Next(100) == 0)
                {
                    if (npc.type == NPCID.EyeofCthulhu)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("ExplosiveRing"), Main.rand.Next(1, 2));
                        Main.NewText("You found a Legendary Item!", 155, 53, 155);
                    }
                }
            }
            if (!Main.expertMode)
            {
                if (Main.rand.Next(200) == 0)
                {
                    if (npc.type == NPCID.Retinazer)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("SwordOfJustice"), Main.rand.Next(1, 2));
                        Main.NewText("You found a Legendary Item!", 155, 53, 155);
                    }
                }
            }
            if (Main.expertMode)
            {
                if (Main.rand.Next(100) == 0)
                {
                    if (npc.type == NPCID.Retinazer)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("SwordOfJustice"), Main.rand.Next(1, 2));
                        Main.NewText("You found a Legendary Item!", 155, 53, 155);
                    }
                }
            }
            if (!Main.expertMode)
            {
                if (Main.rand.Next(10) == 0)
                {
                    if (npc.type == NPCID.CultistBoss)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("RingofMoonlight"), Main.rand.Next(1, 2));
                        Main.NewText("You found a special Item!", 155, 53, 155);
                    }
                }
            }
            if (Main.expertMode)
            {
                if (Main.rand.Next(5) == 0)
                {
                    if (npc.type == NPCID.CultistBoss)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("RingofMoonlight"), Main.rand.Next(1, 2));
                        Main.NewText("You found a special Item!", 155, 53, 155);
                    }
                }
            }
            if (!Main.expertMode)
            {
                if (Main.rand.Next(20) == 0)
                {
                    if (npc.type == NPCID.CultistBoss)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("Soul_Scythe"), Main.rand.Next(1, 2));
                        Main.NewText("You found a Legendary Item!", 155, 53, 155);
                    }
                }
            }
            if (Main.expertMode)
            {
                if (Main.rand.Next(10) == 0)
                {
                    if (npc.type == NPCID.CultistBoss)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("Soul_Scythe"), Main.rand.Next(1, 2));
                        Main.NewText("You found a Legendary Item!", 155, 53, 155);
                    }
                }
            }
            if (!Main.expertMode)
            {
                if (Main.rand.Next(100) == 0)
                {
                    if (npc.type == NPCID.DukeFishron)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("Spinningsphere"), Main.rand.Next(1, 2));
                        Main.NewText("You found a Legendary Item!", 155, 53, 155);
                    }
                }
            }
            if (Main.expertMode)
            {
                if (Main.rand.Next(50) == 0)
                {
                    if (npc.type == NPCID.DukeFishron)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("Spinningsphere"), Main.rand.Next(1, 2));
                        Main.NewText("You found a Legendary Item!", 155, 53, 155);
                    }
                }
            }
            if (!Main.expertMode)
            {
                if (Main.rand.Next(20) == 0)
                {
                    if (npc.type == NPCID.WallofFlesh)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("InvertedFlower"), Main.rand.Next(1, 2));
                        Main.NewText("You found a Legendary Item!", 155, 53, 155);
                    }
                }
            }
            if (Main.expertMode)
            {
                if (Main.rand.Next(10) == 0)
                {
                    if (npc.type == NPCID.WallofFlesh)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("InvertedFlower"), Main.rand.Next(1, 2));
                        Main.NewText("You found a Legendary Item!", 155, 53, 155);
                    }
                }
            }
            if (!Main.expertMode)
            {
                if (Main.rand.Next(100) == 0)
                {
                    if (npc.type == NPCID.Plantera)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("JunglePistol"), Main.rand.Next(1, 2));
                        Main.NewText("You found a Legendary Item!", 155, 53, 155);
                    }
                }
            }
            if (Main.expertMode)
            {
                if (Main.rand.Next(50) == 0)
                {
                    if (npc.type == NPCID.Plantera)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("JunglePistol"), Main.rand.Next(1, 2));
                        Main.NewText("You found a Legendary Item!", 155, 53, 155);
                    }
                }
            }
            if (!Main.expertMode)
            {
                if (Main.rand.Next(100) == 0)
                {
                    if (npc.type == NPCID.KingSlime)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("SlimyWings"), Main.rand.Next(1, 2));
                        Main.NewText("You found a Legendary Item!", 155, 53, 155);
                    }
                }
            }
            if (Main.expertMode)
            {
                if (Main.rand.Next(50) == 0)
                {
                    if (npc.type == NPCID.KingSlime)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("SlimyWings"), Main.rand.Next(1, 2));
                        Main.NewText("You found a Legendary Item!", 155, 53, 155);
                    }
                }
            }
            if (Main.hardMode)
            {
                if (Main.rand.Next(2) == 0)
                {
                    if (npc.type == NPCID.Zombie)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("SoulOfRight"), Main.rand.Next(1, 5));
                    }
                }

                if (Main.rand.Next(2) == 0)
                {
                    if (npc.type == NPCID.SwampZombie)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("SoulOfRight"), Main.rand.Next(1, 5));
                    }
                }

                if (Main.rand.Next(2) == 0)
                {
                    if (npc.type == NPCID.SlimedZombie)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("SoulOfRight"), Main.rand.Next(1, 5));
                    }
                }

                if (Main.rand.Next(2) == 0)
                {
                    if (npc.type == NPCID.ArmedZombie)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("SoulOfRight"), Main.rand.Next(1, 5));
                    }
                }

                if (Main.rand.Next(2) == 0)
                {
                    if (npc.type == NPCID.ZombieEskimo)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("SoulOfRight"), Main.rand.Next(1, 5));
                    }
                }
                if (Main.rand.Next(2) == 0)
                {
                    if (npc.type == NPCID.ArmedZombieSlimed)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("SoulOfRight"), Main.rand.Next(1, 5));
                    }
                }

                if (Main.rand.Next(2) == 0)
                {
                    if (npc.type == NPCID.ArmedZombieSwamp)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("SoulOfRight"), Main.rand.Next(1, 5));
                    }
                }

                if (Main.rand.Next(2) == 0)
                {
                    if (npc.type == NPCID.TwiggyZombie)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("SoulOfRight"), Main.rand.Next(1, 5));
                    }
                }

                if (Main.rand.Next(2) == 0)
                {
                    if (npc.type == NPCID.ZombieRaincoat)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("SoulOfRight"), Main.rand.Next(1, 5));
                    }
                }

                if (Main.rand.Next(2) == 0)
                {
                    if (npc.type == NPCID.ZombieDoctor)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("SoulOfRight"), Main.rand.Next(1, 5));
                    }
                }

                if (Main.rand.Next(2) == 0)
                {
                    if (npc.type == NPCID.ArmedZombieTwiggy)
                    {
                        Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("SoulOfRight"), Main.rand.Next(1, 5));
                    }
                }
            }
            if (Main.rand.Next(3) == 0)
            {
                if (npc.type == NPCID.Zombie)
                {
                    Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("BloodOre"), Main.rand.Next(2, 5));
                }
            }
            if (npc.type == NPCID.DungeonGuardian)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("DungeonStone"));
            }
            if (npc.type == NPCID.EyeofCthulhu)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("BloodOre"), Main.rand.Next(10, 30));
            }

            if (npc.type == NPCID.MoonLordCore)
            {

                if (!MyWorld.spawnOre)
                {
                    Main.NewText("You can feel some kind of new power.", 255, 53, 255);
                    for (int k = 0; k < (int)((double)(Main.maxTilesX * Main.maxTilesY) * 1E-05); k++)
                    {

                        WorldGen.TileRunner(WorldGen.genRand.Next(0, Main.maxTilesX), WorldGen.genRand.Next((int)-1400, Main.maxTilesY), (double)WorldGen.genRand.Next(14, 17), WorldGen.genRand.Next(14, 17), mod.TileType("OnyxOreTile"), false, 0f, 0f, false, true);
                    }
                }
                MyWorld.spawnOre = true;
            }


        }
    }
}