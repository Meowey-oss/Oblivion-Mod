﻿using Microsoft.Xna.Framework;
using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;


namespace OnyxMod2.Items.NPCs
{

    public class GodSlime : ModNPC
    {
        private Player player;
        private float speed;
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Toxic Slime");
            Main.npcFrameCount[npc.type] = 2;
        }
        public override void SetDefaults()
        {
            npc.width = 32;
            npc.height = 52;
            npc.damage = 100;
            npc.defense = 100;
            npc.lifeMax = 3000;
            npc.knockBackResist = 0.0f;
            npc.value = 1500;
            npc.HitSound = SoundID.NPCHit1;
            npc.DeathSound = SoundID.NPCDeath1;
            npc.buffImmune[mod.BuffType("Buff12")] = true;
            aiType = NPCID.BlueSlime;
            npc.noTileCollide = false;
            npc.noGravity = false;
            npc.aiStyle = NPCID.BlueSlime; 
            Main.npcFrameCount[npc.type] = Main.npcFrameCount[NPCID.BlueSlime];
            animationType = NPCID.BlueSlime;


        }
        public override void OnHitPlayer(Player player, int damage, bool crit)
        {
            player.AddBuff(mod.BuffType("Buff12"), 200, true);
        }



        public override void AI()
        {
            npc.ai[0]++;
            Player P = Main.player[npc.target];
            Target();
            Dust.NewDust(npc.position + npc.velocity, npc.width, npc.height, DustID.ToxicBubble, npc.velocity.X * 0.2f, npc.velocity.Y * 0.2f);
        }


        private void Target()
        {
            player = Main.player[npc.target];
        }

        public override void NPCLoot()
        {

                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.Gel, Main.rand.Next(30, 100));

            if (Main.rand.Next(10) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.SlimeStaff, Main.rand.Next(1, 2));
            }

        }
        







    }
}
