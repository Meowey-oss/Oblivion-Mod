﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace OnyxMod2.Items.NPCs
{
    public class BossHelper3 : ModNPC
    {
        private Player player;
        private float speed;
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Corrupted Spazmatism");
        }
        public override void SetDefaults()
        {
            npc.width = 110;
            npc.height = 182;
            npc.damage = 40;
            npc.defense = 50;
            npc.lavaImmune = true;
            npc.noGravity = true;
            npc.knockBackResist = 0f;
            npc.noTileCollide = true;
            npc.lifeMax = 20000;
            npc.noGravity = true;
            npc.HitSound = SoundID.NPCHit4;
            npc.DeathSound = SoundID.NPCDeath6;
            npc.knockBackResist = 0.00f;
            npc.value = 150f;
            npc.aiStyle = 2;

           
        }
        private void Move(Vector2 offset)
        {
            speed = 9f;
            Vector2 moveTo = player.Center + offset;
            Vector2 move = moveTo - npc.Center;
            float magnitude = Magnitude(move);
            if (magnitude > speed)
            {
                move *= speed / magnitude;
            }
            float turnResistance = 20f;
            move = (npc.velocity * turnResistance + move) / (turnResistance + 1f);
            magnitude = Magnitude(move);
            if (magnitude > speed)
            {
                move *= speed / magnitude;
            }
            npc.velocity = move;
        }

        private float Magnitude(Vector2 mag)
        {
            return (float)Math.Sqrt(mag.X * mag.X + mag.Y * mag.Y);
        }
        public override void AI()
        {
            Target();

            DespawnHandler();

            RotateNPCToTarget();
            if (!NPC.AnyNPCs(mod.NPCType("Class1")))
            {
                npc.TargetClosest(true);
                player = Main.player[npc.target];
                if (!player.active || player.dead)
                {
                    npc.velocity = new Vector2(10f, -10f);
                    if (npc.timeLeft > 10)
                    {

                    }
                    return;
                }
            }
            npc.ai[0]++;
            Player P = Main.player[npc.target];

            if (NPC.AnyNPCs(mod.NPCType("BossHelper1")))
            {
                npc.dontTakeDamage = true;
            }

            if (!NPC.AnyNPCs(mod.NPCType("BossHelper1")))
            {
                npc.dontTakeDamage = false;
            }

            npc.ai[2]++;
            if (npc.ai[2] == 250)
            {
                Main.PlaySound(15, (int)npc.position.X, (int)npc.position.Y, 0);
                npc.velocity.X *= 4.98f;
                npc.velocity.Y *= 4.98f;
                Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height * 0.5f));
                {
                    float rotation = (float)Math.Atan2((vector8.Y) - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), (vector8.X) - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                    npc.velocity.X = (float)(Math.Cos(rotation) * 16) * -1;
                    npc.velocity.Y = (float)(Math.Sin(rotation) * 16) * -1;
                }

                npc.ai[0] %= (float)Math.PI * 2f;
                Vector2 offset = new Vector2((float)Math.Cos(npc.ai[0]), (float)Math.Sin(npc.ai[0]));


            }
            if (npc.ai[2] == 280)
            {
                npc.velocity.X *= 4.98f;
                npc.velocity.Y *= 4.98f;
                Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height * 0.5f));
                {
                    float rotation = (float)Math.Atan2((vector8.Y) - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), (vector8.X) - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                    npc.velocity.X = (float)(Math.Cos(rotation) * 0) * -1;
                    npc.velocity.Y = (float)(Math.Sin(rotation) * 0) * -1;
                }

                npc.ai[0] %= (float)Math.PI * 2f;
                Vector2 offset = new Vector2((float)Math.Cos(npc.ai[0]), (float)Math.Sin(npc.ai[0]));


            }
            if (npc.ai[2] == 290)
            {
                npc.velocity.X *= 4.98f;
                npc.velocity.Y *= 4.98f;
                Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height * 0.5f));
                {
                    float rotation = (float)Math.Atan2((vector8.Y) - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), (vector8.X) - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                    npc.velocity.X = (float)(Math.Cos(rotation) * 0) * -1;
                    npc.velocity.Y = (float)(Math.Sin(rotation) * 0) * -1;
                }

                npc.ai[0] %= (float)Math.PI * 2f;
                Vector2 offset = new Vector2((float)Math.Cos(npc.ai[0]), (float)Math.Sin(npc.ai[0]));

                npc.ai[2] = 900;

            }

            if (npc.ai[2] == 200)
            {
                Main.PlaySound(15, (int)npc.position.X, (int)npc.position.Y, 0);
                npc.velocity.X *= 4.98f;
                npc.velocity.Y *= 4.98f;
                Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height * 0.5f));
                {
                    float rotation = (float)Math.Atan2((vector8.Y) - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), (vector8.X) - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                    npc.velocity.X = (float)(Math.Cos(rotation) * 17) * -1;
                    npc.velocity.Y = (float)(Math.Sin(rotation) * 17) * -1;
                }

                npc.ai[0] %= (float)Math.PI * 2f;
                Vector2 offset = new Vector2((float)Math.Cos(npc.ai[0]), (float)Math.Sin(npc.ai[0]));



            }
            if (npc.ai[2] == 240)
            {
                npc.velocity.X *= 4.98f;
                npc.velocity.Y *= 4.98f;
                Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height * 0.5f));
                {
                    float rotation = (float)Math.Atan2((vector8.Y) - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), (vector8.X) - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                    npc.velocity.X = (float)(Math.Cos(rotation) * 0) * -1;
                    npc.velocity.Y = (float)(Math.Sin(rotation) * 0) * -1;
                }

                npc.ai[0] %= (float)Math.PI * 2f;
                Vector2 offset = new Vector2((float)Math.Cos(npc.ai[0]), (float)Math.Sin(npc.ai[0]));


            }
            if (MyWorld.ChaosMode)
            {
                if (npc.ai[2] >= 10 && npc.ai[2] <= 280)
                {
                    npc.alpha = 230;
                }
                else 
                npc.alpha = 0;
            }
           
            if (npc.ai[2] == 160)
            {
                Main.PlaySound(15, (int)npc.position.X, (int)npc.position.Y, 0);
                npc.velocity.X *= 4.98f;
                npc.velocity.Y *= 4.98f;
                Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height * 0.5f));
                {
                    float rotation = (float)Math.Atan2((vector8.Y) - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), (vector8.X) - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                    npc.velocity.X = (float)(Math.Cos(rotation) * 17) * -1;
                    npc.velocity.Y = (float)(Math.Sin(rotation) * 17) * -1;
                }

                npc.ai[0] %= (float)Math.PI * 2f;
                Vector2 offset = new Vector2((float)Math.Cos(npc.ai[0]), (float)Math.Sin(npc.ai[0]));



            }
            if (npc.ai[2] == 190)
            {
                npc.velocity.X *= 4.98f;
                npc.velocity.Y *= 4.98f;
                Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height * 0.5f));
                {
                    float rotation = (float)Math.Atan2((vector8.Y) - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), (vector8.X) - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                    npc.velocity.X = (float)(Math.Cos(rotation) * 0) * -1;
                    npc.velocity.Y = (float)(Math.Sin(rotation) * 0) * -1;
                }

                npc.ai[0] %= (float)Math.PI * 2f;
                Vector2 offset = new Vector2((float)Math.Cos(npc.ai[0]), (float)Math.Sin(npc.ai[0]));


            }
            if (npc.ai[2] == 120)
            {
                Main.PlaySound(15, (int)npc.position.X, (int)npc.position.Y, 0);
                npc.velocity.X *= 4.98f;
                npc.velocity.Y *= 4.98f;
                Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height * 0.5f));
                {
                    float rotation = (float)Math.Atan2((vector8.Y) - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), (vector8.X) - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                    npc.velocity.X = (float)(Math.Cos(rotation) * 17) * -1;
                    npc.velocity.Y = (float)(Math.Sin(rotation) * 17) * -1;
                }

                npc.ai[0] %= (float)Math.PI * 2f;
                Vector2 offset = new Vector2((float)Math.Cos(npc.ai[0]), (float)Math.Sin(npc.ai[0]));


            }
            if (npc.ai[2] == 150)
            {
                npc.velocity.X *= 4.98f;
                npc.velocity.Y *= 4.98f;
                Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height * 0.5f));
                {
                    float rotation = (float)Math.Atan2((vector8.Y) - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), (vector8.X) - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                    npc.velocity.X = (float)(Math.Cos(rotation) * 0) * -1;
                    npc.velocity.Y = (float)(Math.Sin(rotation) * 0) * -1;
                }

                npc.ai[0] %= (float)Math.PI * 2f;
                Vector2 offset = new Vector2((float)Math.Cos(npc.ai[0]), (float)Math.Sin(npc.ai[0]));


            }

            if (npc.ai[2] >= 1000)
            {
                   /*
                npc.rotation += 0.1f;
                  */
                 Move(new Vector2(0, 0f));
                float Speed = 8f;
                Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                int damage = 10;
                int type = mod.ProjectileType("FlamethrowerP2");
                 
                float rotation = (float)Math.Atan2(vector8.Y - (P.position.Y + (P.height * 0.5f)), vector8.X - (P.position.X + (P.width * 0.5f)));
                int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);

            }

            if (npc.ai[2] >= 1400)
            {
                npc.ai[2] = 80;
            }

        }

        private void Target()
        {

                player = Main.player[npc.target];
            
        }

        private void RotateNPCToTarget()
        {


                if (player == null) return;
                Vector2 direction = npc.Center - player.Center;
                float rotation = (float)Math.Atan2(direction.Y, direction.X);
               npc.rotation = rotation + ((float)Math.PI * 0.5f);
            

        }
        public override bool? DrawHealthBar(byte hbPostition, ref float scale, ref Vector2 position)
        {
            if (npc.ai[2] >= 10 && npc.ai[2] <= 280)
            {


                scale = 0f;

            }
            else scale = 1f;
            return null;

        }
        private void DespawnHandler()
        {
            if (!player.active || player.dead)
            {
                npc.TargetClosest(true);
                player = Main.player[npc.target];
                if (!player.active || player.dead)
                {
                    npc.velocity = new Vector2(10f, -10f);
                    if (npc.timeLeft > 10)
                    {

                    }
                    return;
                }
            }
        }
    }
}



    

