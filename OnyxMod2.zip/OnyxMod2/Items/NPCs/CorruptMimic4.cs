﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using System;

namespace OnyxMod2.Items.NPCs
{
    public class CorruptMimic4 : ModNPC
    {
        private Player player;
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Platinum Treasure Chest");
        }
        public override void SetDefaults()
        {
            npc.width = 42;
            npc.height = 48;
            npc.damage = 0;
            npc.defense = 99;
            npc.lifeMax = 200;
            npc.HitSound = SoundID.NPCHit4;
            npc.DeathSound = SoundID.NPCDeath7;
            npc.knockBackResist = 0.0f;
            npc.value = 150f;
            npc.aiStyle = 0;


        }



        public override float SpawnChance(NPCSpawnInfo spawnInfo)
        {
            if (Main.hardMode)
            {
                return SpawnCondition.OverworldDay.Chance * 0.03f;
            }
            return SpawnCondition.OverworldDay.Chance * 0.00f;
        }


        public override void AI()
        {
            Target();
            Player P = Main.player[npc.target];
            int dustIndex = Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, DustID.PlatinumCoin, 0f, 0f, 1, default(Color), 0.2f);
            Main.dust[dustIndex].velocity *= 0.1f;
            Main.dust[dustIndex].scale *= .25f;
        }

        private void Target()
        {
            player = Main.player[npc.target];
        }

        public override void OnHitPlayer(Player player, int damage, bool crit)
        {
            player.AddBuff(mod.BuffType("Buff4"), 200, true);
        }
        public override void NPCLoot()
        {

            int choice = Main.rand.Next(12);
            if (choice == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("Emblem1"), Main.rand.Next(1, 2));
            }

            if (choice == 1)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("Emblem2"), Main.rand.Next(1, 2));
            }

            if (choice == 2)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("Emblem3"), Main.rand.Next(1, 2));
            }

            if (choice == 3)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height,ItemID.Bezoar, Main.rand.Next(1, 2));
            }

            if (choice == 4)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.AdhesiveBandage, Main.rand.Next(1, 2));
            }

            if (choice == 5)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.ArmorPolish, Main.rand.Next(1, 2));
            }

            if (choice == 6)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.Vitamins, Main.rand.Next(1, 2));
            }

            if (choice == 7)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.FastClock, Main.rand.Next(1, 2));
            }

            if (choice == 8)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.TrifoldMap, Main.rand.Next(1, 2));
            }

            if (choice == 9)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.Megaphone, Main.rand.Next(1, 2));
            }

            if (choice == 10)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.Nazar, Main.rand.Next(1, 2));
            }

            if (choice == 11)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, ItemID.Blindfold, Main.rand.Next(1, 2));
            }

        }
    }

}