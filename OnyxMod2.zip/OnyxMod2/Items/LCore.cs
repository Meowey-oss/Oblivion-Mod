using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OnyxMod2.Items
{

    public class LCore : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Legendary Core");
            Tooltip.SetDefault("'I hope this is worth farming for you.'" + "\nDecreases damage taken by 33% but decreases all damage and crit by 25%.");
        }

        public override void SetDefaults()
        {
            item.width = 50;
            item.height = 50;
            item.value = Item.buyPrice(6, 66, 66, 66);
            item.rare = -12;
            item.accessory = true;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            
            player.meleeCrit -= 25;
            player.rangedCrit -= 25;
            player.thrownCrit -= 25;
            player.magicCrit -= 25;
            player.endurance += 0.33f;
            player.minionDamage -= 0.25f;
            player.thrownDamage -= 0.25f;
            player.magicDamage -= 0.25f;
            player.meleeDamage -= 0.25f;
            player.rangedDamage -= 0.25f;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);

            recipe.AddIngredient(null, "OnyxBar", 5);
            recipe.AddIngredient(null, "ExplosiveRing", 1);
            recipe.AddIngredient(null, "EXCore", 1);
            recipe.AddIngredient(null, "JunglePistol", 1);
            recipe.AddIngredient(null, "InfinityStone", 1);
            recipe.AddIngredient(null, "SwordOfJustice", 1);
            recipe.AddIngredient(null, "Beam1", 1);
            recipe.AddIngredient(null, "Flamethrower1", 1);
            recipe.AddIngredient(null, "InvertedFlower", 1);
            recipe.AddIngredient(null, "Spinningsphere", 1);
            recipe.AddIngredient(null, "Soul_Scythe", 1);
            recipe.AddTile(TileID.LunarCraftingStation);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

    }
}