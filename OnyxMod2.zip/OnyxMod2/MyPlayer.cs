using System;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;

namespace OnyxMod2
{
    public class MyPlayer : ModPlayer
    {

        public static MyPlayer Get() => Get(Main.LocalPlayer);
        public static MyPlayer Get(Player player) => player.GetModPlayer<MyPlayer>();
    
        public bool Lol;
        public bool no;
        public bool ROML;
        public static bool nobuff;
        public bool mem;
        public static bool ee;
        public static bool em;
        public static bool NerfWepWG1;
        public static bool BuffWepWG1;
        public bool q;
        public static bool minikn = false;
        public bool minionName = false;
        public static bool hasProjectile;


        public bool Spinningsphere { get; set; }
        public bool memee { get; set; }
        public bool memeee { get; set; }
        public override void ResetEffects()
        {
            memeee = false;
            Spinningsphere = false;
            ee = false;
            mem = false;
            memee = false;
            no = false;
            nobuff = false;
            minikn = false;
            em = false;
            Lol = false;
            ROML = false;

          
        }
        

        
        public override bool PreKill(double damage, int hitDirection, bool pvp, ref bool playSound, ref bool genGore, ref PlayerDeathReason damageSource)
        {
            if (ee == true && em == false)
            {

                player.AddBuff(mod.BuffType("Buff8"), 5000, true);
                player.statLife += 250;
                player.HealEffect(250);
                Main.PlaySound(SoundID.MoonLord, (int)player.position.X, (int)player.position.Y, 6);

            }
            if (ee == false || em == true)
           {
            return base.PreKill(damage, hitDirection, pvp, ref playSound, ref genGore, ref damageSource);
           }
           else
            return false;

            
        }


        public override void PostHurt(bool pvp, bool quiet, double damage, int hitDirection, bool crit)
        {
            SpawnProjectileOnPlayerHurt();
        }
        
        
        private void SpawnProjectileOnPlayerHurt()
        {
            if (Lol)
                Lolol();

            if (ROML)
                ROMFL1();

            if (mem)
                MEM1();

            if (no)
                HELP();
        }

        private void HELP() 
        {
            float speedX = 3;
            float speedY = 3;
            Vector2 vector8 = new Vector2(player.position.X + (player.width / 2), player.position.Y + (player.height / 2));
            player.position += Vector2.Normalize(new Vector2(speedX, speedY)) * 0f;
            float numberProjectiles = 2;
            float rotation = MathHelper.ToRadians(1);
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedBy(MathHelper.Lerp(-rotation, rotation, i / (numberProjectiles - 1))) * .7f;
                Projectile.NewProjectile(player.position.X, player.position.Y, perturbedSpeed.X, perturbedSpeed.Y, mod.ProjectileType("E"), 2000, 0f, player.whoAmI, 0f, 0f);
            }
        }
        private void MEM1()
        {
            float speedX = 2;
            float speedY = 2;
            Vector2 vector8 = new Vector2(player.position.X + (player.width / 2), player.position.Y + (player.height / 2));
            player.position += Vector2.Normalize(new Vector2(speedX, speedY)) * 0f;
            float numberProjectiles = 6;
            float rotation = MathHelper.ToRadians(360);
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedBy(MathHelper.Lerp(-rotation, rotation, i / (numberProjectiles - 1))) * .7f;
                Projectile.NewProjectile(player.position.X, player.position.Y, perturbedSpeed.X, perturbedSpeed.Y, ProjectileID.IceBolt, 5, 0f, player.whoAmI, 0f, 0f);
            }
        }
        private void ROMFL1()
        {
            float speedX = 2;
            float speedY = 2;
            Vector2 vector8 = new Vector2(player.position.X + (player.width / 2), player.position.Y + (player.height / 2));
            player.position += Vector2.Normalize(new Vector2(speedX, speedY)) * 0f;
            float numberProjectiles = 10;
            float rotation = MathHelper.ToRadians(360);
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedBy(MathHelper.Lerp(-rotation, rotation, i / (numberProjectiles - 1))) * .7f;
                Projectile.NewProjectile(player.position.X, player.position.Y, perturbedSpeed.X, perturbedSpeed.Y, ProjectileID.LunarFlare, 40, 0f, player.whoAmI, 0f, 0f);
            }
        }
        private void Lolol() 
        {
            float speedX = 2;
            float speedY = 2;
            Vector2 vector8 = new Vector2(player.position.X + (player.width / 2), player.position.Y + (player.height / 2));
            player.position += Vector2.Normalize(new Vector2(speedX, speedY)) * 0f;
            float numberProjectiles = 20;
            float rotation = MathHelper.ToRadians(360);
            for (int i = 0; i < numberProjectiles; i++)
            {
                Vector2 perturbedSpeed = new Vector2(speedX, speedY).RotatedBy(MathHelper.Lerp(-rotation, rotation, i / (numberProjectiles - 1))) * .7f;
                Projectile.NewProjectile(player.position.X, player.position.Y, perturbedSpeed.X, perturbedSpeed.Y, ProjectileID.LunarFlare, 90, 0f, player.whoAmI, 0f, 0f);
            }
        }
    }
}