
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using OnyxMod2.Items;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.UI;
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Terraria.DataStructures;
using Terraria.GameContent.UI.Elements;
using Terraria.Localization;



namespace OnyxMod2
{
	class OnyxMod2 : Mod
	{
    /*
        internal UserInterface MyInterface;
        internal BookUI MyUI;
        */


        public override void Load()
        {

       


        }

        /*public override void UpdateUI(GameTime gameTime)
        {
            // it will only draw if the player is not on the main menu
            if (!Main.gameMenu
                )
            {
                MyInterface?.Update(gameTime);
            }
        }
        internal void ShowMyUI()
        {
            MyInterface?.SetState(MyUI);
        }

        internal void HideMyUI()
        {
            MyInterface?.SetState(null);
        }
        */
        public OnyxMod2()
		{

        }

        public override void AddRecipeGroups()
        {
#pragma warning disable CS0618 // Typ oder Element ist veraltet
            RecipeGroup group = new RecipeGroup(getName: () => Lang.misc[37] + " BulletBallsLvl2", validItems: new int[]
#pragma warning restore CS0618 // Typ oder Element ist veraltet
            {
              ItemType("BulletBall2"),
              ItemType("BulletBall3"),
            });
            RecipeGroup.RegisterGroup("BulletBalls", group);
        }
    }
}
