using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace OnyxMod2
{
    public class QwertyMethods
    {
        public static float SlowRotation(float currentRotation, float targetAngle, float speed)
        {
            int f = 1; //this is used to switch rotation direction
            float actDirection = new Vector2((float)Math.Cos(currentRotation), (float)Math.Sin(currentRotation)).ToRotation();
            targetAngle = new Vector2((float)Math.Cos(targetAngle), (float)Math.Sin(targetAngle)).ToRotation();

            //this makes f 1 or -1 to rotate the shorter distance
            if (Math.Abs(actDirection - targetAngle) > Math.PI)
            {
                f = -1;
            }
            else
            {
                f = 1;
            }

            if (actDirection <= targetAngle + MathHelper.ToRadians(speed * 2) && actDirection >= targetAngle - MathHelper.ToRadians(speed * 2))
            {
                actDirection = targetAngle;
            }
            else if (actDirection <= targetAngle)
            {
                actDirection += MathHelper.ToRadians(speed) * f;
            }
            else if (actDirection >= targetAngle)
            {
                actDirection -= MathHelper.ToRadians(speed) * f;
            }
            actDirection = new Vector2((float)Math.Cos(actDirection), (float)Math.Sin(actDirection)).ToRotation();

            return actDirection;
        }

        public static Vector2 PolarVector(float radius, float theta)
        {

            return new Vector2((float)Math.Cos(theta), (float)Math.Sin(theta)) * radius;
        }

        public static void BreakTiles(int i, int j, int width, int height)
        {
            for (int x = 0; x < width; x++)
            {
                for (int y = 0; y < height; y++)
                {
                    WorldGen.KillTile(i + x, j + y, false, false, true);
                    WorldGen.KillWall(i + x, j + y, false);
                    Main.tile[i + x, j + y].liquid = 0;
                }

            }
        }
        public static bool ClosestNPC(ref NPC target, float maxDistance, Vector2 position, bool ignoreTiles = false, int overrideTarget = -1)
        {
            bool foundTarget = false;
            if (overrideTarget != -1)
            {
                if ((Main.npc[overrideTarget].Center - position).Length() < maxDistance)
                {
                    target = Main.npc[overrideTarget];
                    return true;
                }

            }
            for (int k = 0; k < Main.npc.Length; k++)
            {
                NPC possibleTarget = Main.npc[k];
                float distance = (possibleTarget.Center - position).Length();
                if (distance < maxDistance && possibleTarget.active && possibleTarget.chaseable && !possibleTarget.dontTakeDamage && !possibleTarget.friendly && possibleTarget.lifeMax > 5 && !possibleTarget.immortal && (Collision.CanHit(position, 0, 0, possibleTarget.Center, 0, 0) || ignoreTiles))
                {
                    target = Main.npc[k];
                    foundTarget = true;


                    maxDistance = (target.Center - position).Length();
                }

            }
            return foundTarget;
        }
        public static void ServerClientCheck()
        {
            if (Main.netMode == 1)
            {
                Main.NewText("Client says Hello!", Color.Pink);
            }


            if (Main.netMode == 2) // Server
            {
                NetMessage.BroadcastChatMessage(Terraria.Localization.NetworkText.FromLiteral("Server says Hello!"), Color.Green);
            }
        }
        public static void ServerClientCheck(bool q)
        {
            if (Main.netMode == 1)
            {
                Main.NewText("Client says It's " + q, Color.Pink);
            }


            if (Main.netMode == 2) // Server
            {
                NetMessage.BroadcastChatMessage(Terraria.Localization.NetworkText.FromLiteral("Server says It's " + q), Color.Green);
            }
        }
        public static void ServerClientCheck(int q)
        {
            if (Main.netMode == 1)
            {
                Main.NewText("Client says It's " + q, Color.Pink);
            }


            if (Main.netMode == 2) // Server
            {
                NetMessage.BroadcastChatMessage(Terraria.Localization.NetworkText.FromLiteral("Server says It's " + q), Color.Green);
            }
        }
        public static void ServerClientCheck(string q)
        {
            if (Main.netMode == 1)
            {
                Main.NewText("Client says It's " + q, Color.Pink);
            }


            if (Main.netMode == 2) // Server
            {
                NetMessage.BroadcastChatMessage(Terraria.Localization.NetworkText.FromLiteral("Server says " + q), Color.Green);
            }
        }
        public static void ServerClientCheck(Vector2 q)
        {
            if (Main.netMode == 1)
            {
                Main.NewText("Client says It's" + q, Color.Pink);
            }


            if (Main.netMode == 2) // Server
            {
                NetMessage.BroadcastChatMessage(Terraria.Localization.NetworkText.FromLiteral("Server says " + q), Color.Green);
            }
        }

        public static Item MakeItemFromID(int type)
        {
            if (type <= 0)
            {
                return null;
            }
            if (type >= ItemID.Count)
            {
                return ItemLoader.GetItem(type).item;
            }
            else
            {
                Item item;
                item = new Item();
                item.SetDefaults(type, true);
                return item;
            }
        }

        public static float AngularDifference(float angle1, float angle2)
        {
            while (angle1 > (float)Math.PI)
            {
                angle1 -= (float)Math.PI * 2;
            }
            while (angle2 > (float)Math.PI)
            {
                angle2 -= (float)Math.PI * 2;
            }
            while (angle1 < -(float)Math.PI)
            {
                angle1 += (float)Math.PI * 2;
            }
            while (angle2 < -(float)Math.PI)
            {
                angle1 += (float)Math.PI * 2;
            }
            if (Math.Abs(angle1 - angle2) > Math.PI)
            {
                return (float)Math.PI * 2 - Math.Abs(angle1 - angle2);
            }
            return Math.Abs(angle1 - angle2);
        }

        public static List<Projectile> ProjectileSpread(Vector2 position, int count, float speed, int type, int damage, float kb, int owner = 255, float ai0 = 0, float ai1 = 0, float rotation = 0f, float spread = (float)Math.PI * 2)
        {
            List<Projectile> me = new List<Projectile>();
            for (int r = 0; r < count; r++)
            {
                float rot = rotation + r * (spread / count) - (spread / 2) + (spread / (2 * count));
                me.Add(Main.projectile[Projectile.NewProjectile(position, PolarVector(speed, rot), type, damage, kb, owner, ai0, ai1)]);
            }
            return me;
        }
    }
    public static class StaticQwertyMethods
    {
        public static void FriendlyFire(this Projectile projectile) //allows friendly projectile to chit player and cause pvp death (like the grenade explosion)
        {
            Rectangle myRect = new Rectangle((int)projectile.position.X, (int)projectile.position.Y, projectile.width, projectile.height);
            int myPlayer = projectile.owner;
            if (Main.player[myPlayer].active && !Main.player[myPlayer].dead && !Main.player[myPlayer].immune && (!projectile.ownerHitCheck || projectile.CanHit(Main.player[myPlayer])))
            {
                Rectangle value = new Rectangle((int)Main.player[myPlayer].position.X, (int)Main.player[myPlayer].position.Y, Main.player[myPlayer].width, Main.player[myPlayer].height);
                if (myRect.Intersects(value))
                {
                    if (Main.player[myPlayer].position.X + (float)(Main.player[myPlayer].width / 2) < projectile.position.X + (float)(projectile.width / 2))
                    {
                        projectile.direction = -1;
                    }
                    else
                    {
                        projectile.direction = 1;
                    }
                    int num4 = Main.DamageVar((float)projectile.damage);
                    projectile.StatusPlayer(myPlayer);
                    Main.player[myPlayer].Hurt(PlayerDeathReason.ByProjectile(projectile.owner, projectile.whoAmI), num4, projectile.direction, true, false, false, -1);
                }
            }
        }
    }


}