﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace OnyxMod2.Bosses
{
    [AutoloadBossHead]
    public class BossHelper1 : ModNPC
    {
        private Player player;
        private float speed;
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Oblivion Clone");
        }
        public override void SetDefaults()

        {
            npc.aiStyle = 5;
            npc.lifeMax = 20000;
            npc.damage = 170;
            npc.defense = 50;
            npc.knockBackResist = 0f;
            npc.width = 138;
            npc.rotation = 1f;
            npc.height = 171;
            npc.value = 1000;
            npc.npcSlots = 10f;
            npc.lavaImmune = true;
            npc.noGravity = true;
            npc.noTileCollide = true;
            npc.HitSound = SoundID.NPCHit1;
            npc.DeathSound = SoundID.NPCDeath1;
        }


        public override void BossLoot(ref string name, ref int potionType)
        {
            potionType = ItemID.SuperHealingPotion;
        }

        public override void AI()
        {
            Target();

            DespawnHandler();

            npc.ai[0]++;
            Player P = Main.player[npc.target];

            if (!NPC.AnyNPCs(mod.NPCType("Class1")))
            {
                npc.TargetClosest(true);
                player = Main.player[npc.target];
                if (!player.active || player.dead)
                {
                    npc.velocity = new Vector2(10f, -10f);
                    if (npc.timeLeft > 10)
                    {

                    }
                    return;
                }
            }

            if (npc.ai[2] >= 170)
            {
                npc.ai[2] = -20;
            }

            if (npc.life >= 1)
                npc.ai[2]++;
            if (npc.ai[2] == 120)
            {
                Main.PlaySound(SoundID.Roar, (int)npc.position.X, (int)npc.position.Y, 0);
                npc.velocity.X *= 4.98f;
                npc.velocity.Y *= 4.98f;
                Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height * 0.5f));
                {
                    float rotation = (float)Math.Atan2((vector8.Y) - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), (vector8.X) - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                    npc.velocity.X = (float)(Math.Cos(rotation) * 38) * -1;
                    npc.velocity.Y = (float)(Math.Sin(rotation) * 38) * -1;
                }

                    npc.ai[0] %= (float)Math.PI * 2f;
                Vector2 offset = new Vector2((float)Math.Cos(npc.ai[0]), (float)Math.Sin(npc.ai[0]));


            }
            if (npc.ai[2] == 160)
            {
                npc.velocity.X *= 4.98f;
                npc.velocity.Y *= 4.98f;
                Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height * 0.5f));
                {
                    float rotation = (float)Math.Atan2((vector8.Y) - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), (vector8.X) - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                    npc.velocity.X = (float)(Math.Cos(rotation) * 0) * -1;
                    npc.velocity.Y = (float)(Math.Sin(rotation) * 0) * -1;
                }

                npc.ai[0] %= (float)Math.PI * 2f;
                Vector2 offset = new Vector2((float)Math.Cos(npc.ai[0]), (float)Math.Sin(npc.ai[0]));


            }










        }

        private void Target()
        {
            player = Main.player[npc.target];
        }


        private void DespawnHandler()
        {
            if (!player.active || player.dead)
            {
                npc.TargetClosest(true);
                player = Main.player[npc.target];
                if (!player.active || player.dead)
                {
                    npc.velocity = new Vector2(10f, -10f);
                    if (npc.timeLeft > 10)
                    {

                    }
                    return;


                }



            }



        }



        private float Magnitude(Vector2 mag)
        {
            return (float)Math.Sqrt(mag.X * mag.X * mag.Y * mag.Y);
        }

        public override void FindFrame(int frameHeight)
        {
            npc.frameCounter += 1;
            npc.frameCounter %= 20;
            int frame = (int)(npc.frameCounter / 2.0);
            if (frame >= Main.npcFrameCount[npc.type]) frame = 0;
            npc.frame.Y = frame * frameHeight;

            RotateNPCToTarget();
        }

        private void RotateNPCToTarget()
        {
            if (npc.ai[2] >= 170)
            {
                if (player == null) return;
                Vector2 direction = npc.Center - player.Center;
                float rotation = (float)Math.Atan2(direction.Y, direction.X);
                npc.rotation = rotation + ((float)Math.PI * 0.5f);
            }
        }



        public override bool? DrawHealthBar(byte hbPostition, ref float scale, ref Vector2 position)
        {
            scale = 1.5f;
            return null;






        }
    }

}
