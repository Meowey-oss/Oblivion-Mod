﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace OnyxMod2.Bosses
{
    [AutoloadBossHead]
    public class MasterControl : ModNPC
    {
        private Player player;
        private float speed;
        internal int meme;
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Master Control");
            Main.npcFrameCount[npc.type] = 3;
        }
        public override void SetDefaults()

        {
            npc.lifeMax = 3600;
            npc.damage = 30;     
            npc.defense = 5;
            npc.knockBackResist = 0f;
            npc.width = 210;
            npc.height = 305;
            npc.value = 1000;
            npc.HitSound = SoundID.NPCHit4;
            npc.DeathSound = SoundID.NPCDeath6;
            npc.npcSlots = 1f;
            npc.boss = true;


            npc.lavaImmune = true;
            /*
            music = mod.GetSoundSlot(SoundType.Music, "Sounds/Music/xfedkjn");
            */
        }

        public override void ScaleExpertStats(int numPlayers, float bossLifeScale)
        {
            if (MyWorld.ChaosMode == true)
            {
                npc.lifeMax = (int)(npc.lifeMax * 1.25f * bossLifeScale);
                npc.damage = (int)(npc.damage * 0.4f);
            }
            if (MyWorld.ChaosMode == false)
            {
                npc.lifeMax = (int)(npc.lifeMax * 0.75f * bossLifeScale);
                npc.damage = (int)(npc.damage * 0.3f);
            }

        }
        public override void BossLoot(ref string name, ref int potionType)
        {
            Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("Bag3"), Main.rand.Next(1, 2));
        }



        public override void AI()
        {
            Player P = Main.player[npc.target];
            if (NPC.AnyNPCs(mod.NPCType("SuperDrone1")))
            {
                npc.dontTakeDamage = true;
                npc.aiStyle = 2;

                npc.noTileCollide = true;
                npc.noGravity = true;

            }
            else if (!NPC.AnyNPCs(mod.NPCType("SuperDrone1")))
            {
                npc.dontTakeDamage = false;
                npc.aiStyle = 2;
                npc.noTileCollide = true;
                npc.noGravity = true;
            }

            npc.ai[0]++;
            Target();
            DespawnHandler();


            if (!Main.expertMode)
            {
                npc.ai[3]++;
                npc.ai[1]++;
                npc.ai[2]++;
                if (npc.ai[3] % 600 == 2)
                {
                    NPC.NewNPC((int)npc.position.X + 200, (int)npc.position.Y + 200, mod.NPCType("CyDrone"));
                }

                if (npc.ai[1] % 1800 == 2)
                {
                    NPC.NewNPC((int)npc.position.X + 200, (int)npc.position.Y + 200, mod.NPCType("BomberDrone"));
                }

                if (!NPC.AnyNPCs(mod.NPCType("SuperDrone1")))
                {
                    if (npc.ai[2] % 2300 == 2)
                    {
                        NPC.NewNPC((int)npc.position.X + 200, (int)npc.position.Y + 200, mod.NPCType("SuperDrone1"));
                    }
                }
            }

            if (Main.expertMode)
            {
                if (MyWorld.ChaosMode == false)
                {
                    meme++;
                    if (meme >= 300)
                    {
                        float Speed = 15f;
                        Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                        int damage = 10;
                        int type = mod.ProjectileType("CrystalBomb");
                        float rotation = (float)Math.Atan2(vector8.Y - (P.position.Y + (P.height * 0.5f)), vector8.X - (P.position.X + (P.width * 0.5f)));
                        int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                        meme = 0;
                    }
                    npc.ai[3]++;
                    npc.ai[1]++;
                    npc.ai[2]++;
                    if (npc.ai[3] % 500 == 2)
                    {
                        NPC.NewNPC((int)npc.position.X + 200, (int)npc.position.Y + 200, mod.NPCType("CyDrone"));
                    }

                    if (npc.ai[1] % 1500 == 2)
                    {
                        NPC.NewNPC((int)npc.position.X + 200, (int)npc.position.Y + 200, mod.NPCType("BomberDrone"));
                    }

                    if (!NPC.AnyNPCs(mod.NPCType("SuperDrone1")))
                    {
                        if (npc.ai[2] % 2050 == 2)
                        {
                            NPC.NewNPC((int)npc.position.X + 200, (int)npc.position.Y + 200, mod.NPCType("SuperDrone1"));
                        }
                    }
                }
            }

            if (Main.expertMode)
            {
                if (MyWorld.ChaosMode == true)
                {
                    meme++;
                    if (meme >= 200)
                    {
                        float Speed = 20f;
                        Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                        int damage = 10;
                        int type = mod.ProjectileType("CrystalBomb");
                        float rotation = (float)Math.Atan2(vector8.Y - (P.position.Y + (P.height * 0.5f)), vector8.X - (P.position.X + (P.width * 0.5f)));
                        int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                        meme = 0;
                    }

                    npc.ai[3]++;
                    npc.ai[1]++;
                    npc.ai[2]++;
                    if (npc.ai[3] % 450 == 2)
                    {
                        NPC.NewNPC((int)npc.position.X + 200, (int)npc.position.Y + 200, mod.NPCType("CyDrone"));
                    }

                    if (npc.ai[1] % 1200 == 2)
                    {
                        NPC.NewNPC((int)npc.position.X + 200, (int)npc.position.Y + 200, mod.NPCType("BomberDrone"));
                    }

                    if (!NPC.AnyNPCs(mod.NPCType("SuperDrone1")))
                    {
                        if (npc.ai[2] % 1700 == 2)
                        {
                            NPC.NewNPC((int)npc.position.X + 200, (int)npc.position.Y + 200, mod.NPCType("SuperDrone1"));
                        }
                    }
                }
            }



        }


        private void Target()
        {
            player = Main.player[npc.target];
        }
        private void DespawnHandler()
        {
            if (!player.active || player.dead)
            {
                npc.TargetClosest(true);
                player = Main.player[npc.target];
                if (!player.active || player.dead)
                {
                    npc.velocity = new Vector2(10f, -10f);
                    if (npc.timeLeft > 10)
                    {

                    }
                    return;


                }



            }



        }








        public override void FindFrame(int frameHeight)
        {
            npc.frameCounter += 1;
            npc.frameCounter %= 30;
            int frame = (int)(npc.frameCounter / 10.0);
            if (frame >= Main.npcFrameCount[npc.type]) frame = 0;
            npc.frame.Y = frame * frameHeight;

        }

        public override bool? DrawHealthBar(byte hbPostition, ref float scale, ref Vector2 position)
        {
            scale = 1.2f;
            return null;






        }
    }

}
