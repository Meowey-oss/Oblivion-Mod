﻿
using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace OnyxMod2.Bosses
{
    [AutoloadBossHead]
    public class Class1 : ModNPC
    {
        internal int ded;
        internal int e;
        internal int p;
        internal int kek;
        internal int meme;
        internal int w;
        internal int gejßW;
        private Player player;
        private float speed;
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Oblivion");
            Main.npcFrameCount[npc.type] = 2;
        }
        public override void SetDefaults()

        {
            NPCID.Sets.TrailingMode[npc.type] = 0;
            NPCID.Sets.TrailCacheLength[npc.type] = 5;
            npc.lifeMax = 100000;
            npc.damage = 50;     
            npc.defense = 60;
            npc.knockBackResist = 0f;
            npc.width = 110;
            npc.height = 152;
            npc.value = 1000;
            npc.npcSlots = 10f;
            npc.boss = true;
            npc.lavaImmune = true;
            npc.buffImmune[mod.BuffType("Buff4")] = true;
            npc.HitSound = SoundID.NPCHit8;
            npc.DeathSound = SoundID.NPCDeath8;

            music = mod.GetSoundSlot(SoundType.Music, "Sounds/Music/CorruptedTheme");

        }
        private void Move(Vector2 offset)
        {
            speed = 45f; 
            Vector2 moveTo = player.Center + offset;
            Vector2 move = moveTo - npc.Center;
            float magnitude = Magnitude(move);
            if (magnitude > speed)
            {
                move *= speed / magnitude;
            }
            float turnResistance = 20f;
            move = (npc.velocity * turnResistance + move) / (turnResistance + 1f);
            magnitude = Magnitude(move);
            if (magnitude > speed)
            {
                move *= speed / magnitude;
            }
            npc.velocity = move;
        }

        private float Magnitude(Vector2 mag)
        {
            return (float)Math.Sqrt(mag.X * mag.X + mag.Y * mag.Y);
        }
        public override void ScaleExpertStats(int numPlayers, float bossLifeScale)
        {
            if (MyWorld.ChaosMode == true)
            {
                npc.lifeMax = (int)(npc.lifeMax * 1.25f * bossLifeScale);
                npc.damage = (int)(npc.damage * 1.4f);
            }
            if (MyWorld.ChaosMode == false)
            {
                npc.lifeMax = (int)(npc.lifeMax * 0.75f * bossLifeScale);
                npc.damage = (int)(npc.damage * 1.3f);
            }

        }
        public override void BossLoot(ref string name, ref int potionType)
        {
            if (!Main.expertMode)
            {
                if (Main.rand.Next(100) == 0)
                {
                    Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("Flamethrower1"), Main.rand.Next(1, 2));
                    Main.NewText("You found a Legendary Item!", 155, 53, 155);
                }
            }
            if (Main.expertMode)
            {
                if (Main.rand.Next(50) == 0)
                {
                    Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("Flamethrower1"), Main.rand.Next(1, 2));
                    Main.NewText("You found a Legendary Item!", 155, 53, 155);
                }
            }
            potionType = ItemID.SuperHealingPotion;
            Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("Bag1"));
        }

        
        public override void AI()
        {


            for (int i = npc.oldPos.Length - 1; i > 0; i--)
                npc.oldPos[i] = npc.oldPos[i - 1];
            npc.oldPos[0] = npc.position;


            Target();

            DespawnHandler();

            DebuffSpawn();

            npc.ai[0]++;
            Player P = Main.player[npc.target];


            if (NPC.AnyNPCs(mod.NPCType("BossHelper1")))
            {
                npc.dontTakeDamage = true;
                npc.aiStyle = 5;
                npc.noGravity = true;
                npc.noTileCollide = true; 
            }
            else if (NPC.AnyNPCs(mod.NPCType("BossHelper2")))
            {
                npc.dontTakeDamage = true;
                npc.aiStyle = 5;
                npc.noGravity = true;
                npc.noTileCollide = true;
            }
            else if (NPC.AnyNPCs(mod.NPCType("BossHelper3")))
            {
                npc.dontTakeDamage = true;
                npc.aiStyle = 5;
                npc.noGravity = true;
                npc.noTileCollide = true;
            }
            if (!NPC.AnyNPCs(mod.NPCType("BossHelper1")) && (!NPC.AnyNPCs(mod.NPCType("BossHelper2"))) && (!NPC.AnyNPCs(mod.NPCType("BossHelper3"))))
            {
                npc.dontTakeDamage = false;
                npc.aiStyle = 5;
                npc.noGravity = true;
                npc.noTileCollide = true;
               if (npc.life <= 75000)
                {
                    if (npc.life <= 75000)
                    {

                        kek++;
                        if (kek == 10)
                        {
                            Main.NewText("I'm not done with you yet!", 125, 53, 185);
                        }
                    }
                     gejßW++;
                      meme++;
                    if (meme >= 45)
                    {
                        if (npc.life <= 75000)
                        {

                                float Speed = 25f;
                                Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                                int damage = 30;
                                int type = mod.ProjectileType("BossProjectile1");
                                float rotation = (float)Math.Atan2(vector8.Y - (P.position.Y + (P.height * 0.5f)), vector8.X - (P.position.X + (P.width * 0.5f)));
                                int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                               meme = 0;
                            
                        }
                    }
                    if (gejßW >= 1 && gejßW <= 100)
                    {
                        Move(new Vector2(-1, -550f));
                    }

                    if (gejßW >= 100 && gejßW <= 200)
                    {
                        Move(new Vector2(-550, -1f));
                    }

                    if (gejßW >= 200 && gejßW <= 300)
                    {
                        Move(new Vector2(1, 550f));
                    }

                    if (gejßW >= 300 && gejßW <= 400)
                    {
                        Move(new Vector2(550, 1f));

                    }

                    if (gejßW >= 400 && gejßW <= 500)
                    {
                        Move(new Vector2(-550, -550f));

                    }
                    if (gejßW >= 500 && gejßW <= 600)
                    {
                        Move(new Vector2(550, -550f));

                    }
                    if (gejßW >= 600 && gejßW <= 700)
                    {
                        Move(new Vector2(550, 550f));

                    }
                    if (gejßW >= 700 && gejßW <= 800)
                    {
                        Move(new Vector2(-550, 550f));

                    }
                    if (gejßW == 500)
                    {
                        NPC.NewNPC((int)npc.position.X, (int)npc.position.Y, mod.NPCType("BabyRetinazer"));
                        NPC.NewNPC((int)npc.position.X, (int)npc.position.Y, mod.NPCType("BabySpazmatism"));
                        NPC.NewNPC((int)npc.position.X, (int)npc.position.Y, mod.NPCType("BabyRetinazer"));
                        NPC.NewNPC((int)npc.position.X, (int)npc.position.Y, mod.NPCType("BabySpazmatism"));
                        NPC.NewNPC((int)npc.position.X, (int)npc.position.Y, mod.NPCType("BabyRetinazer"));
                        NPC.NewNPC((int)npc.position.X, (int)npc.position.Y, mod.NPCType("BabySpazmatism"));
                    }

                    if (gejßW == 801)
                    {
                        npc.velocity.X *= 4.98f;
                        npc.velocity.Y *= 4.98f;
                        Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 2.5f), npc.position.Y + (npc.height * 2.5f));
                        {
                            float rotation = (float)Math.Atan2((vector8.Y) - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), (vector8.X) - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                            npc.velocity.X = (float)(Math.Cos(rotation) * 0) * -1;
                            npc.velocity.Y = (float)(Math.Sin(rotation) * 0) * -1;
                        }

                        npc.ai[0] %= (float)Math.PI * 2f;
                        Vector2 offset = new Vector2((float)Math.Cos(npc.ai[0]), (float)Math.Sin(npc.ai[0]));
                        npc.ai[2] = -40;
                    }

                    if (gejßW >= 1200)
                    {
                        gejßW = 0;
                    }
                    
                }
            }



            if (MyWorld.ChaosMode == false)
            {
                if (npc.life >= 75000)
                    p++;
                if (p == 500)
                {
                    NPC.NewNPC((int)npc.position.X, (int)npc.position.Y, mod.NPCType("BabyRetinazer"));
                    NPC.NewNPC((int)npc.position.X, (int)npc.position.Y, mod.NPCType("BabySpazmatism"));
                    p = 0;
                }
            }
            if (MyWorld.ChaosMode == true)
            {
                if (npc.life >= 75000)
                    p++;
                if (p == 400)
                {
                    NPC.NewNPC((int)npc.position.X, (int)npc.position.Y, mod.NPCType("BabyRetinazer"));
                    NPC.NewNPC((int)npc.position.X, (int)npc.position.Y, mod.NPCType("BabySpazmatism"));
                    p = 0;
                }
            }
            if (!NPC.AnyNPCs(mod.NPCType("BossHelper1")) && (!NPC.AnyNPCs(mod.NPCType("BossHelper2"))) && (!NPC.AnyNPCs(mod.NPCType("BossHelper3"))))
            {

                if (MyWorld.ChaosMode == false)
                {
                        if (npc.life >= 75000)
                        {
                        npc.ai[1]++;
                        w++;
                        if (w >= 400) 
                        {
                            Move(new Vector2(-1, -550f));
                            if (w >= 450)
                            {
                                e++;
                                if (e == 5)
                                {
                                    float Speed = 40f;
                                    Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                                    int damage = 30;
                                    int type = mod.ProjectileType("BossProjectile1");
                                    float rotation = (float)Math.Atan2(vector8.Y - (P.position.Y + (P.height * 0.5f)), vector8.X - (P.position.X + (P.width * 0.5f)));
                                    int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                                    e = 0;
                                    if (w >= 750)
                                    {
                                        w = -150;
                                    }
                                }
                            }
                        }
                        else
                        if (npc.ai[1] >= 80)
                        {
                            float Speed = 25f;
                            Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                            int damage = 30;
                            int type = mod.ProjectileType("BossProjectile1");
                            float rotation = (float)Math.Atan2(vector8.Y - (P.position.Y + (P.height * 0.5f)), vector8.X - (P.position.X + (P.width * 0.5f)));
                            int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                            npc.ai[1] = 0;
                        }
                        if (w >= 400)
                        {

                        }
                        else
                            npc.ai[2]++;
                            if (npc.ai[2] >= 90)
                            {
                                npc.velocity.X *= 4.98f;
                                npc.velocity.Y *= 4.98f;
                                Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 2.5f), npc.position.Y + (npc.height * 2.5f));
                                {
                                    float rotation = (float)Math.Atan2((vector8.Y) - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), (vector8.X) - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                                    npc.velocity.X = (float)(Math.Cos(rotation) * 13) * -1;
                                    npc.velocity.Y = (float)(Math.Sin(rotation) * 13) * -1;
                                }

                                npc.ai[0] %= (float)Math.PI * 2f;
                                Vector2 offset = new Vector2((float)Math.Cos(npc.ai[0]), (float)Math.Sin(npc.ai[0]));
                                npc.ai[2] = -40;



                            }
                        }
                    
                }

                if (MyWorld.ChaosMode == true)
                {
                    if (npc.life >= 75000)
                    {
                        w++;
                        npc.ai[1]++;
                        if (w >= 300)
                        {
                            if (w >= 350)
                            {
                                Move(new Vector2(-1, -550f));
                                e++;
                                if (e == 3)
                                {
                                    float Speed = 30f;
                                    Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                                    int damage = 30;
                                    int type = mod.ProjectileType("BossProjectile1");
                                    float rotation = (float)Math.Atan2(vector8.Y - (P.position.Y + (P.height * 0.5f)), vector8.X - (P.position.X + (P.width * 0.5f)));
                                    int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                                    e = 0;
                                    if (w >= 850)
                                    {
                                        w = -50;
                                    }
                                }
                            }
                        }
                        else
                        if (npc.ai[1] >= 60)
                        {
                            float Speed = 50f;
                            Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                            int damage = 30;
                            int type = mod.ProjectileType("BossProjectile1");
                            float rotation = (float)Math.Atan2(vector8.Y - (P.position.Y + (P.height * 0.5f)), vector8.X - (P.position.X + (P.width * 0.5f)));
                            int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                            npc.ai[1] = 0;
                        }
                        if (w >= 300)
                        {

                        }
                        else
                            npc.ai[2]++;
                        if (npc.ai[2] >= 70)
                        {
                            npc.velocity.X *= 4.98f;
                            npc.velocity.Y *= 4.98f;
                            Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 2.5f), npc.position.Y + (npc.height * 2.5f));
                            {
                                float rotation = (float)Math.Atan2((vector8.Y) - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), (vector8.X) - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                                npc.velocity.X = (float)(Math.Cos(rotation) * 16) * -1;
                                npc.velocity.Y = (float)(Math.Sin(rotation) * 16) * -1;
                            }

                            npc.ai[0] %= (float)Math.PI * 2f;
                            Vector2 offset = new Vector2((float)Math.Cos(npc.ai[0]), (float)Math.Sin(npc.ai[0]));
                            npc.ai[2] = -40;



                        }
                    }
                    
                }
            }

            if (npc.life <= 75000)
                npc.ai[3]++;
            if (npc.ai[3] >= 1)
            {
                NPC.NewNPC((int)npc.position.X, (int)npc.position.Y, mod.NPCType("BossHelper1"));
                NPC.NewNPC((int)npc.position.X, (int)npc.position.Y, mod.NPCType("BossHelper3"));
                NPC.NewNPC((int)npc.position.X, (int)npc.position.Y, mod.NPCType("BossHelper2"));
                npc.ai[3] = -100000000000;
            }
            npc.ai[1] += 0;








        }

    
        private void DebuffSpawn()
        {

                player.AddBuff(mod.BuffType("Buff7"), 1, true);
            
        }
        private void Target()
        {
            player = Main.player[npc.target];
        }


        private void DespawnHandler()
        {
            if (!player.active || player.dead)
            {
                npc.TargetClosest(true);
                player = Main.player[npc.target];
                if (!player.active || player.dead)
                {

                    if (ded == 0)
                    { 
                        Main.NewText("You can't win!", 185, 53, 185);
                        ded = 1;
                    }
                    npc.velocity = new Vector2(10f, -10f);
                    if (npc.timeLeft > 10)
                    {

                    }
                    return;


                }



            }



        }




        public override void FindFrame(int frameHeight)
        {
            npc.frameCounter += 2;
            npc.frameCounter %= 60;
            int frame = (int)(npc.frameCounter / 23.0);
            if (frame >= Main.npcFrameCount[npc.type]) frame = 0;
            npc.frame.Y = frame * frameHeight;

            RotateNPCToTarget();
        }

        private void RotateNPCToTarget()
        {
            if (player == null) return;
            Vector2 direction = npc.Center - player.Center;
            float rotation = (float)Math.Atan2(direction.Y, direction.X);
            npc.rotation = rotation + ((float)Math.PI * 0.5f);
        }



        public override bool? DrawHealthBar(byte hbPostition, ref float scale, ref Vector2 position)
        {
            scale = 1.5f;
            return null;






        }
    }

}
