﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace OnyxMod2.Bosses
{
    [AutoloadBossHead]
    public class Missingno : ModNPC
    {
        private Player player;
        private float speed;
        internal int a;
        internal int b;
        internal int c;
        internal int d;
        internal int e;
        internal int f;
        internal int g;
        internal int h;
        internal int i;
        internal int j;
        internal int k;
        internal int l;
        internal int m;
        internal int n;
        internal int o;



        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Missing.No");
        }
        public override void SetDefaults()

        {
            npc.lifeMax = 666666;
            npc.defense = 400;
            npc.knockBackResist = 0f;
            npc.width = 100;
            npc.height = 100;
            npc.value = 1000;
            npc.npcSlots = 1f;
            npc.height = 560;
            npc.width = 460;
            npc.boss = true;
            npc.lavaImmune = true;
            npc.noGravity = true;
            npc.noTileCollide = true;
            npc.HitSound = SoundID.NPCHit1;
            npc.DeathSound = SoundID.NPCDeath1;
            music = MusicID.Boss1;
        }
        private void Move(Vector2 offset)
        {
            speed = 4500f;
            Vector2 moveTo = player.Center + offset;
            Vector2 move = moveTo - npc.Center;
            float magnitude = Magnitude(move);
            if (magnitude > speed)
            {
                move *= speed / magnitude;
            }
            float turnResistance = 2f;
            move = (npc.velocity * turnResistance + move) / (turnResistance + 1f);
            magnitude = Magnitude(move);
            if (magnitude > speed)
            {
                move *= speed / magnitude;
            }
            npc.velocity = move;
        }
        public override void ScaleExpertStats(int numPlayers, float bossLifeScale)
        {
            npc.damage = (int)(npc.damage * 0.7f);

        }

        public override void BossLoot(ref string name, ref int potionType)
        {
            potionType = ItemID.SuperHealingPotion;
            Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("MissDrop"));
        }

        public override void AI()
        {
            Target();

            DespawnHandler();
            npc.ai[0]++;
            Player P = Main.player[npc.target];
            if (MyWorld.ChaosMode == false) 
            {
                a++;
                if (a <= 1)
                {
                    npc.alpha = 254;
                }
                if (a >= 1)
                {
                    b++;
                    if (b >= 3 && npc.alpha >= 1)
                    {
                        npc.alpha -= 5;
                        b = 0;
                    }
                }
                if (a == 300)
                {
                    Main.NewText("0101010001101000011010010111001100100000011010010111001100100000011011100110111101110100001000000110110101100101", 35, 53, 125);
                }

                if (a == 400)
                {
                    c += 1;
                    d += 1;

                }

                if (c == 1)
                {
                    npc.aiStyle = 5;
                    npc.dontTakeDamage = false;
                    npc.damage = 300;
                    Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, DustID.Electric, 0f, 0f, 100, default(Color), 1.2f);

                }
                else if (c <= 1)
                {
                    Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, DustID.Electric, 0f, 0f, 100, default(Color), 2.5f);
                    npc.aiStyle = 0;
                    npc.dontTakeDamage = true;
                    npc.damage = 1;
                }

                if (d == 1) 
                {
                    e++;

                    if (e == 400)
                    {
                        float Speed = 4f;
                        Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                        int damage = 220;
                        float rotation = (float)Math.Atan2(-npc.velocity.Y, -npc.velocity.X / 3);
                        int type = mod.ProjectileType("BP33");
                        int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                    }

                    if (e == 400)
                    {
                        float Speed = 4f;
                        Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                        int damage = 220;
                        float rotation = (float)Math.Atan2(-npc.velocity.Y, -npc.velocity.X * 4);
                        int type = mod.ProjectileType("BP33");
                        int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                    }

                    if (e == 400)
                    {
                        float Speed = 4f;
                        Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                        int damage = 220;
                        float rotation = (float)Math.Atan2(-npc.velocity.Y, -npc.velocity.X / 2);
                        int type = mod.ProjectileType("BP33");
                        int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                    }

                    if (e == 400)
                    {
                        float Speed = 4f;
                        Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                        int damage = 220;
                        float rotation = (float)Math.Atan2(-npc.velocity.Y, -npc.velocity.X * 2);
                        int type = mod.ProjectileType("BP33");
                        int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                    }

                    if (e == 800)
                    {
                        float Speed = 4f;
                        Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                        int damage = 220;
                        float rotation = (float)Math.Atan2(-npc.velocity.Y, -npc.velocity.X / 3);
                        int type = mod.ProjectileType("BP33");
                        int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                    }

                    if (e == 800)
                    {
                        float Speed = 4f;
                        Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                        int damage = 220;
                        float rotation = (float)Math.Atan2(-npc.velocity.Y, -npc.velocity.X * 4);
                        int type = mod.ProjectileType("BP33");
                        int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                    }

                    if (e == 800)
                    {
                        float Speed = 4f;
                        Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                        int damage = 220;
                        float rotation = (float)Math.Atan2(-npc.velocity.Y, -npc.velocity.X / 2);
                        int type = mod.ProjectileType("BP33");
                        int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                    }

                    if (e == 800)
                    {
                        float Speed = 4f;
                        Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                        int damage = 220;
                        float rotation = (float)Math.Atan2(-npc.velocity.Y, -npc.velocity.X * 2);
                        int type = mod.ProjectileType("BP33");
                        int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                    }

                    if (e == 1200)
                    {
                        float Speed = 4f;
                        Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                        int damage = 220;
                        float rotation = (float)Math.Atan2(-npc.velocity.Y, -npc.velocity.X / 3);
                        int type = mod.ProjectileType("BP33");
                        int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                    }

                    if (e == 1200)
                    {
                        float Speed = 4f;
                        Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                        int damage = 220;
                        float rotation = (float)Math.Atan2(-npc.velocity.Y, -npc.velocity.X * 4);
                        int type = mod.ProjectileType("BP33");
                        int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                    }

                    if (e == 1200)
                    {
                        float Speed = 4f;
                        Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                        int damage = 220;
                        float rotation = (float)Math.Atan2(-npc.velocity.Y, -npc.velocity.X / 2);
                        int type = mod.ProjectileType("BP33");
                        int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                    }

                    if (e == 1200)
                    {
                        float Speed = 4f;
                        Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                        int damage = 220;
                        float rotation = (float)Math.Atan2(-npc.velocity.Y, -npc.velocity.X * 2);
                        int type = mod.ProjectileType("BP33");
                        int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                    }
                    if (e >= 1200)
                    {
                        if (i <= 502 )
                        {
                            npc.damage = 0;
                            Main.PlaySound(SoundID.Shatter, (int)npc.position.X, (int)npc.position.Y, 0);
                            Move(new Vector2(-1, -450f));
                            i++;
                            float Speed = 35f;
                            Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                            int damage = 30;
                            int type = ProjectileID.Stinger;
                            float rotation = (float)Math.Atan2(vector8.Y - (P.position.Y + (P.height * 0.5f)), vector8.X - (P.position.X + (P.width * 0.5f)));
                            int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);

                        }
                        if (i >= 502 && i <= 1202)
                        {
                            npc.damage = 0;
                            Main.PlaySound(SoundID.Shatter, (int)npc.position.X, (int)npc.position.Y, 0);
                            Move(new Vector2(-450, 1f));
                            i++;
                            float Speed = 35f;
                            Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                            int damage = 30;
                            int type = ProjectileID.Stinger;
                            float rotation = (float)Math.Atan2(vector8.Y - (P.position.Y + (P.height * 0.5f)), vector8.X - (P.position.X + (P.width * 0.5f)));
                            int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);

                        }
                        if (i >= 1200 && h <= 3)
                        {
                            j++;
                            if (j >= 3)
                            {
                                npc.aiStyle = 5;
                                j = 0;
                                e = 0;
                                i = 0;
                            }
                        }
                    }

                }

            }

            if (MyWorld.ChaosMode == true)
            {


            }
        }

        private void Target()
        {
            player = Main.player[npc.target];
        }


        private void DespawnHandler()
        {
            if (!player.active || player.dead)
            {
                npc.TargetClosest(false);
                player = Main.player[npc.target];
                if (!player.active || player.dead)
                {
                    npc.velocity = new Vector2(10f, -10f);
                    if (npc.timeLeft > 10)
                    {

                    }
                    return;


                }



            }
        }

        private float Magnitude(Vector2 mag)
        {
            return (float)Math.Sqrt(mag.X * mag.X * mag.Y * mag.Y);
        }

        public override void FindFrame(int frameHeight)
        {
            npc.frameCounter += 1;
            npc.frameCounter %= 60;
            int frame = (int)(npc.frameCounter / 2.0);
            if (frame >= Main.npcFrameCount[npc.type]) frame = 0;
            npc.frame.Y = frame * frameHeight;

            RotateNPCToTarget();
        }

        private void RotateNPCToTarget()
        {
            if (npc.ai[2] <= 80)
            {
                if (player == null) return;
                Vector2 direction = npc.Center - player.Center;
                float rotation = (float)Math.Atan2(direction.Y, direction.X);
                npc.rotation = rotation + ((float)Math.PI * 0.5f);
            }
        }


        public override bool? DrawHealthBar(byte hbPostition, ref float scale, ref Vector2 position)
        {
            scale = 4.5f;
            return null;
        }

    }
}
       