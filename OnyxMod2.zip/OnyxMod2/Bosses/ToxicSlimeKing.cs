
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace OnyxMod2.Bosses
{

    [AutoloadBossHead]

    
    public class ToxicSlimeKing : ModNPC
    {
        internal int LOL;
        internal int NE;
        internal int e;
        internal int f;
        internal int g;
        internal int l;
        internal int p;
        internal int o;
        internal int q;
        internal int u;
        internal int L;
        internal int y;
        internal int s;
        internal int r;
        private Player player;
        private float speed;
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Toxic Slime King");
            
            Main.npcFrameCount[npc.type] = 3;
            
        }
        public override void SetDefaults()

        {
        npc.lifeMax = 220000;
            npc.damage = 120;
            npc.knockBackResist = 0f;
            npc.width = 174;
            npc.height = 120;
            npc.value = 1000;
            npc.alpha = 0;
            npc.npcSlots = 1f;
            npc.defense = 80;
            npc.netAlways = true;
            npc.boss = true;
            npc.lavaImmune = true;
            npc.buffImmune[BuffID.Ichor] = true;
            npc.buffImmune[BuffID.OnFire] = true;
            npc.buffImmune[BuffID.CursedInferno] = true;
            npc.buffImmune[mod.BuffType("Buff12")] = true;
            npc.HitSound = SoundID.NPCHit1;
            npc.DeathSound = SoundID.NPCDeath1;
            Main.npcFrameCount[npc.type] = Main.npcFrameCount[NPCID.KingSlime];
            animationType = NPCID.KingSlime;
            music = mod.GetSoundSlot(SoundType.Music, "Sounds/Music/QueenSlimeBossTheme");
        }
        public override void ScaleExpertStats(int numPlayers, float bossLifeScale)
        {
            if (MyWorld.ChaosMode == true)
            {
                npc.lifeMax = (int)(npc.lifeMax * 1.25f * bossLifeScale);
                npc.damage = (int)(npc.damage * 1.3f);
            }
            if(MyWorld.ChaosMode == false)
            {
              npc.lifeMax = (int)(npc.lifeMax * 0.75f * bossLifeScale);
              npc.damage = (int)(npc.damage * 1.2f);
            }

        }
        public override void BossLoot(ref string name, ref int potionType)
              
        {
            if (Main.expertMode)
            {
                
                    Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("SuperSword"), Main.rand.Next(1, 2));
                
            }
                if (!Main.expertMode)
            {
                if (Main.rand.Next(100) == 0)
                {
                }
            }
            if (Main.expertMode)
            {
                if (Main.rand.Next(50) == 0)
                {
                }
            }
            potionType = ItemID.SuperHealingPotion;
            Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("Bag4"));
        }


        private void Move(Vector2 offset)
        {
            speed = 700f;
            Vector2 moveTo = player.Center + offset;
            Vector2 move = moveTo - npc.Center;
            float magnitude = Magnitude(move);
            if (magnitude > speed)
            {
                move *= speed / magnitude;
            }
            float turnResistance = 1f;
            move = (npc.velocity * turnResistance + move) / (turnResistance + 1f);
            magnitude = Magnitude(move);
            if (magnitude > speed)
            {
                move *= speed / magnitude;
            }
            npc.velocity = move;
        }
        private float Magnitude(Vector2 mag)
        {
            return (float)Math.Sqrt(mag.X * mag.X + mag.Y * mag.Y);
        }

        public override bool? DrawHealthBar(byte hbPostition, ref float scale, ref Vector2 position)
        {
            if (s >= 390 && s <= 510)
            {


                scale = 0f;

            }
            else scale = 2.5f;
            return null;

        }
        public override void AI()
        {
            Player P = Main.player[npc.target];
            s++;
            if (s >= 400 && s <= 510)
            {
                r++;
                if (r == 1)
                {
                    npc.alpha += 4;
                    r = 0;
                }


                if (s == 510)
                {
                    npc.alpha = 0;
                    float Speed = 9f;
                    int damage = 50;
                    int type = mod.ProjectileType("BP10");
                    Vector2 perturbedSpeed = new Vector2(Speed).RotatedByRandom(MathHelper.ToRadians(90));
                    float scale = 1f - (Main.rand.NextFloat() * 15.5f);
                    perturbedSpeed = perturbedSpeed * scale;
                    float rotation = (float)Math.Atan2(new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2)).Y - (P.position.Y + (P.height * 0.5f)), new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2)).X - (P.position.X + (P.width * 0.5f)));
                    int num54 = Projectile.NewProjectile(new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2)).X, new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2)).Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                    s = -500;
                    y = 0;
                }
            }
            if (s >= 490 && s <= 510)
            {
                y = 1;
               
                Move(new Vector2(-1, -320f));
            }

            Target();

            DespawnHandler();
            npc.ai[0]++;
            npc.ai[1]++;

            
              if (Main.expertMode && MyWorld.ChaosMode == true)
               {
                if (p == 1)
                {
                    aiType = 0;
                }
                if (p == 0)
                {
                    if (y == 0)
                    {
                        aiType = NPCID.KingSlime;

                        npc.ai[3]++;
                        if (npc.ai[3] >= 370)
                        {



                            float Speed = 9f;
                            int damage = 50;
                            int type = mod.ProjectileType("FlamethrowerP5");
                            Vector2 perturbedSpeed = new Vector2(Speed).RotatedByRandom(MathHelper.ToRadians(90));
                            float scale = 1f - (Main.rand.NextFloat() * 15.5f);
                            perturbedSpeed = perturbedSpeed * scale;
                            float rotation = (float)Math.Atan2(new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2)).Y - (P.position.Y + (P.height * 0.5f)), new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2)).X - (P.position.X + (P.width * 0.5f)));
                            int num54 = Projectile.NewProjectile(new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2)).X, new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2)).Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                            if (npc.ai[3] >= 580)
                            {
                                npc.ai[3] = 60;
                            }


                        }



                        l++;
                        if (l >= 70)
                        {
                            float Speed = 14f;
                            int damage = 51;
                            int type = mod.ProjectileType("Toxic_Cloud2");
                            float rotation = (float)Math.Atan2(new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2)).Y - (P.position.Y + (P.height * 0.5f)), new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2)).X - (P.position.X + (P.width * 0.5f)));
                            int num54 = Projectile.NewProjectile(new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2)).X, new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2)).Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                            if (l >= 70)
                            {
                                l = 0;
                            }

                        }
                    }
                  }
                }

               if (Main.expertMode && MyWorld.ChaosMode == false)
               {
                if (p == 1)
                {
                    aiType = 0; 
                }
                if (p == 0)
                {
                    if (y == 0)
                    {
                        aiType = NPCID.KingSlime;

                        LOL++;
                        if (LOL >= 70)
                        {
                            float Speed = 11f;
                            int damage = 50;
                            int type = mod.ProjectileType("Toxic_Cloud2");
                            Vector2 perturbedSpeed = new Vector2(Speed).RotatedByRandom(MathHelper.ToRadians(90));
                            float scale = 1f - (Main.rand.NextFloat() * 15.5f);
                            perturbedSpeed = perturbedSpeed * scale;
                            float rotation = (float)Math.Atan2(new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2)).Y - (P.position.Y + (P.height * 0.5f)), new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2)).X - (P.position.X + (P.width * 0.5f)));
                            int num54 = Projectile.NewProjectile(new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2)).X, new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2)).Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                            if (LOL >= 70)
                            {
                                LOL = 0;
                            }

                        }
                        NE++;
                        if (NE >= 60)
                        {
                            float Speed = 6f;
                            int damage = 50;
                            int type = mod.ProjectileType("FlamethrowerP5");
                            Vector2 perturbedSpeed = new Vector2(Speed).RotatedByRandom(MathHelper.ToRadians(90));
                            float scale = 1f - (Main.rand.NextFloat() * 15.5f);
                            perturbedSpeed = perturbedSpeed * scale;
                            float rotation = (float)Math.Atan2(new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2)).Y - (P.position.Y + (P.height * 0.5f)), new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2)).X - (P.position.X + (P.width * 0.5f)));
                            int num54 = Projectile.NewProjectile(new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2)).X, new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2)).Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                            if (NE >= 200)
                            {
                                NE = -400;
                            }

                        }
                    }
                }
                    
               }
                if (MyWorld.ChaosMode == true)
                {
                if (u == 1 && p == 0)
                {
                    if (y == 0)
                    {
                        if (e >= 3)
                        {

                            o++;
                            if (o >= 50)
                            {
                                float Speed = 20f;
                                Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                                int damage = 50;
                                int type = mod.ProjectileType("Toxic_Cloud");
                                float rotation = (float)Math.Atan2(vector8.Y - (P.position.Y + (P.height * 0.5f)), vector8.X - (P.position.X + (P.width * 0.5f)));
                                int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                                o = 0;
                            }
                            q++;
                            if (q >= 60)
                            {
                                if (q >= 60)
                                {
                                    float Speed = 6f;
                                    Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                                    int damage = 60;
                                    float rotation = (float)Math.Atan2(vector8.Y - (P.position.Y * 2 + (P.height * 0.5f)), vector8.X - (P.position.X * 2 + (P.width * 0.5f)));
                                    int type = mod.ProjectileType("FlamethrowerP5");
                                    int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                                }

                                if (q >= 60)
                                {
                                    float Speed = 6f;
                                    Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                                    int damage = 60;
                                    float rotation = (float)Math.Atan2(vector8.Y - (P.position.Y / 2 + (P.height * 0.5f)), vector8.X - (P.position.X / 2 + (P.width * 0.5f)));
                                    int type = mod.ProjectileType("FlamethrowerP5");
                                    int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                                }

                                if (q >= 200)
                                {
                                    q = -400;
                                }

                            }
                        }
                        npc.lifeRegenCount = 500;
                        npc.defense = 40;

                    }
                }
                if (g == 0)
                {
                    e = 0;
                }
                if (npc.life >= 15000 && npc.life <= 70000 && e <= 1 || npc.life >= 15000 && e >= 1 && e <= 4)
                {
                    Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, DustID.ToxicBubble, 10f, 0f, 100, default(Color), 1.5f);
                    Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, DustID.ToxicBubble, 0f, 10f, 100, default(Color), 1.5f);
                    Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, DustID.ToxicBubble, -10f, 0f, 100, default(Color), 1.5f);
                    Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, DustID.ToxicBubble, 0f, -10f, 100, default(Color), 1.5f);
                    Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, DustID.ToxicBubble, -10f, -10f, 100, default(Color), 1.5f);
                    Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, DustID.ToxicBubble, 10f, 10f, 100, default(Color), 1.5f);
                    Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, DustID.ToxicBubble, -10f, 10f, 100, default(Color), 1.5f);
                    Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, DustID.ToxicBubble, -10f, 10f, 100, default(Color), 1.5f);
                    p = 1;
                    if (f == 0)
                    {
                        Main.NewText("Toxic Slime King is powering up!", 155, 53, 155);
                        g += 1;
                        f += 1;
                        e += 1;
                        u += 1;
 
                    }

                    npc.defense = 10000000;
                    npc.lifeRegenCount = 60000;
                }
                else p = 0;
                if (npc.life >= 540000 && e >= 0)
                {
                    e += 4;
                }
                if (e >= 3)
                {

                    npc.lifeRegenCount = 1000;
                    npc.defense = 60;

                }
                int xDistance = (int)npc.position.X - (int)player.position.X;
                    int yDistance = (int)npc.position.Y - (int)player.position.Y;
                    if (xDistance <= 1820)
                    {
                        npc.noTileCollide = false;
                        npc.aiStyle = 15;
                        aiType = NPCID.LavaSlime;
                        npc.noGravity = false;
                    }
                    if (yDistance <= 1820)
                    {
                        npc.noTileCollide = false;
                        npc.noGravity = false;
                        aiType = NPCID.LavaSlime;
                        npc.aiStyle = 15;
                    }
                    if (-xDistance <= 1820)
                    {
                        npc.noTileCollide = false;
                        npc.noGravity = false;
                        aiType = NPCID.LavaSlime;
                        npc.aiStyle = 15;
                    }
                    if (-yDistance <= 1820)
                    {
                        npc.noTileCollide = false;
                        npc.noGravity = false;
                        aiType = NPCID.LavaSlime;
                        npc.aiStyle = 15;
                    }
                    if (xDistance >= 1820)
                    {
                        npc.noTileCollide = true;
                        npc.aiStyle = 2;
                        npc.noGravity = true;
                        if (xDistance >= 1820)
                        {
                            npc.velocity.X *= 4.98f;
                            npc.velocity.Y *= 4.98f;
                            Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height * 0.5f));
                            {
                                float rotation = (float)Math.Atan2((vector8.Y) - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), (vector8.X) - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                                npc.velocity.X = (float)(Math.Cos(rotation) * 26) * -1;
                                npc.velocity.Y = (float)(Math.Sin(rotation) * 26) * -1;
                            }

                            npc.ai[0] %= (float)Math.PI * 2f;
                            Vector2 offset = new Vector2((float)Math.Cos(npc.ai[0]), (float)Math.Sin(npc.ai[0]));
                            Main.PlaySound(SoundID.Roar, 0, (int)npc.position.X, (int)npc.position.Y, 20);

                        }
                    }
                    if (yDistance >= 1820)
                    {
                        npc.noTileCollide = true;
                        npc.aiStyle = 2;
                        npc.noGravity = true;
                        if (yDistance >= 1520)
                        {
                            npc.velocity.X *= 4.98f;
                            npc.velocity.Y *= 4.98f;
                            Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height * 0.5f));
                            {
                                float rotation = (float)Math.Atan2((vector8.Y) - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), (vector8.X) - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                                npc.velocity.X = (float)(Math.Cos(rotation) * 26) * -1;
                                npc.velocity.Y = (float)(Math.Sin(rotation) * 26) * -1;
                            }

                            npc.ai[0] %= (float)Math.PI * 2f;
                            Vector2 offset = new Vector2((float)Math.Cos(npc.ai[0]), (float)Math.Sin(npc.ai[0]));
                            Main.PlaySound(SoundID.Roar, 0, (int)npc.position.X, (int)npc.position.Y, 20);

                        }
                    }
                    if (-xDistance >= 1820)
                    {
                        npc.noTileCollide = true;
                        npc.aiStyle = 2;
                        npc.noGravity = true;
                        if (-xDistance >= 1520)
                        {
                            npc.velocity.X *= 4.98f;
                            npc.velocity.Y *= 4.98f;
                            Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height * 0.5f));
                            {
                                float rotation = (float)Math.Atan2((vector8.Y) - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), (vector8.X) - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                                npc.velocity.X = (float)(Math.Cos(rotation) * 26) * -1;
                                npc.velocity.Y = (float)(Math.Sin(rotation) * 26) * -1;
                            }

                            npc.ai[0] %= (float)Math.PI * 2f;
                            Vector2 offset = new Vector2((float)Math.Cos(npc.ai[0]), (float)Math.Sin(npc.ai[0]));
                            Main.PlaySound(SoundID.Roar, 0, (int)npc.position.X, (int)npc.position.Y, 20);

                        }
                    }
                    if (-yDistance >= 1820)
                    {
                        npc.noTileCollide = true;
                        npc.aiStyle = 2;
                        npc.noGravity = true;
                        if (-yDistance >= 1520)
                        {
                            npc.velocity.X *= 4.98f;
                            npc.velocity.Y *= 4.98f;
                            Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height * 0.5f));
                            {
                                float rotation = (float)Math.Atan2((vector8.Y) - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), (vector8.X) - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                                npc.velocity.X = (float)(Math.Cos(rotation) * 26) * -1;
                                npc.velocity.Y = (float)(Math.Sin(rotation) * 26) * -1;
                            }

                            npc.ai[0] %= (float)Math.PI * 2f;
                            Vector2 offset = new Vector2((float)Math.Cos(npc.ai[0]), (float)Math.Sin(npc.ai[0]));
                            Main.PlaySound(SoundID.Roar, 0, (int)npc.position.X, (int)npc.position.Y, 20);

                        }
                    }
                }
                if (MyWorld.ChaosMode == false)
                {
                if (u == 1 && p == 0)
                {
                    if (y == 0)
                    {
                        if (e >= 3)
                        {

                            o++;
                            if (o >= 70)
                            {
                                float Speed = 20f;
                                Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                                int damage = 50;
                                int type = mod.ProjectileType("Toxic_Cloud");
                                float rotation = (float)Math.Atan2(vector8.Y - (P.position.Y + (P.height * 0.5f)), vector8.X - (P.position.X + (P.width * 0.5f)));
                                int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                                o = 0;
                            }
                            q++;
                            if (q >= 60)
                            {
                                if (q >= 60)
                                {
                                    float Speed = 6f;
                                    Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                                    int damage = 60;
                                    float rotation = (float)Math.Atan2(-npc.velocity.Y, -npc.velocity.X * 4);
                                    int type = mod.ProjectileType("FlamethrowerP5");
                                    int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                                }

                                if (q >= 60)
                                {
                                    float Speed = 6f;
                                    Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                                    int damage = 60;
                                    float rotation = (float)Math.Atan2(-npc.velocity.Y, -npc.velocity.X / 4);
                                    int type = mod.ProjectileType("FlamethrowerP5");
                                    int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                                }

                                if (q >= 200)
                                {
                                    q = -400;
                                }

                            }
                            npc.lifeRegenCount = 500;
                            npc.defense = 40;
                        }
                    }
                }
                if (g == 0)
                {
                    e = 0;
                }
                if (npc.life >= 15000 && npc.life <= 50000 && e <= 1 || npc.life >= 15000 && e >= 1 && e <= 4)
                {
                    Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, DustID.ToxicBubble, 10f, 0f, 100, default(Color), 1.5f);
                    Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, DustID.ToxicBubble, 0f, 10f, 100, default(Color), 1.5f);
                    Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, DustID.ToxicBubble, -10f, 0f, 100, default(Color), 1.5f);
                    Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, DustID.ToxicBubble, 0f, -10f, 100, default(Color), 1.5f);
                    Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, DustID.ToxicBubble, -10f, -10f, 100, default(Color), 1.5f);
                    Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, DustID.ToxicBubble, 10f, 10f, 100, default(Color), 1.5f);
                    Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, DustID.ToxicBubble, -10f, 10f, 100, default(Color), 1.5f);
                    Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, DustID.ToxicBubble, -10f, 10f, 100, default(Color), 1.5f);
                    p = 1;
                   if (f == 0)
                    {
                        Main.NewText("Toxic Slime King is powering up!", 155, 53, 155);
                        g += 1;
                        f += 1;
                        e += 1;
                        u += 1;
                    }
                    npc.defense = 10000000;
                    npc.lifeRegenCount = 40000;
                }
                else p = 0;
                if (npc.life >= 320000 && e >= 0)
                {
                    e += 4;
                }
                if (e >= 3)
                {

                    npc.lifeRegenCount = 500;
                    npc.defense = 40;

                }

                    int xDistance = (int)npc.position.X - (int)player.position.X;
                    int yDistance = (int)npc.position.Y - (int)player.position.Y;
                    if (xDistance <= 1820)
                    {
                        npc.noTileCollide = false;
                        aiType = NPCID.LavaSlime;
                        npc.aiStyle = 15;
                        npc.noGravity = false;
                    }
                    if (yDistance <= 1820)
                    {
                        npc.noTileCollide = false;
                        npc.noGravity = false;
                        aiType = NPCID.LavaSlime;
                        npc.aiStyle = 15;
                    }
                    if (-xDistance <= 1820)
                    {
                        npc.noTileCollide = false;
                        npc.noGravity = false;
                        aiType = NPCID.LavaSlime;
                        npc.aiStyle = 15;
                    }
                    if (-yDistance <= 1820)
                    {
                        npc.noTileCollide = false;
                        npc.noGravity = false;
                        aiType = NPCID.LavaSlime;
                        npc.aiStyle = 15;
                    }
                    if (xDistance >= 1820)
                    {
                        npc.noTileCollide = true;
                        npc.aiStyle = 2;
                        npc.noGravity = true;
                        if (xDistance >= 1820)
                        {
                            npc.velocity.X *= 4.98f;
                            npc.velocity.Y *= 4.98f;
                            Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height * 0.5f));
                            {
                                float rotation = (float)Math.Atan2((vector8.Y) - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), (vector8.X) - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                                npc.velocity.X = (float)(Math.Cos(rotation) * 26) * -1;
                                npc.velocity.Y = (float)(Math.Sin(rotation) * 26) * -1;
                            }

                            npc.ai[0] %= (float)Math.PI * 2f;
                            Vector2 offset = new Vector2((float)Math.Cos(npc.ai[0]), (float)Math.Sin(npc.ai[0]));
                            Main.PlaySound(SoundID.Roar, 0, (int)npc.position.X, (int)npc.position.Y, 20);

                        }
                    }
                    if (yDistance >= 1820)
                    {
                        npc.noTileCollide = true;
                        npc.aiStyle = 2;
                        npc.noGravity = true;
                        if (yDistance >= 1020)
                        {
                            npc.velocity.X *= 4.98f;
                            npc.velocity.Y *= 4.98f;
                            Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height * 0.5f));
                            {
                                float rotation = (float)Math.Atan2((vector8.Y) - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), (vector8.X) - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                                npc.velocity.X = (float)(Math.Cos(rotation) * 26) * -1;
                                npc.velocity.Y = (float)(Math.Sin(rotation) * 26) * -1;
                            }

                            npc.ai[0] %= (float)Math.PI * 2f;
                            Vector2 offset = new Vector2((float)Math.Cos(npc.ai[0]), (float)Math.Sin(npc.ai[0]));
                            Main.PlaySound(SoundID.Roar, 0, (int)npc.position.X, (int)npc.position.Y, 20);

                        }
                    }
                    if (-xDistance >= 1820)
                    {
                        npc.noTileCollide = true;
                        npc.aiStyle = 2;
                        npc.noGravity = true;
                        if (-xDistance >= 1020)
                        {
                            npc.velocity.X *= 4.98f;
                            npc.velocity.Y *= 4.98f;
                            Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height * 0.5f));
                            {
                                float rotation = (float)Math.Atan2((vector8.Y) - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), (vector8.X) - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                                npc.velocity.X = (float)(Math.Cos(rotation) * 26) * -1;
                                npc.velocity.Y = (float)(Math.Sin(rotation) * 26) * -1;
                            }

                            npc.ai[0] %= (float)Math.PI * 2f;
                            Vector2 offset = new Vector2((float)Math.Cos(npc.ai[0]), (float)Math.Sin(npc.ai[0]));
                            Main.PlaySound(SoundID.Roar, 0, (int)npc.position.X, (int)npc.position.Y, 20);

                        }
                    }
                    if (-yDistance >= 1820)
                    {
                        npc.noTileCollide = true;
                        npc.aiStyle = 2;
                        npc.noGravity = true;
                        if (-yDistance >= 1020)
                        {
                            npc.velocity.X *= 4.98f;
                            npc.velocity.Y *= 4.98f;
                            Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height * 0.5f));
                            {
                                float rotation = (float)Math.Atan2((vector8.Y) - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), (vector8.X) - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                                npc.velocity.X = (float)(Math.Cos(rotation) * 26) * -1;
                                npc.velocity.Y = (float)(Math.Sin(rotation) * 26) * -1;
                            }

                            npc.ai[0] %= (float)Math.PI * 2f;
                            Vector2 offset = new Vector2((float)Math.Cos(npc.ai[0]), (float)Math.Sin(npc.ai[0]));
                            Main.PlaySound(SoundID.Roar, 0, (int)npc.position.X, (int)npc.position.Y, 20);

                        }
                    }
                }
            if (y == 0)
            {
                Dust.NewDust(npc.position + npc.velocity, npc.width, npc.height, DustID.ToxicBubble, npc.velocity.X * 0.5f, npc.velocity.Y * 0.5f);
            }
                if (npc.ai[1] == 500)
                {
                    NPC.NewNPC((int)npc.position.X, (int)npc.position.Y, mod.NPCType("ToxicDrone"));
                }
                if (npc.ai[1] == 1000)
                {
                    NPC.NewNPC((int)npc.position.X, (int)npc.position.Y, mod.NPCType("GodSlime"));
                    npc.ai[1] = 0;
                }
            if (MyWorld.ChaosMode == true)

            {
                if (npc.ai[1] == 600)
                {
                    NPC.NewNPC((int)npc.position.X, (int)npc.position.Y, mod.NPCType("ToxicDrone"));
                }
                if (npc.ai[1] == 300)
                {
                    NPC.NewNPC((int)npc.position.X, (int)npc.position.Y, mod.NPCType("GodSlime"));
                    npc.ai[1] = 0;
                }

                if (p == 0)
                {
                    if (y == 0)
                    {
                        npc.ai[2]++;
                        if (npc.ai[2] >= 50)
                        {
                            float Speed = 23f;
                            Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                            int damage = 40;
                            int type = mod.ProjectileType("Toxic_Cloud");
                            float rotation = (float)Math.Atan2(vector8.Y - (P.position.Y + (P.height * 0.5f)), vector8.X - (P.position.X + (P.width * 0.5f)));
                            int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                            npc.ai[2] = 0;
                    }   }
                }
            }

            if (MyWorld.ChaosMode == false)
                {
                if (p == 0)
                {
                    if (y == 0)
                    {
                        npc.ai[2]++;
                        if (npc.ai[2] >= 80)
                        {
                            float Speed = 20f;
                            Vector2 vector8 = new Vector2(npc.position.X + (npc.width / 2), npc.position.Y + (npc.height / 2));
                            int damage = 50;
                            int type = mod.ProjectileType("Toxic_Cloud");
                            float rotation = (float)Math.Atan2(vector8.Y - (P.position.Y + (P.height * 0.5f)), vector8.X - (P.position.X + (P.width * 0.5f)));
                            int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, (float)((Math.Cos(rotation) * Speed) * -1), (float)((Math.Sin(rotation) * Speed) * -1), type, damage, 0f, 0);
                            npc.ai[2] = 0;
                        }
                    }
                 }
                }

            
        }
        private void Target()
        {
            player = Main.player[npc.target];
        }

        /*
        public override void FindFrame(int frameHeight)
        {
            npc.frameCounter += 1;
            npc.frameCounter %= 30;
            int frame = (int)(npc.frameCounter / 8.0);
            if (frame >= Main.npcFrameCount[npc.type]) frame = 0;
            npc.frame.Y = frame * frameHeight;

        }
        */

        private void DespawnHandler()
        {
            if (!player.active || player.dead)
            {
                npc.noTileCollide = true;
                npc.TargetClosest(true);
                player = Main.player[npc.target];
                if (!player.active || player.dead)
                {
                    npc.velocity = new Vector2(10f, -10f);
                    if (npc.timeLeft > 10)
                    {

                    }
                    return;


                }



            }



        }










    }

}
