﻿
using System;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;

namespace OnyxMod2.Bosses
{
    public class Unknown : ModNPC
    {
        private Player player;
        private float speed;
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("The Unknown");
        }
        public override void SetDefaults()
        {
            npc.width = 90;
            npc.height = 68;
            npc.boss = true;
            npc.damage = 60;
            npc.defense = 40;
            npc.buffImmune[BuffID.Ichor] = true;
            npc.buffImmune[BuffID.OnFire] = true;
            npc.buffImmune[BuffID.CursedInferno] = true;
            npc.lifeMax = 30000;
            npc.HitSound = SoundID.NPCHit4;
            npc.DeathSound = SoundID.NPCDeath6;
            npc.knockBackResist = 0.00f;
            npc.value = 100f;
            npc.aiStyle = 2;
            npc.noGravity = true;
            npc.noTileCollide = true;
            npc.lavaImmune = true;


        }

        private void Move(Vector2 offset)
        {
        }

        private float Magnitude(Vector2 mag)
        {
            return (float)Math.Sqrt(mag.X * mag.X + mag.Y * mag.Y);
        }

        public override void ScaleExpertStats(int numPlayers, float bossLifeScale)
        {
            if (MyWorld.ChaosMode == true)
            {
                npc.lifeMax = (int)(npc.lifeMax * 1f * bossLifeScale);
                npc.damage = (int)(npc.damage * 0.7f);
            }
            if (MyWorld.ChaosMode == false)
            {
                npc.lifeMax = (int)(npc.lifeMax * 0.75f * bossLifeScale);
                npc.damage = (int)(npc.damage * 0.4f);
            }

        }



        public override void AI()
        {

            Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, mod.DustType("Dust1"), 0f, 0f, 1000, default(Color), 4f);
            Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, mod.DustType("Dust1"), 0f, 0f, 1000, default(Color), 4f);
            Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, mod.DustType("Dust1"), 0f, 0f, 1000, default(Color), 2f);
            Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, mod.DustType("Dust1"), 0f, 0f, 1000, default(Color), 2f);
            Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, mod.DustType("Dust1"), 0f, 0f, 1000, default(Color), 2f);
            Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, mod.DustType("Dust1"), 0f, 0f, 1000, default(Color), 3f);
            Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, mod.DustType("Dust1"), 0f, 0f, 1000, default(Color), 3f);
            Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, mod.DustType("Dust1"), 0f, 0f, 1000, default(Color), 4f);
            Dust.NewDust(new Vector2(npc.position.X, npc.position.Y), npc.width, npc.height, mod.DustType("Dust1"), 0f, 0f, 1000, default(Color), 4f);

            Target(); 


            DespawnHandler();
            //Move(new Vector2(-150, -150f));
            npc.ai[0]++;
            Player P = Main.player[npc.target];




        }


        private void Target()
        {
            player = Main.player[npc.target];
        }

        private void DespawnHandler()
        {
            if (!player.active || player.dead)
            {
                npc.TargetClosest(true);
                player = Main.player[npc.target];
                if (!player.active || player.dead)
                {
                    npc.velocity = new Vector2(10f, -10f);
                    if (npc.timeLeft > 10)
                    {

                    }
                    return;


                }



            }



        }
        public override void FindFrame(int frameHeight)
        {
            npc.frameCounter += 1;
            npc.frameCounter %= 60;
            int frame = (int)(npc.frameCounter / 20.0);
            if (frame >= Main.npcFrameCount[npc.type]) frame = 0;
            npc.frame.Y = frame * frameHeight;
        }

    
    

        public override void OnHitPlayer(Player player, int damage, bool crit)
        {
            player.AddBuff(mod.BuffType("Buff1"), 200, true);
        }
    }
}







